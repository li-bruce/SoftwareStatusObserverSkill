"""Persist this implementation's reviewed classification for the current candidate."""
import json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from observer_runtime.change_sync import inspect
from observer_runtime.sync_config import config

if __name__ == "__main__":
    cfg = config(ROOT, "sync.json")
    active = json.loads((ROOT / ".stategraph/active.json").read_text())
    change = ROOT / active["change"]
    base, current, impact = inspect(ROOT, cfg, change)
    excluded = {}
    for ident in impact["unmapped_implementation_symbols"]:
        symbol = current["structure"]["symbols"][ident]
        if symbol["kind"] != "class":
            raise ValueError("Needs individual semantic review: " + ident)
        excluded[ident] = "Class declaration is a structural container; its constructor and every method are source-mapped. The class object itself is not a separate business action."
    review = {"candidate_id": current["id"], "decisions": {
        "business": {"action": "updated", "reason": "Preserve U02/U03/U04; add only U05/U06 maintenance: admission continues, administrator-only manual toggling, active prints continue, eligible FIFO resumes."},
        "state_machine": {"action": "updated", "reason": "Public BOStateGraph installed by bo_upgrade; query.py supplies actual SQLite instances and exact event-bound runtime frames. User U05 explicitly selected ordinary Python functions: app/workflow.py contains ordinary business functions without stategraph imports; explicit source_moves retain prior probe and whitebox identities. Declaration now describes observed behavior, public graph exports observe mode. SQLite writer transaction owns shared printer occupancy and queue; all transaction snapshots checked with the project shared-resource extension."},
        "abstraction": {"action": "updated", "reason": "Stable business IDs retain round-01 meaning; all implementation functions including transaction callbacks bind to current source, static auxiliaries remain under analysis details."},
        "probes": {"action": "updated", "reason": "Commit probes follow SQLite commit. Actual parameters, predicate flags, wait reasons and effect IDs are compared independently; overridden checker functions are attributed to the actual worker/callback, not falsely to the default checker."}}, "excluded_symbols": excluded, "requirement_changes": {r["id"]: "Only R11 mode choice and new R12/R13 maintenance semantics are authorized by U05/U06; prior expectations preserved. New expectations authored before implementation; only whitebox rule.source and probe.symbol rebind through reviewed one-to-one source_moves; assertions, phase, node and parameters preserved." for r in current["intent"]["requirements"]}, "limits": ["No real printer or mesh parsing", "Local synthetic actor identities, not authentication", "No automatic retry of interrupted checks after process crash; persisted waiting/printing ownership can resume", "No inferred causal edges or arbitrary natural-language equivalence"]}
    review["source_moves"] = []
    for key, symbol in base["structure"]["symbols"].items():
        if symbol["path"] != "bo_stategraph/workflow.py":
            continue
        new_key = "app/workflow.py::" + symbol["symbol"]
        if new_key not in current["structure"]["symbols"]:
            raise ValueError("Moved symbol absent: " + new_key)
        review["source_moves"].append({"from": {"path": symbol["path"], "symbol": symbol["symbol"]},
            "to": {"path": "app/workflow.py", "symbol": symbol["symbol"]},
            "reason": "U05 requests ordinary Python business implementation and observe modes; retain this exact function/class identity and all protected observations while moving its source location."})
    (change / "review.json").write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"candidate_id": current["id"], "class_containers_classified": len(excluded), "source_moves": len(review["source_moves"]), "structural_errors": impact["errors"]}))
