"""Independent maintenance exercises; fixed expected outcomes live in acceptance.json."""
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
import json
import sqlite3
import threading
from app.store import Store
from app.workflow import Workflow


def exercise(case, lab):
    w = lab.w
    flag = lambda: next(p['maintenance'] for p in lab.store.snapshot()['printers'] if p['id'] == 'P1')
    if case == 'maintenance_flow':
        a, b = lab.submit(), lab.submit(); lab.approve(a); lab.approve(b)
        seq_b = lab.row(b)['queue_seq']
        w.set_maintenance('admin', 'P1', True)
        continues = lab.state(a) == 'printing' and lab.owner() == a
        c = lab.submit(); lab.approve(c)
        seq_c = lab.row(c)['queue_seq']
        passed = all(x['state'] == 'passed' for x in lab.store.snapshot()['activities'] if x['run_id'] == c)
        queued = lab.state(c) == 'queued'; reason = lab.row(c)['reason']
        w.confirm(a, 'complete'); empty = lab.owner() is None
        w.set_maintenance('admin', 'P1', False)
        first = lab.owner() == b and lab.state(c) == 'queued'
        preserved = lab.row(b)['queue_seq'] == seq_b and lab.row(c)['queue_seq'] == seq_c and seq_b < seq_c
        w.confirm(b, 'complete')
        return dict(running_continues=continues, new_checks_passed=passed, new_queued=queued, wait_reason=reason, after_complete_empty=empty, order_preserved=preserved, first_resumes=first, second_resumes=lab.owner() == c)
    if case == 'maintenance_auth':
        denied, denied_exit = [], []
        before = lab.store.snapshot(); revisions = len(lab.store.history())
        for actor in ('alice', 'bob', 'carol', 'unknown'):
            try: w.set_maintenance(actor, 'P1', True)
            except PermissionError: denied.append(actor)
        unchanged = lab.store.snapshot() == before and len(lab.store.history()) == revisions
        w.set_maintenance('admin', 'P1', True); enabled = flag() == 1
        for actor in ('alice', 'bob'):
            try: w.set_maintenance(actor, 'P1', False)
            except PermissionError: denied_exit.append(actor)
        enabled = enabled and flag() == 1
        w.set_maintenance('admin', 'P1', False)
        return dict(denied=denied, denied_exit=denied_exit, no_denied_writes=unchanged, admin_enabled=enabled, admin_disabled=flag() == 0)
    if case == 'maintenance_scope':
        w.set_maintenance('admin', 'P1', True)
        a = lab.submit(); b = lab.submit(printer='P2', material='ABS'); lab.approve(a); lab.approve(b)
        return dict(p1_waits=lab.state(a) == 'queued' and lab.owner() is None, p2_prints=lab.state(b) == 'printing' and lab.owner('P2') == b)
    if case == 'maintenance_restart':
        w.set_maintenance('admin', 'P1', True); a = lab.submit(); lab.approve(a, expires=200000)
        fresh = Workflow(Store(lab.store.path, []), lab.port, lambda: lab.now)
        persisted = flag() == 1
        lab.now = 100000; fresh.schedule()
        no_timeout = flag() == 1 and lab.owner() is None
        fresh.set_maintenance('admin', 'P1', False)
        return dict(persists=persisted, no_timeout=no_timeout, manual_exit_starts=lab.owner() == a)
    if case == 'maintenance_approval':
        a, b, c = lab.submit(), lab.submit(), lab.submit()
        lab.approve(a); grant = lab.approve(b); lab.approve(c); sequence = lab.row(b)['queue_seq']
        w.set_maintenance('admin', 'P1', True); w.revoke(grant); w.confirm(a, 'complete')
        w.set_maintenance('admin', 'P1', False)
        blocked = lab.state(b) == 'blocked'; later = lab.owner() == c
        lab.approve(b, 'carol'); w.confirm(c, 'complete')
        return dict(invalid_stays_blocked=blocked, valid_later_starts=later, restored_order=lab.owner() == b and lab.row(b)['queue_seq'] == sequence)
    if case == 'maintenance_cancel':
        a, b = lab.submit(), lab.submit(); lab.approve(a); lab.approve(b)
        w.set_maintenance('admin', 'P1', True); w.cancel(a)
        holds = lab.state(a) == 'stopping' and lab.owner() == a
        w.confirm(a, 'stop'); released = lab.owner() is None
        blocks = lab.state(b) == 'queued' and flag() == 1
        w.set_maintenance('admin', 'P1', False)
        return dict(stopping_holds=holds, confirm_releases=released, maintenance_still_blocks=blocks, exit_starts=lab.owner() == b)
    if case == 'maintenance_race':
        a = lab.submit()
        def grant(c):
            run = c.execute('SELECT * FROM runs WHERE id=?', (a,)).fetchone()
            c.execute('INSERT INTO approvals VALUES(?,?,?,?,?,?,0)', ('race-grant', run['task_id'], run['version'], 'P1', 'bob', 500))
        lab.store.change('fixture_eligible', grant)
        barrier = threading.Barrier(2)
        def race(maintenance):
            other = Workflow(Store(lab.store.path, []), lab.port, lambda: lab.now)
            barrier.wait(5)
            return other.set_maintenance('admin', 'P1', True) if maintenance else other.schedule()
        with ThreadPoolExecutor(max_workers=2) as pool:
            list(pool.map(race, (False, True)))
        with closing(sqlite3.connect(lab.store.path)) as c:
            snapshots = [json.loads(row[0]) for row in c.execute('SELECT snapshot FROM history ORDER BY revision')]
        seen, safe = set(), True
        for snap in snapshots:
            for effect in snap['effects']:
                if effect['id'] in seen or effect['kind'] != 'start': continue
                printer = next(p for p in snap['printers'] if p['id'] == effect['printer_id'])
                safe = safe and printer['maintenance'] == 0
                seen.add(effect['id'])
        return dict(maintenance_on=flag() == 1, serialized_start=safe, capacity_ok=sum(r['state'] == 'printing' for r in lab.store.snapshot()['runs']) <= 1)
    raise KeyError(case)
