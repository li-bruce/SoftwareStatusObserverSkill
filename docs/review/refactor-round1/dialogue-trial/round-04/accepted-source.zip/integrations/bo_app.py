"""Project adapters for the unchanged public core and full stategraph viewer."""
import copy
import json
from pathlib import Path
import threading
import time
from app.store import Store
from app.ports import EventPort
from bo_stategraph import BOStateGraph, bo_export_view
from bo_stategraph.query import bo_machine, bo_authority, bo_runtime_frames
from app.workflow import Workflow
from observer_runtime.behavior_model import capture, check
from observer_runtime.recording_session import Recordings
from observer_runtime.view_preferences import Preferences, PreferenceConflict
from integrations.bo_capture import BOCapture

ROOT = Path(__file__).resolve().parents[1]

class BOApplication:
    def __init__(self, database, mode="on"):
        self.model = json.loads((ROOT / "behavior.json").read_text(encoding="utf-8"))
        self.manifest = capture(ROOT, self.model)
        self.sources = {p: (ROOT / p).read_text(encoding="utf-8-sig") for p in self.model["source_files"]}
        self.store = Store(str(database), json.loads((ROOT / "config/printers.json").read_text()), self.manifest["build_id"], json.loads((ROOT / "config/studio.json").read_text())["administrators"])
        retention = json.loads((ROOT / "bo_stategraph/config/retention.json").read_text())
        self.collector = BOCapture(self.model, self.manifest["build_id"], mode,
            capacity=retention["events_in_memory"], rotate_bytes=retention["jsonl_rotate_bytes"], path=ROOT / "data/events.jsonl")
        self.port = EventPort(self.collector.bo_record if mode != "off" else None)
        self.workflow = Workflow(self.store, self.port)
        self.graph = BOStateGraph(self.model, build_id=self.manifest["build_id"], mode="observe", instance_provider=lambda: bo_machine(self.store, self.manifest["build_id"]))
        self.lock = threading.RLock()
        self.preferences = Preferences(ROOT, "studio-print-trial")
        self.expired_seen = set()
        self.records = Recordings(ROOT / "data/public-recordings", self.bo_view, self.sources,
            action_nodes={"submit": "submit", "approve": "approval-change", "role": "approval-change", "cancel": "cancel", "confirm": "printer-stopped", "maintenance": "maintenance"},
            scope_setter=self.collector.bo_scope, event_source=self.collector, max_events=retention["saved_recording_max_events"])

    def bo_view(self):
        with self.lock:
            machine = bo_machine(self.store, self.manifest["build_id"])
            with self.collector.lock:
                events = copy.deepcopy(self.collector.events)
                health = {**self.collector.bo_health(), "port_errors": self.port.errors}
            return {"model": self.model, "manifest": self.manifest,
                "binding_status": check(ROOT, self.model, self.manifest),
                "authority": bo_authority(machine),
                "machine": machine, "instances": self.graph.bo_instances(machine),
                "events": events, "health": health, "historical": False, "busy": False,
                "runtime_frames": bo_runtime_frames(self.store, self.manifest["build_id"], events),
                "layout_id": "studio-print-trial", "available_cases": ["live"],
                "scope": "本地模拟；每条事件绑定原始事务修订的状态快照；全局打印机由项目扩展验证，图操作不执行业务命令。"}

    def bo_export(self):
        return bo_export_view(self.bo_view(), mode="observe", graph=self.graph)

    def bo_preferences(self, value=None):
        return self.preferences.read() if value is None else self.preferences.save(value)

    def bo_record(self, action, values=None):
        values = values or {}
        return self.records.start(values.get("label", "打印调度记录"), values.get("scope")) if action == "start" else self.records.stop()

    def bo_command(self, command):
        with self.lock:
            values = dict(command)
            name = values.pop("command")
            methods = {"submit": self.workflow.submit, "approve": self.workflow.approve, "revoke": self.workflow.revoke, "role": self.workflow.set_role, "maintenance": self.workflow.set_maintenance, "cancel": self.workflow.cancel, "confirm": self.workflow.confirm, "schedule": self.workflow.schedule}
            if name not in methods:
                raise ValueError("unknown command")
            try:
                result = {"result": methods[name](**values)}
            except Exception as error:
                self.records.command(name, values, error=error)
                raise
            self.records.command(name, values, result={"ok": True})
            return result

    def bo_tick(self):
        with self.lock:
            now = time.time()
            expired = {a["id"] for a in self.store.snapshot()["approvals"] if not a["revoked"] and a["expires"] <= now}
            if expired - self.expired_seen:
                self.workflow.schedule()
            self.expired_seen = expired

    def bo_demo(self):
        with self.lock:
            return self.bo_seed()

    def bo_seed(self):
        if self.store.snapshot()["runs"]:
            return {"existing": True}
        self.bo_record("start")
        w = self.workflow
        for actor in ("bob", "carol"):
            for printer in ("P1", "P2"):
                w.set_role(actor, printer, True)
        end = time.time() + 7200
        a = w.submit("alice", "P1", [120, 90, 60], "PLA", {"layer_mm": 0.2}, "任务-A")
        b = w.submit("alice", "P1", [80, 70, 50], "PLA", {"layer_mm": 0.2}, "任务-B")
        c = w.submit("dana", "P1", [50, 50, 50], "PLA", {}, "任务-C")
        w.approve(a, "bob", end)
        first = w.approve(b, "bob", end)
        w.approve(b, "carol", end)
        w.approve(c, "bob", end)
        w.revoke(first)
        w.set_role("carol", "P1", False)
        w.confirm(a, "complete")
        w.set_role("carol", "P1", True)
        w.confirm(c, "complete")
        new = w.submit("alice", "P1", [90, 70, 50], "PLA", {"layer_mm": 0.25}, "任务-B")
        w.approve(new, "bob", end)
        w.cancel(b)
        w.confirm(b, "stop")
        p2 = w.submit("dana", "P2", [250, 200, 100], "ABS", {}, "任务-D")
        w.approve(p2, "carol", end)
        w.confirm(new, "complete")
        # Actual calls demonstrate admission during maintenance and manual FIFO recovery.
        w.set_maintenance("admin", "P1", True)
        m1 = w.submit("alice", "P1", [50, 50, 50], "PLA", {}, "维护任务-1")
        m2 = w.submit("dana", "P1", [40, 40, 40], "PLA", {}, "维护任务-2")
        w.approve(m1, "bob", end)
        w.approve(m2, "bob", end)
        try:
            w.set_maintenance("bob", "P1", False)
        except PermissionError:
            pass  # Intentional rejected command; actual denied decision is captured.
        w.set_maintenance("admin", "P1", False)
        record = self.bo_record("stop")
        info = {"runs": {"A": a, "B1": b, "B2": new, "C": c, "D": p2, "M1": m1, "M2": m2}, "recording": record["id"], "meaning": "Actual synthetic function calls persisted in SQLite; not fabricated events or real printer execution"}
        (ROOT / "data/demo.json").write_text(json.dumps(info, ensure_ascii=False, indent=2), encoding="utf-8")
        return info
