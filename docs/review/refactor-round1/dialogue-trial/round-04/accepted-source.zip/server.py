"""Loopback-only developer view and separate local operator API."""
import argparse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import threading
from urllib.parse import urlparse, parse_qs
from integrations.bo_app import BOApplication, ROOT, PreferenceConflict

def serve(port=0, database="data/studio-maintenance.sqlite", demo=False):
    app = BOApplication(ROOT / database)
    if demo:
        app.bo_demo()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def reply(self, value, status=200):
            body = json.dumps(value, ensure_ascii=False).encode()
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            parsed = urlparse(self.path)
            q = parse_qs(parsed.query)
            try:
                if parsed.path == "/api/view":
                    self.reply(app.bo_view())
                elif parsed.path == "/api/stategraph":
                    self.reply(app.bo_export())
                elif parsed.path == "/api/preferences":
                    self.reply(app.bo_preferences())
                elif parsed.path == "/api/recordings":
                    self.reply(app.records.list())
                elif parsed.path.startswith("/api/recordings/"):
                    ident = parsed.path.rsplit("/", 1)[-1]
                    self.reply(app.records.get(ident))
                elif parsed.path == "/api/source":
                    path = q.get("path", [""])[0]
                    record = app.records.get(q["recording"][0]) if q.get("recording") else None
                    self.reply({"path": path, "build_id": record["build_id"] if record else app.manifest["build_id"], "source": (record["sources"] if record else app.sources)[path]})
                elif parsed.path == "/control":
                    self.reply({"instructions": "本地合成操作者：使用 python main.py command 或 POST /operator/command；运行图只读。具体示例见项目 README。", "stategraph": "/api/stategraph", "shared_resource_scope": "two globally shared printers; not per-run pools", "replay_limit": "exact captured event IDs bind to committed SQLite revisions"})
                elif parsed.path == "/" or (len(parsed.path.split("/")) == 2 and (ROOT / "static/graph" / parsed.path[1:]).is_file()):
                    name = "index.html" if parsed.path == "/" else parsed.path[1:]
                    body = (ROOT / "static/graph" / name).read_bytes()
                    self.send_response(200)
                    self.send_header("Content-Type", {".html": "text/html", ".js": "text/javascript", ".css": "text/css"}.get(Path(name).suffix, "text/plain") + "; charset=utf-8")
                    self.send_header("Content-Length", str(len(body)))
                    self.end_headers(); self.wfile.write(body)
                else:
                    self.reply({"error": "not_found"}, 404)
            except (ValueError, KeyError, OSError) as exc:
                self.reply({"error": str(exc)}, 400)

        def do_POST(self):
            try:
                # Local tool only. Reject cross-origin browser writes; no CORS allowance.
                origin = self.headers.get("Origin")
                if origin and origin != "http://" + self.headers.get("Host", ""):
                    self.reply({"error": "cross_origin_denied"}, 403); return
                size = int(self.headers.get("Content-Length", "0"))
                if size > 128000:
                    self.reply({"error": "body_too_large"}, 413); return
                data = json.loads(self.rfile.read(size) or b"{}")
                if self.path == "/api/preferences":
                    self.reply(app.bo_preferences(data))
                elif self.path == "/api/recordings/start":
                    self.reply(app.bo_record("start", data))
                elif self.path == "/api/recordings/stop":
                    self.reply(app.bo_record("stop"))
                elif self.path == "/operator/command":
                    self.reply(app.bo_command(data))
                else:
                    self.reply({"error": "not_found"}, 404)
            except (RuntimeError, PreferenceConflict) as exc:
                self.reply({"error": str(exc)}, 409)
            except (ValueError, KeyError, TypeError, PermissionError, OSError) as exc:
                self.reply({"error": str(exc), "type": type(exc).__name__}, 400)

    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    url = "http://127.0.0.1:" + str(httpd.server_port)
    (ROOT / "data/server.json").write_text(json.dumps({"url": url, "port": httpd.server_port, "database": str(ROOT / database)}))
    stop = threading.Event()
    def timer():
        while not stop.wait(0.25):
            app.bo_tick()
    threading.Thread(target=timer, daemon=True, name="approval-expiry").start()
    print(url, flush=True)
    try:
        httpd.serve_forever()
    finally:
        stop.set()
        app.records.close()
        httpd.server_close()

if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--port", type=int, default=0)
    p.add_argument("--db", default="data/studio-maintenance.sqlite")
    p.add_argument("--demo", action="store_true")
    a = p.parse_args()
    serve(a.port, a.db, a.demo)
