# 工作室 3D 打印任务工具

Python 标准库 + SQLite；两台本地模拟打印机。业务由普通 Python 函数决定，状态图与监控观察跟随；development_mode 和 execution_mode 均为 observe。开发者运行图使用冻结 Skill 的公共 BOStateGraph 核心和完整查看器。可以从业务节点下钻到函数、参数、审批判断和源码，并回放实际事件对应的事务状态。

本项目是独立 AI Skill 接入试用，需求由主会话模拟。检查结果不代表真人易用性或真实打印机验证。

## 启动

在本目录的 PowerShell 执行：

```powershell
$trialPython = '../SoftwareStatusObserverSkill/.venv/Scripts/python.exe'
& $trialPython -X utf8 -B server.py --demo --port 8897
```

打开 http://127.0.0.1:8897 。端口被占用时传 `--port 0`，地址见终端和 `data/server.json`。默认数据库为 `data/studio-maintenance.sqlite`。已有数据不会被 demo 覆盖；重现新演练使用 `--db data/new-demo.sqlite`。

## 从图定位行为

1. 初始只有五个业务节点。选中后点“展开”，或双击画布节点，进入同色区域；“分析细节”显示静态辅助函数。
2. 搜索 `grant_matches`，选中后点“参数值”“源码”，查看匹配任务、打印机、版本、非自批、权限、撤销、时钟等实际值。静态连线不代表已经调用。
3. 从“选择记录”选演练，播放粒度切为“逐个原始事件”。选择“队列与等待”事件，再下钻 `Workflow.schedule`，查看 `no_valid_approval`、`printer_busy` 和原始 `queue_seq`。
4. 选择取消和设备确认事件，比较全局 P1 的 holder/available 变化。停止请求保留占用，确认停止后才释放。状态/活动/资源变化显示在“本步变化”；“定位”回到对应图节点。
5. “状态机”显示 11 个生命周期状态；“并发与资源”显示两项真实检查与全局打印机。名称、批注、核心标记和布局保存在 `bo_stategraph/config/views/local.json`。

合成演练事件覆盖替代审批、权限撤销/恢复、跳过阻塞任务、版本变化、取消和停止确认，以及维护期间入队、拒绝非管理员和手动恢复。每个事件的帧取自该事件的 SQLite 事务修订；开始前不存在的运行不会出现在早期回放。两台打印机全局各一份，不按运行复制资源池。

## 本地操作入口

图操作只读。CLI 和 `/operator/command` 是独立的合成本地操作入口。录制交互时通过正在运行服务的 `/operator/command` 操作，事件来自同一进程；CLI 是另一个 producer，不把跨进程事件拼接到当前记录：

```powershell
& $trialPython -X utf8 -B main.py show
& $trialPython -X utf8 -B main.py command '{"command":"submit","submitter":"alice","printer_id":"P1","dimensions":[80,60,40],"material":"PLA","parameters":{"layer_mm":0.2}}'
```

submit 返回 run_id。approve 需要 run_id、approver、expires（Unix 秒）；role 需要 actor、printer_id、active；cancel 只取消指定 run_id；confirm 需要 run_id 和 kind（complete/stop）。已启动服务器每 250ms 重新发现到期审批；获取设备前仍在同一写事务内读取当前时钟。CLI 独立执行时可调用 schedule。

尺寸为提交的毫米三边：正有限数，等于上限通过。P1 支持 PLA、200×200×200；P2 支持 PLA/ABS、300×250×250。能力配置见 config/printers.json。模型文件解析、真实打印驱动、身份认证与多租户不在范围内。

## 打印机维护

工作室管理员为 `config/studio.json` 中初始化的 admin，独立于审批角色。两种开关操作都在同一 SQLite 事务内检查 administrators 表。业务函数位于 app/workflow.py；状态声明保留作观察合同，不驱动执行。普通提交者和审批人会收到 PermissionError，维护状态不变。

```powershell
& $trialPython -X utf8 -B main.py command '{"command":"maintenance","actor":"admin","printer_id":"P1","enabled":true}'
& $trialPython -X utf8 -B main.py command '{"command":"maintenance","actor":"admin","printer_id":"P1","enabled":false}'
```

维护期间继续提交、检查、审批和排队，只阻止开始打印。已打印任务不中断；完成或停止确认仍释放占用，后续任务等待手动退出维护。维护标记持久化、不会自动到期，P1 与 P2 分别生效。退出维护重新按原 queue_seq 和当前审批资格调度；审批到期或撤销的任务仍受原规则约束。

图中搜索“管理员手动维护”“工作室管理员资格”，查看真实 actor、allowed、maintenance；资源节点显示维护和占用。演练记录中的维护等待/退出事件保留完整 before/after。身份仍是本地合成操作者，本项目未实现网络登录认证。

## 验证与开发

```powershell
& $trialPython -X utf8 -B tooling/gate.py check
& $trialPython -X utf8 -B tests/test_project.py
& ./tooling/browser_check.ps1
& $trialPython -X utf8 -B tooling/mutation_check.py
```

修改后由 AI 执行 build_model、scan、inspect、内部 review、verify、accept、check。继续已有 active change，不通过重建基线隐藏漂移。全部证据和复现命令见 [review/README.md](review/README.md)。

内存事件和日志轮转使用 bo_stategraph/config/retention.json；保存记录不随 UI 缓存清理。关闭/故障采集不改变业务结果。项目没有声称零开销、任意崩溃后恢复正在检查的线程，或从事件顺序证明因果关系。
