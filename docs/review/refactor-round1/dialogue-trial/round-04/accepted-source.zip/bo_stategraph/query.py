"""Project adapter: one authoritative SQLite snapshot feeds public core and viewer.

Shared printers remain a single global collection, never per-run resource pools.
No execution-graph protocol is claimed for this unsupported shared-resource scope.
"""
import math
from bo_stategraph.project_constraints import validate_instances


def bo_finite(value):
    if isinstance(value, float) and not math.isfinite(value):
        return {"invalid_number": str(value)}
    if isinstance(value, list):
        return [bo_finite(v) for v in value]
    if isinstance(value, dict):
        return {k: bo_finite(v) for k, v in value.items()}
    return value


def bo_machine(store, build_id, snapshot=None, revision=None):
    if snapshot is None:
        history = store.history()
        snapshot = history[-1]["snapshot"] if history else store.snapshot()
        revision = history[-1]["revision"] if history else 0
    builds = {r["run_id"]: r["build_id"] for r in snapshot.get("run_builds", [])}
    configurations = []
    for run in snapshot["runs"]:
        acts = [a for a in snapshot["activities"] if a["run_id"] == run["id"]]
        configuration = {
            "attempt": run["id"], "param_version": run["version"],
            "phase": run["state"], "state_revision": revision,
            "context": {**run, "printing": run["parameters"], "checks": acts},
            "activities": {"check-" + a["name"]: {"passed": "succeeded", "failed": "rejected", "error": "failed"}.get(a["state"], a["state"]) for a in acts},
            "check_results": acts, "journal": [],
            "run_build_id": builds.get(run["id"]),
            "source_status": "current" if builds.get(run["id"]) == build_id else "unknown_or_other_build",
        }
        configurations.append(bo_finite(configuration))
    return {"configurations": configurations,
            "current": configurations[-1]["phase"] if configurations else None,
            "journal": [], "state_revision": revision,
            "shared_resources": {"printer." + p["id"]: {**bo_finite(p), "capacity": 1, "available": 0 if p["occupant"] or p.get("maintenance", 0) else 1, "holder": p["occupant"]} for p in snapshot["printers"]},
            "project_constraints": {"scope": "global SQLite occupancy plus parallel checks", "errors": validate_instances(snapshot)}}


def bo_authority(machine, attempt=None):
    configs = machine["configurations"]
    cfg = next((c for c in configs if c["attempt"] == attempt), None) if attempt is not None else configs[-1] if configs else None
    return {"entity": "studio", "state": cfg["phase"] if cfg else None,
            "basis": {"epoch": machine["state_revision"], "param_version": cfg["param_version"] if cfg else 0},
            "parameters": {"attempt": attempt if attempt is not None else cfg["attempt"] if cfg else None, "param_version": cfg["param_version"] if cfg else 0}, "effects": []}


def bo_snapshot_at(store, build_id, revision, attempt=None):
    """Exact committed frame; a missing revision is a gap, never nearest/final fallback."""
    frames = [f for f in store.history() if f["revision"] == revision]
    if len(frames) != 1:
        raise ValueError("authoritative revision unavailable: " + str(revision))
    machine = bo_machine(store, build_id, frames[0]["snapshot"], revision)
    authority = bo_authority(machine, attempt)
    machine["current"] = authority["state"]
    return {"machine": machine, "authority": authority}


def bo_runtime_frames(store, build_id, events):
    """Bind captured events only to their original committed transaction snapshots."""
    history = {f["revision"]: f["snapshot"] for f in store.history()}
    frames = []
    for event in events:
        revision = event["revision"]
        if revision not in history or event["build_id"] != build_id:
            continue
        machine = bo_machine(store, build_id, history[revision], revision)
        authority = bo_authority(machine, event["attempt"])
        machine["current"] = authority["state"]
        frames.append({"event_id": event["id"], "run_id": event["run_id"], "build_id": build_id,
                       "revision": revision, "machine": machine, "authority": authority})
    return {"schema": "stategraph-runtime-frames/v1", "frames": frames}
