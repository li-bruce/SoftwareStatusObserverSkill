# 本项目开发约定

仅在本目录开发。使用只读冻结 Skill：`../SoftwareStatusObserverSkill/.validation/refactor-trial/candidate-7/business-observer/SKILL.md`；不修改原 Skill、其他示例或已有服务。需求方为主会话模拟，不是真人测试。

读取 `discovery.json`、`intent.json` 和 `review/README.md`。U05/U06 明确要求普通 Python 函数实现，使用 development_mode=observe、execution_mode=observe；状态网观察跟随，不驱动业务，维护独立 `bo_stategraph/`、源码映射、实际参数和运行证据。未决行为不能用实现框架授权代定。

实际解释器：`../SoftwareStatusObserverSkill/.venv/Scripts/python.exe`。以下命令在本项目目录执行；传给冻结脚本的 root 必须是本项目绝对路径。

```powershell
& ../SoftwareStatusObserverSkill/.venv/Scripts/python.exe -B tooling/gate.py begin --change .stategraph/maintenance-02 --request '管理员手动维护与普通函数实现；已建立，继续本变更' --requirements R11 R12 R13
& ../SoftwareStatusObserverSkill/.venv/Scripts/python.exe -B ../SoftwareStatusObserverSkill/.validation/refactor-trial/candidate-7/business-observer/scripts/bo_sync.py scan --root 'C:/Users/Lvi_P/Documents/Work/CF/平台软著/stategraph-refactor-trial-20261022'
& ../SoftwareStatusObserverSkill/.venv/Scripts/python.exe -B tooling/gate.py inspect
& ../SoftwareStatusObserverSkill/.venv/Scripts/python.exe -B tooling/gate.py verify
& ../SoftwareStatusObserverSkill/.venv/Scripts/python.exe -B tooling/gate.py accept
& ../SoftwareStatusObserverSkill/.venv/Scripts/python.exe -B tooling/gate.py check
```

已有 active change 时继续它，不重建基线。每批编辑后读取 `.stategraph/maintenance.json`，处理图、探针、状态和源码差异；最终交付正常入口是 `tooling/gate.py check`。正常 check 已接入 architecture_guard；公共核心和完整 viewer 由 bo_upgrade 安装，项目适配器不得替换其协议。
