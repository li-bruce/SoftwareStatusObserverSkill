"""Project extension: global printers, not per-run resource pools."""
def validate_instances(snapshot: dict) -> list:
    """Project extension: shared printer capacity, ALL checks, and run identities.

    The frozen activity-graph checker supports per-run resource pools only.
    These shared resources are checked here, against the actual SQLite snapshot.
    """
    errors = []
    runs = {r["id"]: r for r in snapshot["runs"]}
    for p in snapshot["printers"]:
        running = [r for r in runs.values() if r["printer_id"] == p["id"] and r["state"] in ("printing", "stopping")]
        if len(running) > 1:
            errors.append("printer capacity exceeded: " + p["id"])
        if {r["id"] for r in running} != ({p["occupant"]} if p["occupant"] else set()):
            errors.append("occupancy differs from running states: " + p["id"])
    for r in runs.values():
        acts = [a for a in snapshot["activities"] if a["run_id"] == r["id"]]
        if sorted(a["name"] for a in acts) != ["material", "size"]:
            errors.append("missing parallel activity: " + r["id"])
        if r["state"] in ("queued", "blocked", "printing", "stopping", "completed") and any(a["state"] != "passed" for a in acts):
            errors.append("ALL check barrier violated: " + r["id"])
        if r["state"] in ("queued", "blocked", "printing", "stopping", "completed") and r["queue_seq"] is None:
            errors.append("missing queue identity: " + r["id"])
    return errors
