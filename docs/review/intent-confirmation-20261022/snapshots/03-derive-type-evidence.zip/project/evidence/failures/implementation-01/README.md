# 首次业务检查失败记录

命令：`python -m unittest tests.test_project -v`。
观察到：5 个测试执行，1 个业务断言失败、5 个清理错误。

业务断言：create 场景输入误写为 processing，而编码前已保存的独立预期是 collection。实际断言为 `AssertionError: 'processing' != 'collection'`。修复场景输入为既定 collection，未修改 acceptance 或预期。

资源错误：SQLite 的连接上下文只提交/回滚，不自动关闭连接；Windows 清理测试库报 `PermissionError: [WinError 32]`，并有 ResourceWarning。修复业务连接 __exit__，以及独立测试读取器的关闭逻辑。失败时的两个源文件随本目录保留。

另有环境问题：bo_upgrade.py 对相对根目录调用 Path.resolve，在当前环境得到重复项目目录，报 project root does not exist。改传绝对根目录后成功，公共工具未修改。
