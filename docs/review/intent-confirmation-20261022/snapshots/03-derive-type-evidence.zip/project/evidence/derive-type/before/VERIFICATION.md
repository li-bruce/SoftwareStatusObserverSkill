# 最终验收与证据索引

日期：2026-10-22，Asia/Shanghai。需求来源是四轮经授权的模拟需求方对话；随后一轮监控接入审查未改变业务规则。试用使用本机安装的 business-observer，共享 Python 核心与查看器原件保持其运行清单哈希。

## 当前交付

- 程序：http://127.0.0.1:8870/
- 运行图：http://127.0.0.1:8870/graph
- 运行环境：Windows，Python 3.13.13，标准库 SQLite/HTTP。
- 当前数据库：`data/final.sqlite3`；已验证的服务 PID 为 28596，启动记录见 `evidence/app-server-final.json`。这是本次时点证据，不保证机器重启后服务仍存在。
- 代码构建：`a930599fbf9839f7b4386aef00cdcdd367ea1790870277aa26554ece5e3f6a8e`。
- 接受候选：`a3e3017c0937bda073d0ebb6efd164811db3b96a6250c5e843be5d4f46a43650`。
- 当前接受回执：`.stategraph/runtime-frames/accepted.json`。初版 `.stategraph/initial/`、旧数据库、旧录制和失败日志全部保留。

## 分项结果

| 范围 | 结果 | 证据与限制 |
| --- | --- | --- |
| 实现映射 | 通过 | 10 个 Python 实现文件、13 个绑定源文件、28 个图节点；44 个辅助符号内部分类。87 个实际值见证、1560 项逐实例字段对照。只支持已登记范围。 |
| 状态约束 | 通过 | checking → completed/rejected、定义加载和公开导出校验。业务无活动汇合、资源调度或恢复流程，不把这些未适用特性计为通过。 |
| 独立业务预期 | 通过 | 25 场景 × on/off/fault = 75 次场景运行，222/222 项业务断言；初始 cases、acceptance、mapping 哈希未变。 |
| 白盒接线 | 通过，但有流程偏差 | 5 条规则、17 项检查；首版约束在实现后补写，不能声称全部测试预先注册。 |
| 项目回归 | 通过 | 17 个 unittest 方法，包含事务回滚、并发、撤权顺序、观察关闭/故障、录制及完整状态帧。最终 gate 内运行结果在 `.stategraph/runtime-frames/checks/test-0.json`。 |
| 采集异常隔离 | 通过 | 关闭、接收端故障、载荷构造故障、快照故障；有界队列丢弃、历史淘汰记录缺口。非无限负载或生产性能证明。 |
| Web 开关 | 通过 | 关闭后图及图 API 为 404，业务创建/API/Python 查询继续；恢复后图可读。没有声称核心包剔除验证。 |
| 故意业务错误 | 被检测 | 将两端 AND 改成 OR 的隔离函数实际放行单端权限，原拒绝断言发现错误；不是仅靠语法或指纹检测。 |
| 漏同步门禁 | 被检测 | 独立副本未改时 gate=0；只改 domain 源码而不更新模型 gate=1，报静态投影过时；新增 app/unregistered.py gate=1，明确报未登记文件。 |
| 浏览器操作 | 通过所列任务 | 创建、派生、配置不传送、执行后 JSON 改变而 result 不变、单端权限拒绝、真实记录/回放/源码定位。320 像素页面真实完成创建，1280 像素正常页面完成主要操作。不是人工易用性研究。 |

机器结果：`evidence/runtime-frames/verify-final.json`、`gate-final.json`、`gate-rehearsal-final.json`。故意遗漏的详细输出在 `evidence/gate-rehearsal/78c32e6a7a354b55afdacbdeb4448029/report.json`。

## 状态帧补测与真实回放

先冻结 `tests/frame_expectations.json` 和四项回归，再在旧实现执行出两项失败、两项错误；代码、测试原件、预期哈希与日志在 `evidence/runtime-frames/before/` 和 `frozen-regressions.json`。修复后的测试仅纠正过 `bo_digest` 的导入位置，未改冻结预期或断言。

每个核心探针由调用线程在原位置读取实际事务行和局部上下文。成功提交前冻结事务内数据，提交成功后才发出完成事件；拒绝的帧含实际拒绝状态和空效果 ID。失败的提交不会发布成功帧。状态修订是操作生命周期数据库修订，关键上下文和目标输入值另随每个事件不可变保存，不能把同一修订误解为局部变量完全没有变化。

公开帧覆盖对应操作及选定目标输入；不包含整个数据库、所有局部变量或推断的因果边。帧的事件、运行、构建、修订身份与原事件一致。超出保留范围明确报告缺口，不按最终状态或事件顺序补造。

真实浏览器保存记录 `799093103f7147828203c6e54115fee5`，页面选择项为“19:23:02 · 26 个事件”：

- 第 11 步权限判断：`checking`，操作者 alice，源/目标权限均 true。
- 第 13 步结果记录：`completed`，目标输入修订从 1 变为 2，JSON 从 `{"old":true}` 变成采集 A 值。
- 第 18 步权限判断：仍是 `checking`，操作者 dave，source_allowed=true、target_allowed=false、allowed=false，可直接定位 `app/domain.py::check_connect`。
- 第 19 步结果记录：`rejected`，reason=connect_denied，effect_id 为空，目标未再次改变。

26 个事件与 26 个帧一一对应，记录 gaps=[]；最终公开导出和保存记录中的同名帧逐项一致。HTTP 复核见 `evidence/runtime-frames/http-proof.json`，完整原件为 `view-final.json`、`export-final.json`、`recording-final.json`。浏览器截图为 `replay-checking.png`、`replay-committed.png`、`replay-rejected.png`、`replay-denied-source.png`；此前值回放与普通/窄屏截图保留于 evidence 根目录。

## 可复现操作与结论边界

启动与命令见 `README.md`。日常验收运行 `python -B -X utf8 tooling/gate.py`；完整场景运行 `python -B -X utf8 observe.py`；故意漏同步演练运行 `python -B -X utf8 tooling/rehearse_gate.py`。后续业务变更必须从当前接受候选开启新变更，保留旧预期，先记录被授权的新含义。

本次业务实现和监控修复在上述范围内通过。首版白盒约束后补的顺序偏差保留，不能追认成严格遵守 Skill 全流程。等待、恢复和取消不适用。页面及图测试属于独立 AI 使用和自动验证，不支持真人易用性、任意自然语言等价、通用 ReBAC、生产认证或性能结论。
