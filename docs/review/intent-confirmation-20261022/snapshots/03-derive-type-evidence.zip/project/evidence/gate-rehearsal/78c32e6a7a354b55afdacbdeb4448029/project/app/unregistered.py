def undocumented_operation():
    return "must be discovered"
