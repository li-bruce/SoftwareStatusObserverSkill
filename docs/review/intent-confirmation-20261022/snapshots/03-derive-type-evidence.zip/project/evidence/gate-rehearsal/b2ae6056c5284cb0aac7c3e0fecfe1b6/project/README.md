# 项目派生与 JSON 数据流转试用

已实现创建、独立派生、配置连接和手动执行。每次执行在同一 SQLite 写事务中重验当前两端 connect 权限和类型/端口规则；拒绝或数据库异常均不写目标数据。

需求来自四轮经授权的模拟需求方对话。业务规则见 `requirements.md`，逐轮原文在 `dialogue/`，最终图解见 `design.md`。本试用不是实际用户易用性研究。

## 启动与使用

只需 Python 标准库，无 pip 安装步骤。已在本机 Python 3.13 运行。先进入本目录：

```powershell
python -B -X utf8 server.py --port 8870
```

- 程序：http://127.0.0.1:8870/
- 运行图：http://127.0.0.1:8870/graph
- 第 1–4 轮设计声明图：http://127.0.0.1:8866/graph （独立设计服务；没有运行实例）

默认数据库为 `data/demo.sqlite3`。使用 `--db data/another.sqlite3` 可另建演示实例；不要删除旧库来掩盖历史结果。启动时只在空库中预置示例。当前交付进程的数据库与 PID 以 `evidence/app-server-final.json` 为准。

演示顺序：

1. 选择小林；将采集 A 的 records 连接到处理 B 的 records。配置成功后，处理 B 输入仍是原值。
2. 点击“执行一次”，查看处理 B 输入成为采集 A 的 JSON，而 result 仍为 `{"total":12}`。
3. 切换访客小王再执行，因仅有源端 connect 被拒绝；目标保持原值。
4. 选择小周，从采集 A 派生项目。新项目类型仍为采集，所有者为小周，有来源 ID，但没有数据、连接或授权副本。
5. 运行图点击“开始记录”，在程序操作，再点击“结束记录”。选择真实权限判断或提交事件，可定位节点、查看参数与源码、回放 JSON 前后预览。

用户选择器只是本地固定身份演示，不提供认证。服务仅绑定回环地址。新建项目没有自动生成的数据。

## 检查与复现

```powershell
$trialRoot = (Get-Location).Path
python -B -X utf8 -m unittest discover -s tests -v
python -B -X utf8 observe.py
python -B -X utf8 observer_runtime/change_sync.py check --root $trialRoot
python -B -X utf8 tooling/gate.py
python -B -X utf8 tooling/rehearse_gate.py
```

`observe.py` 运行预先定义的 25 场景 × 采集开启/关闭/故障三种模式，并将真实数据库和事件保存在 `evidence/runs/`。`tooling/gate.py` 检查已接受源码、模型、清单和架构；它不会偷偷重新生成或接受漂移。修改代码后的同步流程见 `AGENTS.md`。

```powershell
python -B -X utf8 observer_runtime/bo_web.py mode disabled --root $trialRoot
python -B -X utf8 observer_runtime/bo_web.py mode visible --root $trialRoot
```

关闭调试 Web 后，业务与 Python 状态查询继续可用；`--probe-mode off` 则关闭采集。两项是独立开关。这里没有声称或交付“已剔除采集器的核心包”。

## 证据与边界

最终数值与复现记录见 `VERIFICATION.md`、`evidence/runtime-frames/verify-final.json` 和 `.stategraph/runtime-frames/accepted.json`。初版的 `evidence/verify-final.json` 与 `.stategraph/initial/` 保留。失败与修复见 `FAILURES.md`；此前失败输出不会被最终成功覆盖。初始基线与独立业务预期保留，不重新 capture 初始预期。

图展示已绑定函数、选择的参数、实际判断及提交后效果。SQLite 是业务权威状态，图不模拟业务结果。初版缺少状态帧，现已修复：核心事件在发出位置读取当前事务和实际操作上下文；提交前冻结事务数据，提交成功后才发布终态帧。录制与公开导出保留相同事件帧，回放可以区分检查中、已提交、已拒绝。帧覆盖该次操作及选定目标输入，不是整个数据库历史或完整因果链。无等待/恢复业务，因此相应交互任务不适用。

个人布局、名称、批注和核心标记保存在 `bo_stategraph/config/views/local.json`。保留原有标记；共享项目时排除此个人文件及 `data/`。

