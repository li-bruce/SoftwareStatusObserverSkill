"""Save the development assistant's explicit scope review for the current candidate."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from observer_runtime.sync_config import config,snapshot
from observer_runtime.change_sync import impact
from observer_runtime.sync_io import write


def main():
    cfg=config(ROOT,'sync.json');active=json.loads((ROOT/'.stategraph/active.json').read_text(encoding='utf-8'))
    change=ROOT/active['change'];base=json.loads((change/'baseline.json').read_text(encoding='utf-8'))
    current=snapshot(ROOT,cfg,base);changes=impact(base,current)
    reasons={
      'app/ports.py':'中立采集接口与异常隔离，由 builder 故障、off/fault 测试覆盖，不参与权限决定。',
      'app/store.py':'SQLite 连接、初始化和一致快照基础设施；权威效果由独立 SQL 对照验证。',
      'app/domain.py':'领域辅助构造器、异常和嵌套事务回调归属于已映射的外层业务函数，行为由独立场景和原位置探针验证。',
      'bo_stategraph/workflow.py':'操作生命周期声明加载与迁移辅助函数，按公共声明严格校验。',
      'bo_stategraph/query.py':'权威状态读取投影，逐实例字段映射清单与导出反例覆盖。',
      'integrations/bo_adapter.py':'采集、快照、录制及公共查询接线，由隔离/导出/录制测试覆盖。',
      'integrations/bo_server.py':'HTTP 路由和本地传输适配；不作为额外业务规则节点，页面验收另外记录。',
      'server.py':'命令行启动和资源收尾，不引入额外业务状态。'}
    excluded={}
    for symbol in changes['unmapped_implementation_symbols']:
        path=symbol.split('::')[0]
        if path not in reasons:raise ValueError('Review required for '+symbol)
        excluded[symbol]=reasons[path]
    review={'candidate_id':current['id'],'decisions':{
       'business':{'action':'updated','reason':'实现 U1-U4 确认的 R1-R10；不新增内容校验或其他流程。'},
       'state_machine':{'action':'updated','reason':'SQLite 同步操作 checking/completed/rejected，真实事务是唯一权威状态。'},
       'abstraction':{'action':'updated','reason':'沿用所有设计节点 ID；核心函数、参数、规则和提交分别绑定。'},
       'probes':{'action':'updated','reason':'原位置读取/判断、事务成功后提交；on/off/fault 与独立状态对照。'}},
       'excluded_symbols':excluded,'requirement_changes':{}}
    if active['change']=='.stategraph/runtime-frames':
        review['decisions'].update({
          'business':{'action':'unchanged','reason':'R1-R10 与独立业务预期保持原哈希，仅修复监控接线。'},
          'state_machine':{'action':'unchanged','reason':'仍是 checking/completed/rejected；实际事务行和当前操作上下文按事件冻结，未添加业务状态。'},
          'abstraction':{'action':'updated','reason':'节点身份保留；加入既有完整协议的事件帧与选定输入资源说明。'},
          'probes':{'action':'updated','reason':'发出探针时读取同一事务，提交前冻结实际数据、成功提交后才发布；失败隔离，事件和帧保持原身份。'}})
    write(change/'review.json',review)
    print(json.dumps({'candidate_id':current['id'],'classified_helpers':len(excluded)}))


if __name__=='__main__':main()
