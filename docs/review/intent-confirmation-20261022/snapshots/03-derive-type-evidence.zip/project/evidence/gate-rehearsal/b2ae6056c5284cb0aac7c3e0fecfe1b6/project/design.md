# 已确认规则与运行图

四轮需求已经确认，当前交互运行图为 http://127.0.0.1:8870/graph 。从设计阶段保留 `create_project`、`derive_project`、`configure_relation`、`transfer_data` 节点身份与 `project-flow-trial-main` 布局标识。早期图和当时未决问题保留在 `evidence/round-*/`。

```mermaid
flowchart LR
    C[创建项目] --> P[创建者拥有独立新项目]
    D[派生项目] --> DP{来源所有者或显式 derive}
    DP -->|允许| N[同类型 / 来源 ID / 创建者拥有新项目]
    N --> NC[不复制数据、连接或授权]
    R[配置连接] --> RP{当前两端分别具备 connect}
    RP --> TP{类型允许 / 输出到输入 / 格式相同}
    TP --> L[只记录路径]
    L --> E[手动执行]
    E --> EP{重验当前两端 connect 与当前路径规则}
    EP -->|通过| T[复制源当前 JSON 到目标输入]
    EP -->|拒绝| X[目标保持原值]
```

采集 records → 处理 records 使用 dataset/v1；处理 result → 报告 result 使用 result/v1。项目之间的来源关系和数据连接关系分开；独立创建也可连接。

```mermaid
stateDiagram-v2
    [*] --> checking: 开始 SQLite 同步操作
    checking --> completed: 检查通过并提交
    checking --> rejected: 规则拒绝 / 回滚业务写入
```

这是操作实例生命周期，不是新加的项目业务生命周期。`bo_stategraph/query.py` 从真实 operations 读取当前已提交实例；同一查询用于页面和导出。事件状态帧使用同一事务连接读取其当时的 operations 行和选定输入，并拷贝真实的操作局部上下文；未提交状态由该位置采集，不靠另一连接的最终查询补造。提交前冻结终态数据，只有提交成功才发布它。数据库异常会回滚整笔事务，既不产生成功效果也不伪造拒绝记录。

`app/domain.py` 执行领域操作；中立探针接口隔离采集故障；`integrations/bo_adapter.py` 将真实事件和状态交给原版共享图。图上源码关系是静态关联，事件次序不是完整因果证明。选择的字段和有界 JSON 预览用于调试，不是所有局部变量的抓取。

