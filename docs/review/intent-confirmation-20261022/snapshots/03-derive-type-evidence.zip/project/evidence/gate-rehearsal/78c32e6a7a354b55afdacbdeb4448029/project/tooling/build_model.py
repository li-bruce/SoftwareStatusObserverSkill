"""Project-owned graph declarations; never edit the generated behavior.json by hand."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from bo_stategraph.workflow import DEFINITION
from observer_runtime.code_structure import scan,enrich
from observer_runtime.behavior_model import validate,capture


def save(path,value):
    (ROOT/path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


def main():
    discovery=json.loads((ROOT/'discovery.json').read_text(encoding='utf-8'))
    nodes=[dict(n) for network in discovery['networks'] for n in network['nodes']]
    bindings={
      'create_project':'Projects.create_project','derive_project':'Projects.derive_project',
      'configure_relation':'Projects.configure_relation','transfer_data':'Projects.execute_relation',
      'source_project':'Projects._project','derive_permission':'Projects.derive_project',
      'relation_permission':'check_connect','execute_permission':'check_connect','type_port_rules':'check_path',
      'project_created':'Projects.create_project','project_derived':'Projects.derive_project',
      'relation_configured':'Projects.configure_relation','transfer_effect':'Projects._perform'}
    capture_specs={
      'create_project':({'actor':'string','name':'string','type':'string'},{'project_id':'string','owner':'string','type':'string'}),
      'derive_project':({'actor':'string','source_id':'string'},{'project_id':'string','owner':'string','type':'string','source_id':'string'}),
      'configure_relation':({k:'string' for k in ['actor','source_id','target_id','source_port','target_port']},{'link_id':'string'}),
      'transfer_data':({**{k:'string' for k in ['actor','link_id','source_id','target_id','value_hash']},'source_revision':'number'},{k:'string' for k in ['before','after','value_hash']}),
      'source_project':({'project_id':'string'},{k:'string' for k in ['project_id','type','owner','source_id']}),
      'derive_permission':({'actor':'string','source_id':'string'},{'allowed':'boolean'}),
      'relation_permission':({k:'string' for k in ['actor','source_id','target_id']},{k:'boolean' for k in ['source_allowed','target_allowed','allowed']}),
      'execute_permission':({k:'string' for k in ['actor','source_id','target_id']},{k:'boolean' for k in ['source_allowed','target_allowed','allowed']}),
      'type_port_rules':({k:'string' for k in ['source_type','target_type','source_port','target_port','source_format','target_format']},{k:'boolean' for k in ['type_ok','source_output_exists','target_input_exists','format_ok','allowed']}),
      'transfer_effect':({'target_id':'string','link_id':'string'},{k:'string' for k in ['operation_id','effect_id','value_hash','before','after']})}
    requirement_map={'create_project':['R1'],'derive_project':['R2','R3'],'derive_permission':['R4'],'relation_permission':['R5'],
                     'type_port_rules':['R6','R7'],'execute_permission':['R10'],'transfer_data':['R8','R9','R10']}
    for n in nodes:
        n['kind']={'condition':'decision','event':'data'}.get(n['kind'],n['kind'])
        n.update(source={'path':'app/domain.py','symbol':bindings[n['id']]},summary=n.get('summary') or n['label']+'；来源为已确认规则，实际值由原函数探针提供。',
                 capture={'in':capture_specs.get(n['id'],({},{}))[0],'out':capture_specs.get(n['id'],({},{}))[1]},
                 requirements=requirement_map.get(n['id'],[]))
        if n['kind']=='action': n['layer']='business'
        if n['id'] in ('derive_permission','relation_permission','execute_permission'): n['semantic_roles']=['permission']
        n.pop('model_nodes',None);n.pop('source_refs',None)
    extras=[
      ('permission_fact','decision','读取本项目的所有者与显式授权','permission','execute_permission',
       {k:'string' for k in ['actor','project_id','action','owner_id']},{k:'boolean' for k in ['owner','explicit_grant','allowed']}),
      ('operation_checking','function','进入事务内检查','Projects._perform','transfer_data',{'actor':'string','action':'string'},{'state':'string','operation_id':'string'}),
      ('operation_result','data','操作结束与结果记录','Projects._perform','transfer_data',{'actor':'string','action':'string'},
       {k:'string' for k in ['operation_id','state','reason','effect_id','value_hash']})]
    for ident,kind,label,symbol,parent,inputs,outputs in extras:
        nodes.append(dict(id=ident,kind=kind,label=label,summary=label+'；只展示实际读取或执行结果。',source={'path':'app/domain.py','symbol':symbol},parent=parent,capture={'in':inputs,'out':outputs}))
    for ident,symbol in [('create_project','Projects.create_project'),('derive_project','Projects.derive_project'),('configure_relation','Projects.configure_relation'),('transfer_data','Projects.execute_relation')]:
        nodes.append(dict(id='function_'+ident,kind='function',label=symbol,summary='核心函数及参数；静态调用与实际事件分别标识。',source={'path':'app/domain.py','symbol':symbol},parent=ident,capture={'in':{},'out':{}}))
    for state in DEFINITION['values']:
        nodes.append(dict(id='state_'+state,kind='state',layer='state',value=state,label=DEFINITION['labels'][state],summary='单次同步数据库操作的真实状态；不是项目业务生命周期。',parent='transfer_data',capture={'in':{},'out':{}}))
    edges=[dict(id=e['id'],**{'from':e['from'],'to':e['to']},type=e['relation'],label=e['label'],evidence='confirmed conversation; runtime execution is separately observed')
           for network in discovery['networks'] for e in network['edges']]
    for n in nodes:
        if n.get('parent'):
            edges.append(dict(id='contains:'+n['id'],**{'from':n['parent'],'to':n['id']},type='contains',label='展开',evidence='authored grouping; stable identities'))
    code=['app/__init__.py','app/domain.py','app/store.py','app/ports.py','bo_stategraph/workflow.py','bo_stategraph/query.py','integrations/__init__.py','integrations/bo_adapter.py','integrations/bo_server.py','server.py']
    sources=code+['static/app.html','static/app.js','static/app.css']
    model=dict(schema_version=3,revision='1',project_id=discovery['project_id'],title=discovery['title'],intent='intent.json',source_files=sources,
               nodes=nodes,edges=edges,overview=[{'node':n,'x':i*280,'y':100} for i,n in enumerate(['create_project','derive_project','configure_relation','transfer_data'])],
               graph_roots=['create_project','derive_project','configure_relation','transfer_data'],machine=DEFINITION,
               presentation={'subject':'项目派生与数据流转','context_fields':[{'key':k,'label':k} for k in DEFINITION['context']],'recording':{'parameters':['attempt',*DEFINITION['context']]}},
               scope={'unknowns':['演示用户切换不提供生产认证。','同步事务无业务等待、取消或自动恢复。','JSON 正文不作语义校验；图只保存长度受限的演示值预览和散列。','未采集所有局部变量和外部动态调用。','状态帧覆盖对应操作及选定目标输入，状态修订取自事务行，局部上下文来自当前操作；不是整个数据库的历史备份。','操作日志可查询全部实例；有界事件与状态帧可能过期，缺口不补造。']})
    model=enrich(model,scan(ROOT,code),1)
    validate(ROOT,model);capture(ROOT,model)
    save('behavior.json',model)
    cfg=json.loads((ROOT/'sync.json').read_text(encoding='utf-8'))
    cfg['code_files']=code
    cfg['watch_files']=sorted(set(cfg['watch_files']+['tooling/build_model.py','tooling/review_candidate.py','tooling/gate.py','tests/scenarios.py','tests/test_project.py','tests/test_observer.py','observe.py','ownership.json','whitebox.json','bo_stategraph/__init__.py','bo_stategraph/bo_contracts.py','bo_stategraph/execution_contract.py','bo_stategraph/runtime-version.json','bo_stategraph/config/retention.json','static/app.html','static/app.js','static/app.css','AGENTS.md']))
    cfg['watch_files']=sorted(set(cfg['watch_files']+['tests/frame_expectations.json']+[p.relative_to(ROOT).as_posix() for folder in ('tooling','tests') for p in (ROOT/folder).glob('*.py')]))
    cfg.update(stategraph={'module':'bo_stategraph/__init__.py','development_mode':'guided','execution_mode':'observe'},slice_depth=1,whitebox='whitebox.json',probe_callees=['trace.bo_emit'],
        required_probes=[{'symbol':'app/domain.py::Projects.execute_relation.work','node':'transfer_data','phase':'return'},
                         {'symbol':'app/domain.py::check_connect','node':'execute_permission','phase':'decision'},
                         {'symbol':'app/domain.py::Projects._perform','node':'transfer_effect','phase':'commit'}],
        required_runtime_probes=[{'case':'execute_current','node':'transfer_effect','phase':'commit'},
                                 {'case':'execute_revoked','node':'execute_permission','phase':'decision'}])
    cfg['source_scope']['exclude'].update({'observer_runtime/**':'Installed shared tools; runtime-version hashes and architecture seal verify copies.',
       'bo_stategraph/__init__.py':'Installed public query core; verified by runtime manifest and export checks.',
       'bo_stategraph/bo_contracts.py':'Installed shared validators; runtime manifest checked.',
       'bo_stategraph/execution_contract.py':'Installed shared activity validator; project declares no activity graph.',
       'observe.py':'Observed scenario runner, explicitly watched and executed by gate.'})
    save('sync.json',cfg)
    print(json.dumps({'nodes':len(model['nodes']),'source_files':len(sources)}))


if __name__=='__main__': main()
