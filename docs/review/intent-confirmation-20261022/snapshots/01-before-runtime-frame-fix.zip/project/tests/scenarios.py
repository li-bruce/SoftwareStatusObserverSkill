"""Arrange real application inputs. Expected business outcomes live in cases.json."""
import hashlib
import json
import sqlite3
from contextlib import closing
from pathlib import Path
from app.store import Store
from app.domain import Projects
from integrations.bo_adapter import BOAdapter
from bo_stategraph.query import bo_machine

ROOT=Path(__file__).resolve().parents[1]


def read_db(path,sql,params=()):
    with closing(sqlite3.connect(path)) as db:
        db.row_factory=sqlite3.Row
        return [dict(row) for row in db.execute(sql,params)]


def alter(path,sql,params=()):
    with closing(sqlite3.connect(path)) as db, db: db.execute(sql,params)


def raw_input(path):
    rows=read_db(path,"SELECT value_json,revision FROM port_values WHERE project_id='process-b' AND port='records' AND direction='in'")
    return rows


def scenario(case,mode,directory):
    db_path=Path(directory)/case/mode/'application.sqlite3'
    store=Store(db_path);store.seed_demo()
    adapter=BOAdapter(ROOT,store,mode)
    app=Projects(store,build_id=adapter.manifest['build_id'],events=adapter.events)
    before=raw_input(db_path)
    result=None;observations={}
    try:
        if case=='create':
            result=app.create_project('alice','独立新建','collection')
        elif case.startswith('derive_'):
            if case=='derive_nocopy':
                app.configure_relation('alice','collect-a','records','process-b','records')
            actor={'derive_owner':'alice','derive_grant':'bob','derive_denied':'dave','derive_nocopy':'bob'}[case]
            count=read_db(db_path,'SELECT COUNT(*) AS n FROM projects')[0]['n']
            result=app.derive_project(actor,'collect-a','派生测试')
            if case=='derive_denied': observations['project_delta']=read_db(db_path,'SELECT COUNT(*) AS n FROM projects')[0]['n']-count
        elif case in ('execute_current','execute_revoked','execute_other_actor','execute_type_changed','execute_port_changed','execute_format_changed','no_algorithm','json_values','manual_retry','missing_output'):
            linked=app.configure_relation('alice','collect-a','records','process-b','records')
            assert linked['ok'],linked
            actor='alice'
            old_result=read_db(db_path,"SELECT value_json FROM port_values WHERE project_id='process-b' AND port='result'")
            if case=='execute_current':
                alter(db_path,"UPDATE port_values SET value_json=?,revision=revision+1 WHERE project_id='collect-a'",(json.dumps({'batch':'new','items':[1,2,3]}),))
            if case in ('execute_revoked','manual_retry'):
                alter(db_path,"DELETE FROM grants WHERE project_id='process-b' AND actor='alice' AND permission='connect'")
            if case=='execute_other_actor': actor='dave'
            if case=='execute_type_changed': alter(db_path,"UPDATE projects SET type='report' WHERE id='process-b'")
            if case=='execute_port_changed': alter(db_path,"DELETE FROM ports WHERE project_type='processing' AND name='records'")
            if case=='execute_format_changed': alter(db_path,"UPDATE ports SET format='dataset/v2' WHERE project_type='processing' AND name='records'")
            if case=='missing_output': alter(db_path,"DELETE FROM port_values WHERE project_id='collect-a'")
            source_before=read_db(db_path,"SELECT * FROM port_values WHERE project_id='collect-a'")
            if case=='json_values':
                values=[None,False,0,2.5,'原样文本',[],{},[1,{'nested':True}],{'different_shape':['x',3]}]
                preserved=[]
                for value in values:
                    alter(db_path,"UPDATE port_values SET value_json=?,revision=revision+1 WHERE project_id='collect-a'",(json.dumps(value,ensure_ascii=False),))
                    result=app.execute_relation(actor,linked['link_id'])
                    preserved.append(result['ok'] and json.loads(raw_input(db_path)[0]['value_json'])==value)
                observations['values_preserved']=all(preserved)
            else:
                result=app.execute_relation(actor,linked['link_id'])
            if case=='manual_retry':
                observations['first_rejected']=not result['ok'] and before==raw_input(db_path)
                alter(db_path,"INSERT INTO grants VALUES('process-b','alice','connect')")
                result=app.execute_relation(actor,linked['link_id'])
            if case in ('execute_current','manual_retry'):
                observations['target_value']=json.loads(raw_input(db_path)[0]['value_json'])
            if case=='execute_current': observations['source_unchanged']=source_before==read_db(db_path,"SELECT * FROM port_values WHERE project_id='collect-a'")
            if case=='no_algorithm': observations['result_unchanged']=old_result==read_db(db_path,"SELECT value_json FROM port_values WHERE project_id='process-b' AND port='result'")
        else:
            actor='alice';target='process-b';out_port='records';in_port='records'
            if case=='connect_owner': alter(db_path,"UPDATE projects SET owner='alice' WHERE id='process-b'")
            if case=='connect_grants':
                actor='dave';alter(db_path,"INSERT INTO grants VALUES('process-b','dave','connect')")
            if case=='connect_source_only': actor='dave'
            if case=='connect_target_only': actor='carol'
            if case=='connect_neither':
                actor='dave';alter(db_path,"DELETE FROM grants WHERE actor='dave'")
            if case=='type_skip':
                target='report-c';in_port='result';alter(db_path,"INSERT INTO grants VALUES('report-c','alice','connect')")
            if case=='missing_port': out_port='missing'
            if case=='reverse_port': in_port='result'
            if case=='format_mismatch': alter(db_path,"UPDATE ports SET format='dataset/v2' WHERE project_type='processing' AND name='records'")
            result=app.configure_relation(actor,'collect-a',out_port,target,in_port)
            if case=='independent_projects':
                observations['both_independent']=all(r['source_id'] is None for r in read_db(db_path,"SELECT source_id FROM projects WHERE id IN ('collect-a','process-b')"))
        observations.update(ok=result['ok'])
        if not result['ok']: observations['code']=result['code']
        observations['target_unchanged']=before==raw_input(db_path)
        if result.get('project_id'):
            ident=result['project_id'];p=read_db(db_path,'SELECT * FROM projects WHERE id=?',(ident,))[0]
            observations.update(owner=p['owner'],project_type=p['type'],source_id=p['source_id'])
            observations['data_count']=len(read_db(db_path,'SELECT * FROM port_values WHERE project_id=?',(ident,)))
            observations['grant_count']=len(read_db(db_path,'SELECT * FROM grants WHERE project_id=?',(ident,)))
            observations['link_count']=len(read_db(db_path,'SELECT * FROM links WHERE source_id=? OR target_id=?',(ident,ident)))
        # Independent DB read: never copied from the graph or its adapter.
        actual=read_db(db_path,'SELECT * FROM operations ORDER BY rowid')
        machine=bo_machine(store.snapshot())
        instances=adapter.graph.bo_instances(machine)
        adapter.pins.flush()
        events=adapter.history.snapshot()
        run={'case':case,'mode':mode,'observations':observations,'events':events,'actual_runs':actual,
             'projection':{'build_id':adapter.manifest['build_id'],'machine':machine,'instances':instances},
             'mapping_checks':[{'id':case+':'+mode+':states','source':'Independent SELECT operations',
                                'projection':'BOStateGraph.bo_instances',
                                'actual':[[r['id'],r['state']] for r in actual],
                                'mapped':[[i['observed']['instance_id'],i['observed']['state']] for i in instances]}],
             'health':adapter.pins.health()}
        last=actual[-1]
        if last['action']=='execute' and last['state']=='completed':
            link=read_db(db_path,'SELECT * FROM links WHERE id=?',(last['link_id'],))[0]
            target=read_db(db_path,'SELECT value_json FROM port_values WHERE project_id=? AND port=? AND direction=?',
                           (link['target_id'],link['target_port'],'in'))[0]
            actual_hash=hashlib.sha256(target['value_json'].encode('utf-8')).hexdigest()
            mapped=next(i['observed'] for i in instances if i['observed']['instance_id']==last['id'])
            run['mapping_checks'].append({'id':case+':'+mode+':actual-target-value','source':'Independent SELECT target port_values and links',
                                          'projection':'BOStateGraph context.value_hash',
                                          'actual':actual_hash,'mapped':mapped['context']['value_hash']})
        return run,adapter.graph.bo_export(runtime={'machine':machine})
    finally: adapter.close()
