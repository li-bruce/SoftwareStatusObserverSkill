"""One adapter from real SQLite operations to the public instance protocol."""
from .workflow import CONTEXT


def bo_machine(snapshot):
    configurations = []
    for row in snapshot['operations']:
        configurations.append({'attempt':row['id'], 'phase':row['state'], 'state_revision':row['revision'],
                               'run_build_id':row['build_id'], 'context':{k:row[k] for k in CONTEXT},
                               'revision':row['revision'], 'param_version':1, 'journal':[]})
    return {'configurations':configurations, 'current':configurations[-1]['phase'] if configurations else None,
            'journal':[], 'state_revision':sum(r['revision'] for r in snapshot['operations'])}
