"""Neutral, optional events. Even a broken payload builder cannot alter business results."""


class BOTrace:
    def __init__(self, sink=None):
        self.sink = sink
        self.sequence = 0
        self.errors = 0

    def bo_emit(self, node, phase, builder, *, depends=()):
        if self.sink is None:
            return None
        try:
            self.sequence += 1
            return self.sink(node, phase, {'param_version': 1}, builder,
                             call_id=f'{node}:{self.sequence}', depends=depends)
        except Exception:
            self.errors += 1
            return None


class BOEvents:
    def __init__(self, factory=None):
        self.factory = factory

    def bo_trace(self, entity):
        try:
            return BOTrace(self.factory(entity) if self.factory else None)
        except Exception:
            return BOTrace()
