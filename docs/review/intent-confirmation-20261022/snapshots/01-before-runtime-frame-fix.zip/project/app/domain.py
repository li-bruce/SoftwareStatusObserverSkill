"""Project creation, independent derivation and checked JSON transfer."""
import hashlib
import json
import uuid
from .ports import BOEvents
from .store import TYPES
from bo_stategraph.workflow import next_state, validate_loaded


class Rejected(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def value_digest(raw: str) -> str:
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def permission(db, actor: str, project: dict, action: str, trace) -> bool:
    owner = project['owner'] == actor
    granted = db.execute('SELECT 1 FROM grants WHERE project_id=? AND actor=? AND permission=?',
                         (project['id'], actor, action)).fetchone() is not None
    allowed = owner or granted
    trace.bo_emit('permission_fact', 'decision', lambda: {
        'inputs': {'actor': actor, 'project_id': project['id'], 'action': action, 'owner_id': project['owner']},
        'outputs': {'owner': owner, 'explicit_grant': granted, 'allowed': allowed}})
    return allowed


def check_connect(db, actor: str, source: dict, target: dict, trace, *, executing=False) -> bool:
    source_allowed = permission(db, actor, source, 'connect', trace)
    target_allowed = permission(db, actor, target, 'connect', trace)
    allowed = source_allowed and target_allowed
    builder = lambda: {'inputs': {'actor': actor, 'source_id': source['id'], 'target_id': target['id']},
                       'outputs': {'source_allowed': source_allowed, 'target_allowed': target_allowed, 'allowed': allowed}}
    if executing:
        trace.bo_emit('execute_permission', 'decision', builder)
    else:
        trace.bo_emit('relation_permission', 'decision', builder)
    return allowed


def check_path(db, source: dict, source_port: str, target: dict, target_port: str, trace) -> bool:
    # Read current rules inside the same transaction as the eventual write.
    out_port = db.execute('SELECT * FROM ports WHERE project_type=? AND name=? AND direction=?',
                          (source['type'], source_port, 'out')).fetchone()
    in_port = db.execute('SELECT * FROM ports WHERE project_type=? AND name=? AND direction=?',
                         (target['type'], target_port, 'in')).fetchone()
    type_ok = db.execute('SELECT 1 FROM type_edges WHERE source_type=? AND target_type=?',
                         (source['type'], target['type'])).fetchone() is not None
    source_exists, target_exists = out_port is not None, in_port is not None
    source_format = out_port['format'] if out_port else ''
    target_format = in_port['format'] if in_port else ''
    format_ok = source_exists and target_exists and source_format == target_format
    allowed = type_ok and source_exists and target_exists and format_ok
    trace.bo_emit('type_port_rules', 'decision', lambda: {
        'inputs': {'source_type':source['type'], 'target_type':target['type'], 'source_port':source_port,
                   'target_port':target_port, 'source_format':source_format, 'target_format':target_format},
        'outputs': {'type_ok':type_ok, 'source_output_exists':source_exists, 'target_input_exists':target_exists,
                    'format_ok':format_ok, 'allowed':allowed}})
    return allowed


class Projects:
    def __init__(self, store, *, build_id='core', events=None):
        validate_loaded()
        self.store, self.build_id = store, build_id
        self.events = events or BOEvents()

    def _project(self, db, ident: str, trace) -> dict:
        row = db.execute('SELECT * FROM projects WHERE id=?', (ident,)).fetchone()
        if row is None:
            raise Rejected('project_not_found')
        project = dict(row)
        trace.bo_emit('source_project', 'read', lambda: {'inputs': {'project_id':ident},
                      'outputs': {'project_id':ident, 'type':project['type'], 'owner':project['owner'], 'source_id':project['source_id']}})
        return project

    def _perform(self, actor, action, work, *, source_id='', target_id='', link_id=''):
        operation_id = uuid.uuid4().hex
        trace = self.events.bo_trace(operation_id)
        context = dict(actor=actor, action=action, source_id=source_id, target_id=target_id,
                       link_id=link_id, reason='', effect_id='', value_hash='')
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT INTO operations(id,state,revision,build_id,actor,action,source_id,target_id,link_id,reason,effect_id,value_hash) VALUES(?,?,1,?,?,?,?,?,?,?,?,?)',
                       (operation_id,'checking',self.build_id,*context.values()))
            trace.bo_emit('operation_checking','enter',lambda:{'inputs':{'actor':actor,'action':action},'outputs':{'state':'checking','operation_id':operation_id}})
            db.execute('SAVEPOINT business')
            try:
                if db.execute('SELECT 1 FROM users WHERE id=?',(actor,)).fetchone() is None:
                    raise Rejected('unknown_user')
                result = work(db, trace, context)
                result.update(ok=True, operation_id=operation_id)
                state = next_state('checking', 'commit')
                context['effect_id'] = operation_id
            except Rejected as exc:
                db.execute('ROLLBACK TO business')
                context.update(reason=exc.code, effect_id='', value_hash='')
                state = next_state('checking','reject')
                result = dict(ok=False,code=exc.code,operation_id=operation_id)
            db.execute('RELEASE business')
            db.execute('UPDATE operations SET state=?,revision=2,source_id=?,target_id=?,link_id=?,reason=?,effect_id=?,value_hash=?,result_json=? WHERE id=?',
                       (state,context['source_id'],context['target_id'],context['link_id'],context['reason'],context['effect_id'],context['value_hash'],json.dumps(result,ensure_ascii=False),operation_id))
            db.commit()
        # Effects are observed only after the actual commit.
        final_payload = lambda:{'inputs':{'actor':actor,'action':action},'outputs':{
            'operation_id':operation_id,'state':state,'reason':context['reason'],'effect_id':context['effect_id'],'value_hash':context['value_hash']}}
        if result['ok']:
            trace.bo_emit('operation_result','commit',final_payload)
        else:
            trace.bo_emit('operation_result','return',final_payload)
        if action == 'execute' and result['ok']:
            trace.bo_emit('transfer_effect','commit',lambda:{'inputs':{'target_id':context['target_id'],'link_id':link_id},
                          'outputs':{'operation_id':operation_id,'effect_id':context['effect_id'],'value_hash':context['value_hash'],
                                     'before':result['before_preview'],'after':result['after_preview']}})
        return result

    def create_project(self, actor: str, name: str, project_type: str) -> dict:
        def work(db, trace, context):
            if project_type not in TYPES:
                raise Rejected('unknown_type')
            if not isinstance(name,str) or not name.strip():
                raise Rejected('name_required')
            ident = uuid.uuid4().hex[:12]
            db.execute('INSERT INTO projects VALUES(?,?,?,?,NULL)', (ident,name.strip(),project_type,actor))
            context['target_id'] = ident
            trace.bo_emit('create_project','return',lambda:{'inputs':{'actor':actor,'name':name,'type':project_type},
                          'outputs':{'project_id':ident,'owner':actor,'type':project_type}})
            return dict(project_id=ident)
        return self._perform(actor,'create',work)

    def derive_project(self, actor: str, source_id: str, name: str) -> dict:
        def work(db, trace, context):
            source = self._project(db, source_id, trace)
            allowed = permission(db,actor,source,'derive',trace)
            trace.bo_emit('derive_permission','decision',lambda:{'inputs':{'actor':actor,'source_id':source_id},'outputs':{'allowed':allowed}})
            if not allowed:
                raise Rejected('derive_denied')
            if not isinstance(name,str) or not name.strip():
                raise Rejected('name_required')
            ident = uuid.uuid4().hex[:12]
            # Inserting only a project row deliberately copies no grants, links or values.
            db.execute('INSERT INTO projects VALUES(?,?,?,?,?)',(ident,name.strip(),source['type'],actor,source_id))
            context['target_id'] = ident
            trace.bo_emit('derive_project','return',lambda:{'inputs':{'actor':actor,'source_id':source_id},
                          'outputs':{'project_id':ident,'owner':actor,'type':source['type'],'source_id':source_id}})
            return dict(project_id=ident)
        return self._perform(actor,'derive',work,source_id=source_id)

    def configure_relation(self, actor: str, source_id: str, source_port: str, target_id: str, target_port: str) -> dict:
        def work(db, trace, context):
            source, target = self._project(db,source_id,trace), self._project(db,target_id,trace)
            if not check_connect(db,actor,source,target,trace):
                raise Rejected('connect_denied')
            if not check_path(db,source,source_port,target,target_port,trace):
                raise Rejected('invalid_path')
            ident = uuid.uuid4().hex[:12]
            db.execute('INSERT INTO links VALUES(?,?,?,?,?,?)',(ident,source_id,source_port,target_id,target_port,actor))
            context['link_id'] = ident
            trace.bo_emit('configure_relation','return',lambda:{'inputs':{'actor':actor,'source_id':source_id,'target_id':target_id,
                          'source_port':source_port,'target_port':target_port},'outputs':{'link_id':ident}})
            return dict(link_id=ident)
        return self._perform(actor,'connect',work,source_id=source_id,target_id=target_id)

    def execute_relation(self, actor: str, link_id: str) -> dict:
        def work(db, trace, context):
            row = db.execute('SELECT * FROM links WHERE id=?',(link_id,)).fetchone()
            if row is None:
                raise Rejected('link_not_found')
            link = dict(row)
            context.update(source_id=link['source_id'], target_id=link['target_id'])
            source = self._project(db,link['source_id'],trace)
            target = self._project(db,link['target_id'],trace)
            if not check_connect(db,actor,source,target,trace,executing=True):
                raise Rejected('connect_denied')
            if not check_path(db,source,link['source_port'],target,link['target_port'],trace):
                raise Rejected('invalid_path')
            value = db.execute('SELECT value_json,revision FROM port_values WHERE project_id=? AND port=? AND direction=?',
                               (source['id'],link['source_port'],'out')).fetchone()
            if value is None:
                raise Rejected('no_source_value')
            raw = value['value_json']
            before = db.execute('SELECT value_json FROM port_values WHERE project_id=? AND port=? AND direction=?',
                                (target['id'],link['target_port'],'in')).fetchone()
            old = before['value_json'] if before else None
            context['value_hash'] = value_digest(raw)
            trace.bo_emit('transfer_data','return',lambda:{'inputs':{'actor':actor,'link_id':link_id,'source_id':source['id'],
                          'target_id':target['id'],'source_revision':value['revision'],'value_hash':context['value_hash']},
                          'outputs':{'before':old[:180] if old is not None else '(absent)','after':raw[:180],'value_hash':context['value_hash']}})
            db.execute('INSERT INTO port_values VALUES(?,?,?,?,1) ON CONFLICT(project_id,port,direction) DO UPDATE SET value_json=excluded.value_json,revision=port_values.revision+1',
                       (target['id'],link['target_port'],'in',raw))
            return dict(link_id=link_id,before_preview=old[:180] if old is not None else '(absent)',after_preview=raw[:180])
        return self._perform(actor,'execute',work,link_id=link_id)
