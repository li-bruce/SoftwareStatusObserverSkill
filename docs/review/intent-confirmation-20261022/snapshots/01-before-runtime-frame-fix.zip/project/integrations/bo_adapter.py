"""Shared query, selected probes, bounded logs and optional recording service."""
import json
from pathlib import Path
from app.ports import BOEvents
from bo_stategraph import BOStateGraph, bo_export_view
from bo_stategraph.query import bo_machine
from bo_stategraph.workflow import DEFINITION
from observer_runtime.behavior_model import capture, check
from observer_runtime.semantic_probe import Pins, Trace
from observer_runtime.bo_retention import EventHistory
from observer_runtime.recording_session import Recordings


class BOAdapter:
    def __init__(self, root, store, mode='on', *, recordings=False):
        self.root, self.store = Path(root).absolute(), store
        self.model = json.loads((self.root/'behavior.json').read_text(encoding='utf-8'))
        self.manifest = capture(self.root,self.model)
        self.graph = BOStateGraph(self.model,build_id=self.manifest['build_id'],mode='observe',
                                  instance_provider=lambda:bo_machine(self.store.snapshot()))
        self.graph.bo_require_definition(DEFINITION)
        log = store.path.parent/'events.jsonl'
        self.history = EventHistory(project_root=self.root,path=log)
        self.mode = mode
        self.pins = Pins(self.model,self.manifest['build_id'],enabled=mode!='off',sink=self.bo_sink,
                         project_root=self.root)
        self.events = BOEvents(self.bo_trace)
        self.recordings = Recordings(store.path.parent/'recordings',self.bo_view,self.bo_sources(),
                event_source=self.history,scope_setter=self.pins.bo_set_scope) if recordings else None

    def bo_sink(self, text):
        if self.mode == 'fault':
            raise OSError('deliberate observer sink failure')
        self.history.append(json.loads(text))

    def bo_trace(self, entity):
        if self.mode == 'off':
            return None
        return Trace(self.pins,entity,entity).record

    def bo_sources(self):
        return {path:(self.root/path).read_text(encoding='utf-8-sig') for path in self.manifest['files'] if path.endswith('.py')}

    def bo_view(self):
        snapshot = self.store.snapshot()
        machine = bo_machine(snapshot)
        latest = snapshot['operations'][-1] if snapshot['operations'] else None
        return {'stage':'runtime','layout_id':'project-flow-trial-main','model':self.model,'manifest':self.manifest,
                'binding_status':check(self.root,self.model,self.manifest),
                'events':self.history.snapshot(),'machine':machine,'health':self.pins.health(),
                'authority':{'entity':latest['id'] if latest else None,'state':latest['state'] if latest else None,
                             'basis':{'param_version':1},'parameters':{'attempt':latest['id'],**machine['configurations'][-1]['context']} if latest else {},'effects':[]},
                'busy':False,'historical':False,'available_cases':['live']}

    def bo_export(self):
        return bo_export_view(self.bo_view(),graph=self.graph)

    def close(self):
        self.pins.close()
        if self.recordings:
            self.recordings.close()
