"""Loopback application API and optional shared observer surface."""
import json
import mimetypes
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
from observer_runtime.bo_web import BOWeb
from observer_runtime.view_preferences import Preferences, PreferenceConflict


def bo_http_server(root, service, adapter, port):
    web = BOWeb(root,assets=root/'static/graph')
    preferences = Preferences(root,'project-flow-trial-main')
    sources = adapter.bo_sources()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):
            pass

        def reply(self,value,code=200,mime='application/json'):
            data=value if isinstance(value,bytes) else json.dumps(value,ensure_ascii=False).encode('utf-8')
            self.send_response(code)
            self.send_header('Content-Type',mime+'; charset=utf-8')
            self.send_header('Content-Length',str(len(data)))
            self.send_header('Cache-Control','no-store')
            self.send_header('X-Content-Type-Options','nosniff')
            self.end_headers()
            self.wfile.write(data)

        def local(self):
            hosts={f'localhost:{self.server.server_port}',f'127.0.0.1:{self.server.server_port}'}
            origin=self.headers.get('Origin')
            return self.headers.get('Host') in hosts and (not origin or origin=='http://'+self.headers['Host'])

        def do_GET(self):
            if not self.local(): return self.reply({'error':'local_request_required'},403)
            url=urlsplit(self.path);path=url.path;query=parse_qs(url.query)
            try:
                if not web.allowed(path): return self.reply({'code':'bo_web_disabled'},404)
                if path=='/api/projects': return self.reply(service.store.snapshot())
                if path=='/api/view': return self.reply(adapter.bo_view())
                if path in ('/api/stategraph','/api/stategraph/export'): return self.reply(adapter.bo_export())
                if path=='/api/design': return self.reply(web.get(path))
                if path=='/api/preferences': return self.reply(preferences.read())
                if path=='/api/recordings': return self.reply(adapter.recordings.list())
                if path.startswith('/api/recordings/'): return self.reply(adapter.recordings.get(path.rsplit('/',1)[1]))
                if path=='/api/source':
                    name=query.get('path',[''])[0]
                    selected=sources; build=adapter.manifest['build_id']
                    if query.get('recording'):
                        recording=adapter.recordings.get(query['recording'][0]);selected=recording['sources'];build=recording['build_id']
                    if name not in selected: return self.reply({'error':'source_not_in_scope'},404)
                    return self.reply({'source':selected[name],'build_id':build})
                if path in ('/','/app','/control'):
                    return self.reply(web.entry_html((root/'static/app.html').read_bytes()),mime='text/html')
                if path in ('/app.js','/app.css'):
                    return self.reply((root/'static'/path[1:]).read_bytes(),mime=mimetypes.guess_type(path)[0])
                name='index.html' if path in ('/graph','/graph/') else path[1:]
                if name and '/' not in name and '\\' not in name and not name.startswith('.') and (root/'static/graph'/name).is_file():
                    return self.reply((root/'static/graph'/name).read_bytes(),mime=mimetypes.guess_type(name)[0] or 'application/octet-stream')
                return self.reply({'error':'not_found'},404)
            except (ValueError,KeyError) as exc:
                return self.reply({'error':str(exc)},400)

        def do_POST(self):
            if not self.local(): return self.reply({'error':'local_request_required'},403)
            path=urlsplit(self.path).path
            try:
                if not web.allowed(path): return self.reply({'code':'bo_web_disabled'},404)
                length=int(self.headers.get('Content-Length','0'))
                if not 0<length<=2*1024*1024: return self.reply({'error':'invalid_request_size'},400)
                data=json.loads(self.rfile.read(length))
                if not isinstance(data,dict): return self.reply({'error':'object_required'},400)
                if path=='/api/preferences': return self.reply(preferences.save(data))
                if path=='/api/recordings/start': return self.reply(adapter.recordings.start(data.get('label',''),data.get('scope')))
                if path=='/api/recordings/stop': return self.reply(adapter.recordings.stop())
                if path=='/api/create': result=service.create_project(data['actor'],data['name'],data['type'])
                elif path=='/api/derive': result=service.derive_project(data['actor'],data['source_id'],data['name'])
                elif path=='/api/connect': result=service.configure_relation(data['actor'],data['source_id'],data['source_port'],data['target_id'],data['target_port'])
                elif path=='/api/execute': result=service.execute_relation(data['actor'],data['link_id'])
                else: return self.reply({'error':'not_found'},404)
                adapter.pins.flush()
                return self.reply(result,200 if result['ok'] else 409)
            except PreferenceConflict as exc: return self.reply({'error':str(exc)},409)
            except (ValueError,KeyError,TypeError): return self.reply({'error':'invalid_request'},400)
            except Exception:
                return self.reply({'error':'operation_unavailable'},503)

    return ThreadingHTTPServer(('127.0.0.1',port),Handler)
