"""Project management domain. No dependency on observation collectors or Web UI."""
