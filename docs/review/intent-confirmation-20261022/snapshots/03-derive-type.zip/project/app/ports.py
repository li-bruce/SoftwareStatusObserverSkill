"""Neutral, optional events. Even a broken payload builder cannot alter business results."""
from copy import deepcopy


class BOTrace:
    def __init__(self, sink=None):
        self.sink = sink
        self.sequence = 0
        self.errors = 0
        self.snapshot = None

    def bo_bind_state(self, provider):
        self.snapshot = provider

    def bo_freeze_state(self):
        """Freeze the actual transaction before commit; publish only after it succeeds."""
        if self.sink is None or self.snapshot is None:
            return
        try:
            frozen = deepcopy(self.snapshot())
            self.snapshot = lambda: deepcopy(frozen)
        except Exception:
            self.errors += 1
            self.snapshot = None

    def bo_emit(self, node, phase, builder, *, depends=()):
        if self.sink is None:
            return None
        try:
            self.sequence += 1
            return self.sink(node, phase, {'param_version': 1}, builder,
                             call_id=f'{node}:{self.sequence}', depends=depends,snapshot=self.snapshot)
        except Exception:
            self.errors += 1
            return None


class BOEvents:
    def __init__(self, factory=None):
        self.factory = factory

    def bo_trace(self, entity):
        try:
            return BOTrace(self.factory(entity) if self.factory else None)
        except Exception:
            return BOTrace()
