"""SQLite is the authority for projects, grants, ports, JSON values and operation results."""
import json
import sqlite3
from pathlib import Path

SCHEMA = '''
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,name TEXT NOT NULL,type TEXT NOT NULL,
 owner TEXT NOT NULL REFERENCES users(id),source_id TEXT REFERENCES projects(id));
CREATE TABLE IF NOT EXISTS grants(project_id TEXT REFERENCES projects(id),actor TEXT REFERENCES users(id),
 permission TEXT CHECK(permission IN ('derive','connect')),PRIMARY KEY(project_id,actor,permission));
CREATE TABLE IF NOT EXISTS ports(project_type TEXT,name TEXT,direction TEXT,format TEXT,
 PRIMARY KEY(project_type,name,direction));
CREATE TABLE IF NOT EXISTS type_edges(source_type TEXT,target_type TEXT,PRIMARY KEY(source_type,target_type));
CREATE TABLE IF NOT EXISTS links(id TEXT PRIMARY KEY,source_id TEXT REFERENCES projects(id),source_port TEXT,
 target_id TEXT REFERENCES projects(id),target_port TEXT,creator TEXT REFERENCES users(id));
CREATE TABLE IF NOT EXISTS port_values(project_id TEXT REFERENCES projects(id),port TEXT,direction TEXT,
 value_json TEXT NOT NULL,revision INTEGER NOT NULL,PRIMARY KEY(project_id,port,direction));
CREATE TABLE IF NOT EXISTS operations(id TEXT PRIMARY KEY,state TEXT,revision INTEGER,build_id TEXT,
 actor TEXT,action TEXT,source_id TEXT,target_id TEXT,link_id TEXT,reason TEXT,effect_id TEXT,value_hash TEXT,
 before_json TEXT,after_json TEXT,result_json TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
'''
TYPES = ('collection', 'processing', 'report')


class Connection(sqlite3.Connection):
    def __exit__(self, exc_type, exc_value, traceback):
        try:
            return super().__exit__(exc_type, exc_value, traceback)
        finally:
            self.close()


class Store:
    def __init__(self, path):
        self.path = Path(path).absolute()
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript(SCHEMA)
            db.executemany('INSERT OR IGNORE INTO ports VALUES(?,?,?,?)', [
                ('collection','records','out','dataset/v1'), ('processing','records','in','dataset/v1'),
                ('processing','result','out','result/v1'), ('report','result','in','result/v1')])
            db.executemany('INSERT OR IGNORE INTO type_edges VALUES(?,?)', [('collection','processing'),('processing','report')])

    def connect(self):
        db = sqlite3.connect(self.path, timeout=5, factory=Connection)
        db.row_factory = sqlite3.Row
        db.execute('PRAGMA foreign_keys=ON')
        return db

    def seed_demo(self):
        with self.connect() as db:
            if db.execute('SELECT COUNT(*) FROM users').fetchone()[0]:
                return
            db.executemany('INSERT INTO users VALUES(?,?)', [('alice','小林'),('bob','小周'),('carol','小陈'),('dave','访客小王')])
            db.executemany('INSERT INTO projects VALUES(?,?,?,?,?)', [
                ('collect-a','采集 A','collection','alice',None),
                ('process-b','处理 B','processing','bob',None),
                ('report-c','报告 C','report','carol',None)])
            db.executemany('INSERT INTO grants VALUES(?,?,?)', [
                ('process-b','alice','connect'), ('collect-a','bob','derive'), ('collect-a','bob','connect'),
                ('report-c','bob','connect'), ('process-b','carol','connect'), ('collect-a','dave','connect')])
            db.executemany('INSERT INTO port_values VALUES(?,?,?,?,1)', [
                ('collect-a','records','out',json.dumps({'batch':'A','items':[{'id':1,'value':12}]})),
                ('process-b','records','in',json.dumps({'old':True})),
                ('process-b','result','out',json.dumps({'total':12}))])

    def snapshot(self):
        with self.connect() as db:
            db.execute('BEGIN')
            result = {table: [dict(r) for r in db.execute('SELECT * FROM '+table+' ORDER BY rowid')]
                      for table in ('users','projects','grants','ports','type_edges','links','port_values','operations')}
        return result
