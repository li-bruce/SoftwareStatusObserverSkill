"""Independent business assertions, atomicity, concurrent access and deliberate defects."""
import concurrent.futures
import copy
import json
import sqlite3
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from app.store import Store
from app.domain import Projects
from tests.scenarios import scenario, ROOT, read_db, alter


class BusinessTests(unittest.TestCase):
    def setUp(self):
        parent=ROOT/'data/test-tmp';parent.mkdir(parents=True,exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=parent)
        self.addCleanup(self.temp.cleanup)

    def test_independent_business_cases(self):
        cases=json.loads((ROOT/'tests/cases.json').read_text(encoding='utf-8'))
        for case,contract in cases.items():
            with self.subTest(case=case):
                run,_=scenario(case,'on',self.temp.name)
                for field,expected in contract['expected'].items():
                    self.assertEqual(run['observations'][field],expected,(case,field))

    def test_wrong_and_or_mutation_is_detected_by_business_expectation(self):
        import app.domain as domain
        original=domain.check_connect
        # Directed defect in an isolated function namespace; original test expectation stays fixed.
        source=(ROOT/'app/domain.py').read_text(encoding='utf-8')
        start=source.index('def check_connect(');end=source.index('\n\ndef check_path(',start)
        changed=source[start:end].replace('source_allowed and target_allowed','source_allowed or target_allowed')
        self.assertNotEqual(changed,source[start:end])
        namespace=dict(vars(domain));exec(compile(changed,'deliberate-and-or-mutant','exec'),namespace)
        with patch.object(domain,'check_connect',namespace['check_connect']):
            run,_=scenario('connect_source_only','off',self.temp.name)
            self.assertTrue(run['observations']['ok'],'mutant must execute, not fail to load')
            self.assertNotEqual(run['observations']['ok'],False,'independent denial assertion detects defect')
        self.assertIs(domain.check_connect,original)

    def test_concurrent_create_and_snapshot(self):
        store=Store(Path(self.temp.name)/'concurrency.sqlite3');store.seed_demo()
        app=Projects(store)
        barrier=threading.Barrier(6)
        def create(i):
            barrier.wait();result=app.create_project('alice',f'并发{i}','collection');store.snapshot();return result
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
            results=list(pool.map(create,range(6)))
        self.assertTrue(all(r['ok'] for r in results))
        self.assertEqual(len({r['project_id'] for r in results}),6)
        self.assertEqual(len(store.snapshot()['operations']),6)

    def test_revoke_commits_before_execute_waiting_for_writer(self):
        store=Store(Path(self.temp.name)/'linearized.sqlite3');store.seed_demo();app=Projects(store)
        link=app.configure_relation('alice','collect-a','records','process-b','records')['link_id']
        before=read_db(store.path,"SELECT * FROM port_values WHERE project_id='process-b'")
        db=store.connect();db.execute('BEGIN IMMEDIATE')
        db.execute("DELETE FROM grants WHERE project_id='process-b' AND actor='alice'")
        started=threading.Event()
        def execute(): started.set();return app.execute_relation('alice',link)
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future=pool.submit(execute);self.assertTrue(started.wait(2));db.commit();db.close();result=future.result(timeout=8)
        self.assertFalse(result['ok']);self.assertEqual(result['code'],'connect_denied')
        self.assertEqual(before,read_db(store.path,"SELECT * FROM port_values WHERE project_id='process-b'"))

    def test_database_error_rolls_back_target_write(self):
        store=Store(Path(self.temp.name)/'rollback.sqlite3');store.seed_demo();app=Projects(store)
        link=app.configure_relation('alice','collect-a','records','process-b','records')['link_id']
        before=read_db(store.path,"SELECT * FROM port_values WHERE project_id='process-b'")
        alter(store.path,"CREATE TRIGGER fail_finish BEFORE UPDATE ON operations BEGIN SELECT RAISE(ABORT,'test-only'); END")
        with self.assertRaises(sqlite3.IntegrityError): app.execute_relation('alice',link)
        self.assertEqual(before,read_db(store.path,"SELECT * FROM port_values WHERE project_id='process-b'"))


if __name__=='__main__':unittest.main()
