"""Independent expectations and real SQLite scenarios."""
