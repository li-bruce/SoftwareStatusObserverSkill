"""Public protocol, independent evidence, isolation, retention and shared runtime copies."""
import copy
import concurrent.futures
import hashlib
import json
import tempfile
import threading
import shutil
import unittest
import urllib.request
import urllib.error
from pathlib import Path
from app.ports import BOTrace
from app.domain import Projects
from app.store import Store
from bo_stategraph import bo_validate_export
from integrations.bo_adapter import BOAdapter
from integrations.bo_server import bo_http_server
from observer_runtime.bo_web import BOWeb
from observer_runtime.mapping_contract import assess_projections
from observer_runtime.semantic_probe import Pins
from observer_runtime.bo_retention import EventHistory
from tests.scenarios import ROOT,scenario


class ObserverTests(unittest.TestCase):
    def setUp(self):
        parent=ROOT/'data/test-tmp';parent.mkdir(parents=True,exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=parent);self.addCleanup(self.temp.cleanup)

    def test_observation_off_and_sink_fault_do_not_change_results(self):
        reports=[scenario('execute_current',mode,self.temp.name)[0] for mode in ('on','off','fault')]
        self.assertEqual(reports[0]['observations'],reports[1]['observations'])
        self.assertEqual(reports[0]['observations'],reports[2]['observations'])
        self.assertGreater(len(reports[0]['events']),0)
        self.assertEqual(reports[1]['events'],[])
        self.assertGreater(reports[2]['health']['errors'],0)
        rejected,_=scenario('execute_revoked','on',self.temp.name)
        attempt=rejected['actual_runs'][-1]['id']
        final=[e for e in rejected['events'] if e['attempt']==attempt and e['node']=='operation_result']
        self.assertEqual([e['phase'] for e in final],['return'])
        self.assertFalse(any(e['attempt']==attempt and e['node']=='transfer_effect' for e in rejected['events']))

    def test_builder_failure_and_disabled_builder(self):
        def broken():raise RuntimeError('payload builder failed')
        BOTrace().bo_emit('unused','return',broken)
        adapter=None
        store=Store(Path(self.temp.name)/'builder.sqlite3');store.seed_demo()
        adapter=BOAdapter(ROOT,store)
        try:
            trace=adapter.events.bo_trace('fixture')
            trace.bo_emit('create_project','return',broken)
            self.assertGreater(adapter.pins.health()['errors'],0)
            self.assertTrue(Projects(store,events=adapter.events).create_project('alice','仍可工作','collection')['ok'])
        finally:adapter.close()

    def test_public_export_and_wrong_projection_are_detected(self):
        run,exported=scenario('execute_current','on',self.temp.name)
        bo_validate_export(exported)
        self.assertTrue(all(e['attempt'] in {r['id'] for r in run['actual_runs']} for e in run['events']))
        self.assertTrue(all('journal' in cfg for cfg in run['projection']['machine']['configurations']))
        self.assertIsInstance(run['projection']['machine']['current'],str)
        plan=json.loads((ROOT/'mapping.json').read_text(encoding='utf-8'))
        plan['cases']=['execute_current'];plan['modes']=['on']
        payload={'build_id':exported['build_id'],'runs':[run],'stategraph_export':exported}
        errors,count=assess_projections(payload,plan,exported['model'],exported['build_id'])
        self.assertEqual(errors,[]);self.assertGreater(count,0)
        changed=copy.deepcopy(payload);changed['runs'][0]['actual_runs'][-1]['target_id']='wrong-recipient'
        self.assertTrue(assess_projections(changed,plan,exported['model'],exported['build_id'])[0])
        changed=copy.deepcopy(payload);changed['runs'][0]['projection']['instances']=[]
        with self.assertRaises(ValueError):assess_projections(changed,plan,exported['model'],exported['build_id'])
        changed=copy.deepcopy(exported);changed['instances']=[]
        with self.assertRaises(ValueError):bo_validate_export(changed)

    def test_loaded_shared_runtime_matches_installed_manifest(self):
        manifest=json.loads((ROOT/'bo_stategraph/runtime-version.json').read_text(encoding='utf-8'))
        self.assertGreater(len(manifest['files']),10)
        for path,digest in manifest['files'].items():
            with self.subTest(path=path):self.assertEqual(hashlib.sha256((ROOT/path).read_bytes()).hexdigest(),digest)

    def test_bounded_queue_and_history_keep_visible_gaps(self):
        model=json.loads((ROOT/'behavior.json').read_text(encoding='utf-8'))
        entered=threading.Event();release=threading.Event();received=[]
        def sink(text):
            entered.set();release.wait(3);received.append(json.loads(text))
        pins=Pins(model,'bounded-test',sink=sink,capacity=1)
        trace=pins.attempt('bounded')
        builder=lambda:{'inputs':{'actor':'alice','secret':'synthetic-unselected-field'},'outputs':{'project_id':'p'}}
        try:
            trace.record('create_project','return',{},builder);self.assertTrue(entered.wait(2))
            trace.record('create_project','return',{},builder)
            trace.record('create_project','return',{},builder)
            self.assertGreater(pins.health()['dropped'],0)
        finally:release.set();pins.close()
        self.assertNotIn('synthetic-unselected-field',json.dumps(received))
        history=EventHistory(limits={'memory_events':2,'memory_seconds':60,'log_bytes':1048576,'log_backups':1})
        for i in range(8):history.append({'id':str(i),'seq':i})
        self.assertEqual(len(history.snapshot()),2);self.assertEqual(history.health()['evicted_events'],6)

    def test_recording_uses_real_events_and_remains_read_only(self):
        store=Store(Path(self.temp.name)/'recording.sqlite3');store.seed_demo()
        adapter=BOAdapter(ROOT,store,recordings=True)
        try:
            app=Projects(store,build_id=adapter.manifest['build_id'],events=adapter.events)
            started=adapter.recordings.start('实际提交')
            app.create_project('alice','录制中的项目','collection');adapter.pins.flush()
            adapter.recordings.sample();saved=adapter.recordings.stop()
            record=adapter.recordings.get(saved['id'])
            before=store.snapshot()
            self.assertGreater(len(record['events']),0)
            self.assertTrue(any(e['phase']=='commit' for e in record['events']))
            adapter.recordings.get(saved['id'])
            self.assertEqual(before,store.snapshot())
        finally:adapter.close()

    def test_concurrent_business_export_and_recording(self):
        store=Store(Path(self.temp.name)/'concurrent-recording.sqlite3');store.seed_demo()
        adapter=BOAdapter(ROOT,store,recordings=True)
        try:
            app=Projects(store,build_id=adapter.manifest['build_id'],events=adapter.events)
            adapter.recordings.start('并发执行与只读查询')
            barrier=threading.Barrier(3)
            def write():
                barrier.wait()
                return [app.create_project('alice',f'并发录制{i}','collection') for i in range(8)]
            def read():
                barrier.wait()
                for _ in range(8):bo_validate_export(adapter.bo_export())
            def record():
                barrier.wait()
                for _ in range(8):adapter.recordings.sample()
            with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
                futures=[pool.submit(fn) for fn in (write,read,record)]
                results=[f.result(timeout=20) for f in futures]
            self.assertTrue(all(item['ok'] for item in results[0]))
            adapter.pins.flush();adapter.recordings.sample()
            saved=adapter.recordings.stop();recorded=adapter.recordings.get(saved['id'])
            self.assertEqual(len(store.snapshot()['operations']),8)
            self.assertEqual(sum(e['node']=='operation_result' for e in recorded['events']),8)
        finally:adapter.close()

    def test_web_disable_and_restore_preserves_business_and_python_query(self):
        root=Path(self.temp.name)/'web-root';root.mkdir()
        shutil.copytree(ROOT/'static',root/'static')
        store=Store(root/'demo.sqlite3');store.seed_demo()
        adapter=BOAdapter(ROOT,store,recordings=True)
        app=Projects(store,build_id=adapter.manifest['build_id'],events=adapter.events)
        server=bo_http_server(root,app,adapter,0)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base=f'http://127.0.0.1:{server.server_port}'
        def get(path):
            with urllib.request.urlopen(base+path,timeout=5) as response:return response.read()
        try:
            self.assertEqual(get('/graph'),(ROOT/'static/graph/index.html').read_bytes())
            web=BOWeb(root,assets=root/'static/graph');web.set_mode('disabled')
            for path in ('/graph','/api/view','/api/stategraph/export'):
                with self.assertRaises(urllib.error.HTTPError) as error:get(path)
                self.assertEqual(error.exception.code,404)
            self.assertIn(b'data-bo-entry hidden',get('/'))
            request=urllib.request.Request(base+'/api/create',data=json.dumps({'actor':'alice','name':'Web 关闭后','type':'collection'}).encode(),headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(request,timeout=5) as response:self.assertTrue(json.load(response)['ok'])
            self.assertEqual(len(json.loads(get('/api/projects'))['operations']),1)
            bo_validate_export(adapter.bo_export())
            web.set_mode('visible')
            self.assertEqual(get('/graph'),(ROOT/'static/graph/index.html').read_bytes())
            self.assertEqual(json.loads(get('/api/view'))['machine']['current'],'completed')
        finally:server.shutdown();thread.join(5);server.server_close();adapter.close()


if __name__=='__main__':unittest.main()
