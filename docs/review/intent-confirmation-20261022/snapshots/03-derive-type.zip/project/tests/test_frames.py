"""Frozen regression expectations for actual transaction-bound event frames."""
import concurrent.futures
import copy
import hashlib
import json
import tempfile
import threading
import unittest
from pathlib import Path
from unittest.mock import patch
from app.domain import Projects
from app.store import Store
from bo_stategraph import bo_validate_export
from integrations.bo_adapter import BOAdapter
from tests.scenarios import ROOT,read_db


class FrameTests(unittest.TestCase):
    def setUp(self):
        parent=ROOT/'data/test-tmp';parent.mkdir(parents=True,exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=parent);self.addCleanup(self.temp.cleanup)
        self.store=Store(Path(self.temp.name)/'frames.sqlite3');self.store.seed_demo()
        self.adapter=BOAdapter(ROOT,self.store,recordings=True);self.addCleanup(self.adapter.close)
        self.app=Projects(self.store,build_id=self.adapter.manifest['build_id'],events=self.adapter.events)
        self.expected=json.loads((ROOT/'tests/frame_expectations.json').read_text(encoding='utf-8'))

    def target_hash(self):
        raw=read_db(self.store.path,"SELECT value_json FROM port_values WHERE project_id='process-b' AND port='records' AND direction='in'")[0]['value_json']
        return hashlib.sha256(raw.encode()).hexdigest()

    def frames(self,view):
        self.assertIn('runtime_frames',view,'no event-bound runtime frames')
        result={f['event_id']:f for f in view['runtime_frames']['frames']}
        self.assertEqual(len(result),len(view['events']))
        for event in view['events']:
            frame=result[event['id']]
            for key in ('run_id','build_id','revision'):self.assertEqual(frame[key],event[key])
            cfg=frame['machine']['configurations'][0]
            self.assertEqual(cfg['attempt'],event['attempt'])
            self.assertEqual(frame['authority']['entity'],event['attempt'])
            self.assertEqual(frame['authority']['state'],cfg['phase'])
        return result

    def test_success_rejection_recording_export_and_immutability(self):
        link=self.app.configure_relation('alice','collect-a','records','process-b','records')['link_id']
        self.adapter.pins.flush();self.adapter.recordings.start('冻结预期的状态帧回归')
        old_hash=self.target_hash()
        good=self.app.execute_relation('alice',link);self.adapter.pins.flush()
        successful=copy.deepcopy(self.adapter.bo_view());frames=self.frames(successful)
        new_hash=self.target_hash();self.assertNotEqual(old_hash,new_hash)
        for event in successful['events']:
            if event['attempt']!=good['operation_id']:continue
            frame=frames[event['id']];cfg=frame['machine']['configurations'][0]
            if event['node'] in self.expected['success']:
                self.assertEqual(cfg['phase'],self.expected['success'][event['node']])
            if event['node']=='transfer_data':
                self.assertEqual(frame['machine']['shared_resources']['transfer_effect']['target_input_hash'],old_hash)
            if event['node']=='transfer_effect':
                self.assertEqual(frame['machine']['shared_resources']['transfer_effect']['target_input_hash'],new_hash)
                self.assertEqual(cfg['context']['value_hash'],new_hash)
            self.assertEqual(frame['authority']['parameters']['link_id'],link)
        bad=self.app.execute_relation('dave',link);self.adapter.pins.flush()
        view=self.adapter.bo_view();all_frames=self.frames(view)
        for ident,old in frames.items():self.assertEqual(all_frames[ident],old)
        for event in view['events']:
            if event['attempt']!=bad['operation_id']:continue
            frame=all_frames[event['id']];cfg=frame['machine']['configurations'][0]
            if event['node'] in self.expected['rejected']:
                self.assertEqual(cfg['phase'],self.expected['rejected'][event['node']])
            self.assertEqual(frame['machine']['shared_resources']['transfer_effect']['target_input_hash'],new_hash)
            self.assertNotEqual(event['node'],'transfer_effect')
        self.assertEqual(self.target_hash(),new_hash)
        self.adapter.recordings.sample();saved=self.adapter.recordings.stop()
        record=self.adapter.recordings.get(saved['id'])
        record_frames={f['event_id']:f for f in record['runtime_frames']['frames']}
        self.assertEqual(set(record_frames),{e['id'] for e in record['events']})
        self.assertEqual(record['gaps'],[])
        for ident,frame in record_frames.items():self.assertEqual(frame,all_frames[ident])
        exported=self.adapter.bo_export();bo_validate_export(exported)
        self.assertEqual(exported['runtime']['runtime_frames'],view['runtime_frames'])
        changed=copy.deepcopy(exported);changed['runtime']['runtime_frames']['frames'][0]['revision']+=100
        from bo_stategraph import bo_digest
        changed['sha256']=bo_digest({k:v for k,v in changed.items() if k!='sha256'})
        with self.assertRaisesRegex(ValueError,'frame'):bo_validate_export(changed)
        reloaded=json.loads((Path(self.temp.name)/'recordings'/f"{saved['id']}.json").read_text(encoding='utf-8'))
        self.assertEqual(reloaded['runtime_frames'],record['runtime_frames'])

    def test_uncommitted_checking_frame_is_captured_at_source_not_sampled_after_return(self):
        import app.domain as domain
        link=self.app.configure_relation('alice','collect-a','records','process-b','records')['link_id']
        entered=threading.Event();release=threading.Event();original=domain.check_path
        def held(*args,**kwargs):
            result=original(*args,**kwargs);entered.set();release.wait(5);return result
        with patch.object(domain,'check_path',held),concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future=pool.submit(self.app.execute_relation,'alice',link)
            try:
                self.assertTrue(entered.wait(3));self.adapter.pins.flush()
                view=self.adapter.bo_view();frames=self.frames(view)
                event=next(e for e in reversed(view['events']) if e['node']=='execute_permission')
                frame=frames[event['id']]
                self.assertEqual(frame['authority']['state'],'checking')
                self.assertEqual(frame['authority']['parameters']['target_id'],'process-b')
                self.assertEqual(read_db(self.store.path,'SELECT id FROM operations WHERE id=?',(event['attempt'],)),[])
                frozen=copy.deepcopy(frame)
            finally:release.set()
            self.assertTrue(future.result(timeout=5)['ok'])
        self.adapter.pins.flush()
        self.assertEqual(self.frames(self.adapter.bo_view())[event['id']],frozen)

    def test_snapshot_failure_is_isolated_from_business(self):
        link=self.app.configure_relation('alice','collect-a','records','process-b','records')['link_id']
        with patch('app.domain.bo_transaction_frame',side_effect=RuntimeError('deliberate snapshot read failure')):
            result=self.app.execute_relation('alice',link)
        self.assertTrue(result['ok']);self.adapter.pins.flush()
        raw=read_db(self.store.path,"SELECT value_json FROM port_values WHERE project_id='collect-a'")[0]['value_json']
        self.assertEqual(self.target_hash(),hashlib.sha256(raw.encode()).hexdigest())
        self.assertGreater(self.adapter.pins.health()['errors'],0)

    def test_expired_frames_are_reported_as_gaps(self):
        self.adapter.history.limits['memory_events']=2
        self.adapter.recordings.start('有界缺口')
        for i in range(3):self.assertTrue(self.app.create_project('alice',str(i),'collection')['ok'])
        self.adapter.pins.flush();view=self.adapter.bo_view()
        self.assertLessEqual(len(view['events']),2)
        self.assertLessEqual(len(view['runtime_frames']['frames']),2)
        saved=self.adapter.recordings.stop();record=self.adapter.recordings.get(saved['id'])
        self.assertTrue(any('快照' in gap for gap in record['gaps']))


if __name__=='__main__':unittest.main()
