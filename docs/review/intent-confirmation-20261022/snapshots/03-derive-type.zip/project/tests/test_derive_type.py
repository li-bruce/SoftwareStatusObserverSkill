"""Round 6 regression expectations written and run before feature implementation."""
import json
import tempfile
import threading
import unittest
import urllib.request
from pathlib import Path
from app.domain import Projects
from app.store import Store
from integrations.bo_adapter import BOAdapter
from integrations.bo_server import bo_http_server
from tests.scenarios import ROOT,read_db,scenario


class DeriveTypeTests(unittest.TestCase):
    def setUp(self):
        parent=ROOT/'data/test-tmp';parent.mkdir(parents=True,exist_ok=True)
        self.temp=tempfile.TemporaryDirectory(dir=parent);self.addCleanup(self.temp.cleanup)

    def test_frozen_type_cases_in_on_off_fault_modes(self):
        cases=json.loads((ROOT/'tests/cases.json').read_text(encoding='utf-8'))
        inputs=json.loads((ROOT/'tests/derive_type_inputs.json').read_text(encoding='utf-8'))
        for case in inputs:
            for mode in ('on','off','fault'):
                with self.subTest(case=case,mode=mode):
                    run,_=scenario(case,mode,self.temp.name)
                    for field,expected in cases[case]['expected'].items():
                        self.assertEqual(run['observations'][field],expected,(case,mode,field))

    def test_http_selected_type_and_omitted_default(self):
        store=Store(Path(self.temp.name)/'http.sqlite3');store.seed_demo()
        adapter=BOAdapter(ROOT,store,recordings=True)
        service=Projects(store,build_id=adapter.manifest['build_id'],events=adapter.events)
        server=bo_http_server(ROOT,service,adapter,0)
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        def derive(values):
            request=urllib.request.Request(f'http://127.0.0.1:{server.server_port}/api/derive',
                data=json.dumps({'actor':'bob','source_id':'collect-a','name':'HTTP 类型试用',**values}).encode(),
                headers={'Content-Type':'application/json'})
            with urllib.request.urlopen(request,timeout=5) as response:return json.load(response)
        try:
            selected=derive({'target_type':'processing'})
            row=read_db(store.path,'SELECT * FROM projects WHERE id=?',(selected['project_id'],))[0]
            self.assertEqual(row['type'],'processing','HTTP must forward the explicitly selected existing type')
            self.assertEqual(row['source_id'],'collect-a');self.assertEqual(row['owner'],'bob')
            default=derive({})
            self.assertEqual(read_db(store.path,'SELECT type FROM projects WHERE id=?',(default['project_id'],))[0]['type'],'collection')
            self.assertEqual(read_db(store.path,'SELECT * FROM port_values WHERE project_id=?',(selected['project_id'],)),[])
        finally:server.shutdown();thread.join(5);server.server_close();adapter.close()


if __name__=='__main__':unittest.main()
