# 当前验收：第 6 轮可选派生类型

日期：2026-10-22，Asia/Shanghai。需求原文在 `dialogue/round-006-derive-type.md`。本轮仅修改 R2：可指定已有类型，未指定沿用来源；来源权限、空项目和其他业务规则不变。

## 可运行交付

- 程序：http://127.0.0.1:8870/
- 运行图：http://127.0.0.1:8870/graph
- 环境：Windows，Python 3.13.13，标准库 SQLite/HTTP。
- 现有数据库 `data/final.sqlite3` 继续使用，旧项目、操作和录制均保留。当前服务 PID 78700，启动记录为 `evidence/app-server-final.json`；这是本次验证时点的状态。
- 构建：`173a0e7fd4b3634105c12fc6df3dc88456c9a3ec27d1f0e7e48bf2323441ffc5`。
- 接受候选：`ee2202994bcdd5e7cd9796fec6937965494e28c94d69ad424a2359ab5c1f4ecf`，回执 `.stategraph/derive-type/accepted.json`。

页面“从已有项目派生”新增“新项目类型”：默认沿用来源，也可选择采集、处理或报告。函数/API 可选参数为 `target_type`，省略或 null 沿用来源；页面默认不发送该字段。选择不存在的类型以 unknown_type 拒绝。新项目由创建者拥有，保留来源 ID，不复制数据、连接或显式授权。

## 验证结果

| 分项 | 结果 | 证据与范围 |
| --- | --- | --- |
| 实现映射 | 通过 | 10 个 Python 实现文件、13 个绑定源文件、29 个图节点；44 个辅助符号分类；117 个实际值见证、2112 项实例字段对照。 |
| 状态约束 | 通过 | checking/completed/rejected 生命周期保持；定义、逐实例投影、事件绑定帧及公开导出仍有效。无等待、恢复或汇合流程，不将其计为通过。 |
| 业务规则 | 通过 | 33 场景 × on/off/fault 三模式，共 99 次场景运行，408/408 项断言。原 25 场景原值保留，新增 8 场景。 |
| 白盒检查 | 通过 | 6 条规则、24 项检查。本轮新增 1 条规则、7 项检查在功能实现前冻结；首版后补白盒的历史偏差不被消除。 |
| 项目回归 | 通过 | 19 个 unittest 方法。覆盖 HTTP 转发、默认回退、空项目、来源权限、无效类型，以及前轮事务、隔离、并发、录制、状态帧等回归。 |
| 日常门禁 | 通过 | verify → accept → check 和 architecture_guard 完成。当前运行 build 与接受回执一致。 |
| 故意漏同步 | 被检测 | 未改副本 gate=0；仅改源码或新增未登记文件均 gate=1。原有 AND→OR 业务错误检测也继续通过。 |
| 页面交互 | 通过所列任务 | 1280 像素页面跨类型派生、默认沿用和无权限拒绝；320 像素页面实际派生报告项目。不是人工易用性结论。 |
| 个人视图 | 保留 | 实现更新前后配置字节完全一致；浏览器验收后原 13 个节点位置、名称、批注与核心标记均不变，新增 5 个子节点位置。 |

机器结果在 `evidence/derive-type/verify-final.json`、`gate-final.json`、`gate-rehearsal-final.json`。完整单元测试结果在 `.stategraph/derive-type/checks/test-0.json`；24 项白盒结果在该目录的 `whitebox.json`。故意遗漏副本及错误输出在 `evidence/gate-rehearsal/b2ae6056c5284cb0aac7c3e0fecfe1b6/`。

## 真实的预期、失败与修复顺序

1. 从前轮已接受状态开始 `.stategraph/derive-type`，保存旧源码、模型、预期、回执和个人配置。仅 R2 被登记为允许变更。
2. 实现前追加 8 场景、62 项业务断言、7 项白盒检查。冻结文件与测试哈希分别为 `frozen-expectations-hashes.json`、`frozen-tests-hashes.json`；新增内容索引为 `frozen-new-expectations.json`。
3. 在旧实现运行新增测试：21 个子用例报不接受 target_type；HTTP 实际创建 collection，而预期为 processing，产生 1 个断言失败。默认省略参数的路径继续通过。真实输出在 `before/regression.stderr.log`。
4. 修改函数、API、表单及探针，新增回归通过。首次 inspect 仍因 D1 变更缺少完整 previous 历史而失败；从本轮开始前归档补入旧 D1 及 U6 来源，保留 `inspect-01-failed.json`，随后复查通过。
5. 完整 verify、真实浏览器录制、公开导出复核、accept 与门禁完成。`preservation-before-ui.json` 证明旧 checks/白盒项未变、mapping 只增加场景、冻结预期及测试哈希未改；不存在通过调整旧结果来消除回归的行为。

本节相对路径均以 `evidence/derive-type/` 为根。首版和状态帧修复的回执继续在 `.stategraph/initial/`、`.stategraph/runtime-frames/`；前轮完整验收说明保存于 `evidence/derive-type/before/VERIFICATION.md`。`FAILURES.md` 保留各轮失败及边界。

## 真实录制与独立数据复核

本轮记录 `cfd2e4de22224d0d88ca203f57ce9bc0`，页面选择项“21:35:27 · 26 个事件”。26 个事件对应 26 个状态帧，gaps=[]；录制与公开导出的同名帧逐项一致。

| 实际操作 | 请求类型 | 来源类型 | 选定类型 | 独立 SQLite 复核 |
| --- | --- | --- | --- | --- |
| 小周派生处理项目 | processing | collection | processing | 所有者 bob、来源 collect-a；数据/显式授权/连接均为 0 |
| 小周默认派生 | 未指定，探针为 null | collection | collection | 所有者 bob、来源 collect-a；数据/显式授权/连接均为 0 |
| 访客小王派生 | report | collection | 权限拒绝，未进入类型选择 | 没有创建该名称的新项目 |
| 小周窄屏派生报告 | report | collection | report | 所有者 bob、来源 collect-a；数据/显式授权/连接均为 0 |

回放第 6 步显示 source_type=collection、target_type=processing、selected_type=processing、allowed=true；第 13 步显示 target_type=null、selected_type=collection。二者状态帧均为 checking，能够定位 `app/domain.py:137` 的 `Projects.derive_project`。最终记录继续区分完成和拒绝，未以终态覆盖早期帧。

完整原件：`evidence/derive-type/view-final.json`、`export-final.json`、`recording-final.json`；独立 SQL 与个人视图对照在 `http-proof.json`。截图为 `app-processing-empty.png`、`app-320-report.png`、`replay-selected-type-source.png`、`replay-default-type.png`。

## 复现与边界

启动、示例和日常命令见 `README.md`。运行 `python -B -X utf8 tooling/gate.py` 核验当前接受状态；完整场景为 `python -B -X utf8 observe.py`；故意漏同步演练为 `python -B -X utf8 tooling/rehearse_gate.py`。修改代码后按 `AGENTS.md` 开启新变更，不重新建立基线掩盖漂移。

本轮是授权的模拟需求迭代及独立 AI 使用，不是真人易用性研究。状态帧覆盖对应操作、实际上下文及选定目标输入，不是整个数据库历史或完整因果证明。演示用户选择器不是生产认证；未引入后台算法、审批、取消或恢复。前轮对白盒制定顺序的偏差保留；本轮前置约束通过不能追认初版完全符合 Skill 流程。未修改或推送 Skill 仓库。
