"""Run all protected scenarios in on/off/fault modes and return real observations."""
import json
import uuid
from pathlib import Path
from tests.scenarios import scenario
from bo_stategraph.workflow import DEFINITION


def main():
    root=Path(__file__).resolve().parent
    cases=json.loads((root/'tests/cases.json').read_text(encoding='utf-8'))
    directory=root/'evidence/runs'/uuid.uuid4().hex
    runs=[];public=None
    for case in cases:
        for mode in ['on','off','fault']:
            run,exported=scenario(case,mode,directory)
            runs.append(run)
            if case=='execute_current' and mode=='on': public=exported
    payload={'build_id':public['build_id'],'machine':DEFINITION,'runs':runs,'stategraph_export':public,
             'mapping_checks':[check for run in runs for check in run['mapping_checks']]}
    (directory/'observations.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(payload,ensure_ascii=False))


if __name__=='__main__':main()
