"""One-time pre-implementation plan; its output is preserved in the baseline."""
import copy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def save(name, value):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    d = json.loads((ROOT / 'discovery.json').read_text(encoding='utf-8'))
    text = (ROOT / 'dialogue/round-004.md').read_text(encoding='utf-8').split('## ')[1].split('\n', 1)[1].strip()
    d['sources'].append(dict(id='U4', kind='user', text=text, locator='dialogue/round-004.md; authorized simulated requester'))
    item = next(x for x in d['decisions'] if x['id'] == 'D4')
    d['changes'].append(dict(id='C-D4-resolved', decision='D4', previous=copy.deepcopy(item), source_refs=['U4'], reason='明确使用执行时当前权限和规则，失败不写目标。'))
    item.update(status='resolved', resolution=dict(kind='user_answer', text='每次执行重新检查两端 connect 及类型端口规则，失败不写目标数据。', source_refs=['U4']))
    item.pop('note', None)
    for net in d['networks']:
        for n in net['nodes']:
            if n['id'] == 'execute_permission':
                n.update(label='每次执行重验两端 connect', summary=item['resolution']['text'], source_refs=['U4'])
        for e in net['edges']:
            if e['id'] == 'execute_guard':
                e.update(label='当前两端 connect 同时满足', source_refs=['U4'])
    reqs = [
        ('R1','可独立创建项目，创建者成为所有者。','U1/U2'),
        ('R2','同类型派生独立新项目，记录来源 ID。','U2'),
        ('R3','派生不复制数据、连接、授权；创建者为新所有者。','U2'),
        ('R4','派生需来源所有者或显式 derive。','U2'),
        ('R5','连接配置需两端分别满足所有者或显式 connect。','U2'),
        ('R6','仅采集到处理、处理到报告；独立项目也可连接。','U2'),
        ('R7','端口存在、输出到输入、格式标识相同。','U2'),
        ('R8','建连接不传数据，手动执行复制当前 JSON 值。','U2'),
        ('R9','固定演示用户和授权；不自动处理算法或新增内容校验。','U2/U4'),
        ('R10','执行重新检查当前操作者两端 connect 及类型端口规则，失败不写目标。','U4')]
    save('intent.json', dict(intent_id='project-flow', project_id='project-flow-trial-20261022', revision='1', goal=d['goal'],
         requirements=[dict(id=i,text=t,status='confirmed',source='dialogue/round-002.md + round-004.md; '+s) for i,t,s in reqs],
         exclusions=['生产认证与授权管理页面','JSON 内容业务校验','自动算法、排队、审批、取消恢复','未覆盖行为的正确性证明']))
    # Expectations are authored before the implementation, never derived from its predicates.
    expected = {
      'create':('R1',{'ok':True,'owner':'alice','project_type':'collection','source_id':None}),
      'derive_owner':('R2',{'ok':True,'owner':'alice','project_type':'collection','source_id':'collect-a'}),
      'derive_grant':('R4',{'ok':True,'owner':'bob','project_type':'collection','source_id':'collect-a'}),
      'derive_denied':('R4',{'ok':False,'code':'derive_denied','project_delta':0}),
      'derive_nocopy':('R3',{'ok':True,'data_count':0,'grant_count':0,'link_count':0}),
      'connect_owner':('R5',{'ok':True,'target_unchanged':True}),
      'connect_grants':('R5',{'ok':True,'target_unchanged':True}),
      'connect_source_only':('R5',{'ok':False,'code':'connect_denied','target_unchanged':True}),
      'connect_target_only':('R5',{'ok':False,'code':'connect_denied','target_unchanged':True}),
      'connect_neither':('R5',{'ok':False,'code':'connect_denied','target_unchanged':True}),
      'independent_projects':('R6',{'ok':True,'both_independent':True}),
      'type_skip':('R6',{'ok':False,'code':'invalid_path','target_unchanged':True}),
      'missing_port':('R7',{'ok':False,'code':'invalid_path','target_unchanged':True}),
      'reverse_port':('R7',{'ok':False,'code':'invalid_path','target_unchanged':True}),
      'format_mismatch':('R7',{'ok':False,'code':'invalid_path','target_unchanged':True}),
      'execute_current':('R8',{'ok':True,'target_value':{'batch':'new','items':[1,2,3]},'source_unchanged':True}),
      'execute_revoked':('R10',{'ok':False,'code':'connect_denied','target_unchanged':True}),
      'execute_other_actor':('R10',{'ok':False,'code':'connect_denied','target_unchanged':True}),
      'execute_type_changed':('R10',{'ok':False,'code':'invalid_path','target_unchanged':True}),
      'execute_port_changed':('R10',{'ok':False,'code':'invalid_path','target_unchanged':True}),
      'execute_format_changed':('R10',{'ok':False,'code':'invalid_path','target_unchanged':True}),
      'no_algorithm':('R9',{'ok':True,'result_unchanged':True}),
      'json_values':('R9',{'ok':True,'values_preserved':True}),
      'manual_retry':('R10',{'ok':True,'first_rejected':True,'target_value':{'batch':'A','items':[{'id':1,'value':12}]}}),
      'missing_output':('R8',{'ok':False,'code':'no_source_value','target_unchanged':True})}
    save('tests/cases.json', {case:dict(requirement=r,expected=e) for case,(r,e) in expected.items()})
    checks=[dict(id=case+'-'+k,requirement=r,case=case,path=[k],equals=v) for case,(r,values) in expected.items() for k,v in values.items()]
    save('acceptance.json',dict(description='Independent expectations fixed before implementation',checks=checks,model_checks=[]))
    links={'D1':['R2','R3'],'D2':['R4','R5'],'D3':['R6','R7','R8','R9'],'D4':['R10']}
    for decision in d['decisions']:
        rs=links[decision['id']]
        decision['links']=dict(requirements=rs,model_nodes=[x for x in decision['affects'] if any(x==n['id'] for net in d['networks'] for n in net['nodes'])],checks=[x['id'] for x in checks if x['requirement'] in rs])
    save('discovery.json',d)
    # This baseline is a design declaration, deliberately not an executable model.
    save('behavior.json',dict(schema_version=3,revision='design-1',project_id=d['project_id'],intent='intent.json',source_files=['app/__init__.py'],nodes=[n for net in d['networks'] for n in net['nodes']],edges=[],overview=[],scope={'unknowns':['implementation pending']}))
    fields=[dict(id=x,node='transfer_data',actual=[x],mapped=[x]) for x in ['state','revision','build_id']]
    fields += [dict(id=x,node='transfer_data',actual=[x],mapped=['context',x]) for x in ['actor','action','source_id','target_id','link_id','reason','effect_id','value_hash']]
    save('mapping.json',dict(schema='bo-mapping/v1',cases=list(expected),modes=['on','off','fault'],source='tests/scenarios.py independent SQLite SELECT operations',actual_collection=['actual_runs'],actual_id=['id'],fields=fields,export={'case':'execute_current','mode':'on'}))
    save('sync.json',dict(model='behavior.json',manifest='manifest.json',code_files=['app/__init__.py'],watch_files=['discovery.json','requirements.md','tests/cases.json','tooling/plan_trial.py'],discovery='discovery.json',acceptance='acceptance.json',mapping_contract='mapping.json',require_mapping_witnesses=True,probe_modes=['on','off','fault'],observations_command=['{python}','-B','-X','utf8','observe.py'],test_commands=[['{python}','-B','-X','utf8','-m','unittest','discover','-s','tests','-v']],timeout_seconds=180,source_scope={'roots':['.'],'require_symbol_classification':True,'exclude':{'tooling/**':'Project build and gate tooling, explicitly watched.','tests/**':'Independent scenarios and tests, explicitly watched.','.stategraph/**':'Immutable baseline and isolated negative checks.','evidence/**':'Trial evidence, not shipped implementation.'}}))


if __name__ == '__main__':
    main()
