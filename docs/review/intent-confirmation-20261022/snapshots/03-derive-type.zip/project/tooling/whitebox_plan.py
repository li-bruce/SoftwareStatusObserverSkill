"""Materialize actual-parameter checks for the already confirmed business rules."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]


def main():
    definitions=[
      ('derive','R4','derive_permission','Projects.derive_project',{'actor':'str','source_id':'str','name':'str'},'dict','派生权限来自当前来源项目'),
      ('connect','R5','relation_permission','check_connect',{'actor':'str','source':'dict','target':'dict'},'bool','连接两端同时允许'),
      ('execute','R10','execute_permission','check_connect',{'actor':'str','source':'dict','target':'dict'},'bool','执行时两端当前权限同时允许'),
      ('path','R7','type_port_rules','check_path',{'source':'dict','source_port':'str','target':'dict','target_port':'str'},'bool','存在的输出和输入端口满足类型与格式规则'),
      ('copy','R8','transfer_data','Projects.execute_relation',{'actor':'str','link_id':'str'},'dict','当前源版本与实际复制值绑定')]
    rules=[dict(id=i,requirement=r,node=n,source={'path':'app/domain.py','symbol':s},parameters=p,returns=ret,claim=claim,basis='dialogue/round-002.md and round-004.md; independent tests/cases.json',category='decision' if i!='copy' else 'parameter') for i,r,n,s,p,ret,claim in definitions]
    checks=[]
    def add(ident,rule,case,fields,phase='decision',select=None):
        value=dict(id=ident,rule=rule,case=case,phase=phase,count={'min':1},fields=[{'path':path,'equals':v} for path,v in fields])
        if select:value['select']=select
        checks.append(value)
    for case,allowed in [('derive_owner',True),('derive_grant',True),('derive_denied',False)]:
        add(case+'-permission','derive',case,[(['outputs','allowed'],allowed),(['inputs','source_id'],'collect-a')])
    for case,a,b in [('connect_owner',True,True),('connect_grants',True,True),('connect_source_only',True,False),('connect_target_only',False,True),('connect_neither',False,False)]:
        add(case+'-permission','connect',case,[(['outputs','source_allowed'],a),(['outputs','target_allowed'],b),(['outputs','allowed'],a and b)])
    for case,a,b in [('execute_current',True,True),('execute_revoked',True,False),('execute_other_actor',True,False)]:
        add(case+'-permission','execute',case,[(['outputs','source_allowed'],a),(['outputs','target_allowed'],b),(['outputs','allowed'],a and b)])
    for case,fields in [('independent_projects',[('allowed',True)]),('type_skip',[('type_ok',False),('allowed',False)]),('missing_port',[('source_output_exists',False),('allowed',False)]),('reverse_port',[('target_input_exists',False),('allowed',False)]),('format_mismatch',[('format_ok',False),('allowed',False)])]:
        add(case+'-path','path',case,[(['outputs',k],v) for k,v in fields])
    add('copy-current-version','copy','execute_current',[(['inputs','source_revision'],2),(['inputs','source_id'],'collect-a'),(['inputs','target_id'],'process-b')],phase='return')
    checks[-1]['fields'].append({'path':['outputs','value_hash'],'type':'string','compare':{'path':['inputs','value_hash'],'op':'eq'}})
    (ROOT/'whitebox.json').write_text(json.dumps({'schema_version':1,'rules':rules,'checks':checks},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':main()
