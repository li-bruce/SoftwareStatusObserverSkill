"""Run the normal accepted-project gate against isolated, deliberately stale copies."""
import json
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    evidence=ROOT/'evidence/gate-rehearsal'/uuid.uuid4().hex
    clone=evidence/'project'
    shutil.copytree(ROOT,clone,ignore=shutil.ignore_patterns('evidence','data','dist','__pycache__','.git'))
    def gate():
        run=subprocess.run([sys.executable,'-B','-X','utf8',str(clone/'tooling/gate.py')],cwd=clone,capture_output=True,text=True,encoding='utf-8',timeout=90)
        return {'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr}
    baseline=gate()
    if baseline['returncode']:raise AssertionError('isolated unchanged copy must pass: '+baseline['stdout'])
    domain=clone/'app/domain.py';original=domain.read_text(encoding='utf-8')
    mutant=original.replace('source_allowed and target_allowed','source_allowed or target_allowed')
    assert mutant!=original
    domain.write_text(mutant,encoding='utf-8')
    stale=gate()
    (evidence/'domain-mutant.py.txt').write_text(mutant,encoding='utf-8')
    domain.write_text(original,encoding='utf-8')
    (clone/'app/unregistered.py').write_text('def undocumented_operation():\n    return "must be discovered"\n',encoding='utf-8')
    unregistered=gate()
    report={'baseline':baseline,'source_changed_without_sync':stale,'unregistered_source':unregistered}
    (evidence/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    assert stale['returncode']!=0 and unregistered['returncode']!=0,report
    assert 'unregistered' in unregistered['stdout'].lower(),unregistered
    print(json.dumps({'passed':True,'evidence':str(evidence/'report.json'),'baseline_exit':0,'stale_exit':stale['returncode'],'unregistered_exit':unregistered['returncode']},ensure_ascii=False))


if __name__=='__main__':main()
