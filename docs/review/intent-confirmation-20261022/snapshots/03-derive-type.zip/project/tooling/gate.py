"""Normal delivery gate: accepted source synchronization plus architecture boundaries."""
import subprocess
import sys
from pathlib import Path


def main():
    root=Path(__file__).resolve().parents[1]
    for script in ['change_sync.py','architecture_guard.py']:
        result=subprocess.run([sys.executable,'-B','-X','utf8',str(root/'observer_runtime'/script),'check','--root',str(root)],cwd=root)
        if result.returncode:return result.returncode
    return 0


if __name__=='__main__':raise SystemExit(main())
