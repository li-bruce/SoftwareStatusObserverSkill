"""One-time, preimplementation expectations from authorized round 6, never runtime results."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]


def main():
    def read(name):return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
    def save(name,value):(ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if (ROOT/'tests/derive_type_inputs.json').exists():raise ValueError('plan already frozen; do not regenerate expectations')
    inputs={
      'derive_type_processing':{'actor':'bob','source_id':'collect-a','target_type':'processing'},
      'derive_type_report':{'actor':'alice','source_id':'collect-a','target_type':'report'},
      'derive_type_collection':{'actor':'bob','source_id':'process-b','target_type':'collection'},
      'derive_type_same':{'actor':'bob','source_id':'collect-a','target_type':'collection'},
      'derive_type_omitted':{'actor':'bob','source_id':'process-b'},
      'derive_type_null':{'actor':'alice','source_id':'collect-a','target_type':None},
      'derive_type_invalid':{'actor':'alice','source_id':'collect-a','target_type':'not-existing'},
      'derive_type_denied':{'actor':'dave','source_id':'collect-a','target_type':'processing'}}
    expected_types={'derive_type_processing':'processing','derive_type_report':'report','derive_type_collection':'collection',
                    'derive_type_same':'collection','derive_type_omitted':'processing','derive_type_null':'collection'}
    cases=read('tests/cases.json');acceptance=read('acceptance.json');mapping=read('mapping.json');whitebox=read('whitebox.json')
    added={}
    for case,args in inputs.items():
        if case in expected_types:
            expected={'ok':True,'owner':args['actor'],'source_id':args['source_id'],'project_type':expected_types[case],
                      'data_count':0,'grant_count':0,'link_count':0,'source_unchanged':True,'project_delta':1}
        else:expected={'ok':False,'code':'derive_denied' if case=='derive_type_denied' else 'unknown_type','project_delta':0,'source_unchanged':True}
        added[case]={'requirement':'R2','expected':expected};cases[case]=added[case];mapping['cases'].append(case)
        for key,value in expected.items():acceptance['checks'].append({'id':case+'-'+key,'requirement':'R2','case':case,'path':[key],'equals':value})
    whitebox['rules'].append({'id':'derive-type','requirement':'R2','node':'derive_type','source':{'path':'app/domain.py','symbol':'Projects.derive_project'},
        'parameters':{'actor':'str','source_id':'str','name':'str','target_type':'str | None'},'returns':'dict','claim':'可选已有类型，省略或 null 沿用来源类型',
        'basis':'dialogue/round-006-derive-type.md; frozen before implementation','category':'decision'})
    for case,args in inputs.items():
        if case=='derive_type_denied':continue
        source_type='collection' if args['source_id']=='collect-a' else 'processing'
        selected=expected_types.get(case,'not-existing')
        whitebox['checks'].append({'id':case+'-selection','rule':'derive-type','case':case,'phase':'decision','count':{'min':1,'max':1},
            'fields':[{'path':path,'equals':value} for path,value in [(['inputs','target_type'],args.get('target_type')),(['inputs','source_type'],source_type),
                     (['outputs','selected_type'],selected),(['outputs','allowed'],case!='derive_type_invalid')]]})
    save('tests/derive_type_inputs.json',inputs);save('tests/cases.json',cases);save('acceptance.json',acceptance);save('mapping.json',mapping);save('whitebox.json',whitebox)
    save('evidence/derive-type/frozen-new-expectations.json',{'inputs':inputs,'cases':added,'whitebox_rule':whitebox['rules'][-1],'whitebox_checks':whitebox['checks'][-7:]})
    intent=read('intent.json');intent['revision']='2'
    rule=next(r for r in intent['requirements'] if r['id']=='R2')
    rule.update(text='派生独立新项目并记录来源 ID；允许指定已有项目类型，未指定沿用来源类型。',source='dialogue/round-006-derive-type.md; U6 overrides only type selection in U2')
    save('intent.json',intent)
    discovery=read('discovery.json')
    discovery['sources'].append({'id':'U6','kind':'user','text':'派生新项目时允许指定另一个已有项目类型，未指定仍用来源类型；仍然是空项目，不继承连接、数据或授权。请同步更新图和检查。',
                                 'locator':'dialogue/round-006-derive-type.md; authorized simulated requester iteration'})
    for network in discovery['networks']:
        for node in network['nodes']:
            if node['id'] in ('derive_project','project_derived'):
                node['source_refs'].append('U6')
                node['summary']='可指定 collection / processing / report；未指定沿用来源类型。保留来源 ID、由创建者拥有，数据、连接和授权均为空。'
            if node['id']=='project_derived':node['label']='独立空项目：可选类型、记录来源'
    business=next(n for n in discovery['networks'] if n['id']=='business')
    business['nodes'].append({'id':'derive_type','label':'派生类型：指定已有类型或沿用来源','kind':'condition','parent':'derive_project',
                              'source_refs':['U6'],'model_nodes':['derive_type'],'summary':'选填类型；未指定沿用来源，显式指定须属于已有项目类型。'})
    business['edges'].append({'id':'derive_type_guard','from':'derive_type','to':'derive_project','relation':'guard','label':'可选已有类型，默认沿用来源','source_refs':['U6'],'decision_refs':['D1']})
    d1=next(d for d in discovery['decisions'] if d['id']=='D1')
    discovery.setdefault('changes',[]).append({'id':'round-006-derive-type','decision':'D1','previous':json.loads(json.dumps(d1)),
        'source_refs':['U6'],'reason':'U6 明确允许指定已有类型，未指定沿用来源；其余派生语义保留。'})
    d1['resolution']['text']='U2 initially required same-type empty derivation. U6 now permits an existing target type and defaults to the source type; source ID, creator ownership and empty data/links/grants remain unchanged.'
    d1['resolution']['source_refs'].append('U6')
    d1['affects'].append('derive_type')
    save('discovery.json',discovery)
    print(json.dumps({'added_cases':len(added),'added_assertions':sum(len(c['expected']) for c in added.values()),'added_whitebox_checks':7}))


if __name__=='__main__':main()
