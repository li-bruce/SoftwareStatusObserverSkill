"""Run the local demo: python -X utf8 server.py --port 8870."""
import argparse
from pathlib import Path
from app.store import Store
from app.domain import Projects
from integrations.bo_adapter import BOAdapter
from integrations.bo_server import bo_http_server


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port',type=int,default=8870)
    parser.add_argument('--db',type=Path)
    parser.add_argument('--probe-mode',choices=['on','off','fault'],default='on')
    args=parser.parse_args()
    root=Path(__file__).resolve().parent
    store=Store(args.db or root/'data/demo.sqlite3');store.seed_demo()
    adapter=BOAdapter(root,store,args.probe_mode,recordings=True)
    service=Projects(store,build_id=adapter.manifest['build_id'],events=adapter.events)
    server=bo_http_server(root,service,adapter,args.port)
    print(f'Project Flow: http://127.0.0.1:{server.server_port}/ ; graph: /graph',flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close();adapter.close()


if __name__=='__main__': main()
