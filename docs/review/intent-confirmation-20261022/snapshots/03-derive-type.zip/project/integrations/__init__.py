"""Optional observer and HTTP integration."""
