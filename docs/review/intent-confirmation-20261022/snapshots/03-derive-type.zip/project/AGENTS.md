# 本项目的开发约定

业务来源只读本项目 dialogue/、requirements.md、intent.json 和 discovery.json。需求方是经授权的模拟角色；不得编造答复，不读取协调会话的评估或其他试用聊天。使用本地安装 business-observer，公共运行库由 bo_upgrade 安装，禁止修改 Skill 仓库。

默认按已确认状态网指导实现；项目内普通 Python/SQLite 决定真实结果，图只读。后续修改必须保留同一图的节点身份、源码映射、探针和独立预期。未决业务含义用普通最终回复提出，不使用 request_user_input 工具。

使用 UTF-8；Windows 下传绝对项目根路径，避免当前运行环境 Path('.').resolve() 重复目录的问题。

1. 读 .stategraph/active.json；已有未完成变更时继续它，不新建基线。
2. 新变更：`python -X utf8 observer_runtime/change_sync.py begin --root C:/Users/Lvi_P/Documents/Work/CF/平台软著/project-flow-trial-20261022 --change .stategraph/变更名 --request 实际请求 --requirements 实际受影响的需求ID`。
3. 编码后运行 `python -X utf8 tooling/build_model.py` 和 `python -X utf8 observer_runtime/bo_sync.py scan --root C:/Users/Lvi_P/Documents/Work/CF/平台软著/project-flow-trial-20261022`；读取 maintenance.json 并处理任务。
4. 运行 change_sync.py inspect，审阅遗漏后更新 tooling/review_candidate.py 的分类说明并执行它；不能用重新 capture 或修改原预期隐藏失败。
5. 运行 change_sync.py verify → accept → check（均传上述绝对 --root），再运行 `python -X utf8 tooling/gate.py`。失败不得报告通过。
6. 给出更新图、业务和映射检查结果、实际边界；页面业务操作不能放进调试图中。测试文件按 tests/ 中已有清单选取，独立预期保留。

只有请求会改变行为含义时澄清，不增加整图审批。无授权管理界面、生产登录、内容规则、后台算法、排队或恢复流程。
