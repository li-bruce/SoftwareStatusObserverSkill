"""One adapter from real SQLite operations to the public instance protocol."""
import hashlib
from .workflow import CONTEXT


def bo_machine(snapshot):
    configurations = []
    for row in snapshot['operations']:
        configurations.append({'attempt':row['id'], 'phase':row['state'], 'state_revision':row['revision'],
                               'run_build_id':row['build_id'], 'context':{k:row[k] for k in CONTEXT},
                               'revision':row['revision'], 'param_version':1, 'journal':[]})
    return {'configurations':configurations, 'current':configurations[-1]['phase'] if configurations else None,
            'journal':[], 'state_revision':sum(r['revision'] for r in snapshot['operations'])}


def bo_transaction_frame(db, operation_id, context):
    """Read the active transaction, never a final result or inferred event order.

    State/revision come from SQL; context is the operation's actual local context.
    A frame covers this operation and selected input facts, not the whole database.
    """
    row=dict(db.execute('SELECT * FROM operations WHERE id=?',(operation_id,)).fetchone())
    machine=bo_machine({'operations':[row]})
    selected={key:context[key] for key in CONTEXT}
    machine['configurations'][0]['context']=selected
    link=db.execute('SELECT target_id,target_port FROM links WHERE id=?',(selected['link_id'],)).fetchone()
    target_id=link['target_id'] if link else selected['target_id']
    if link:
        value=db.execute("SELECT value_json,revision,port FROM port_values WHERE project_id=? AND port=? AND direction='in'",(target_id,link['target_port'])).fetchone()
    else:
        value=db.execute("SELECT value_json,revision,port FROM port_values WHERE project_id=? AND direction='in' ORDER BY port LIMIT 1",(target_id,)).fetchone()
    resource={'target_id':target_id,'target_input_hash':'','target_input_revision':0,'target_input_preview':'(absent)'}
    if value:
        resource.update(target_input_hash=hashlib.sha256(value['value_json'].encode('utf-8')).hexdigest(),
                        target_input_revision=value['revision'],target_input_preview=value['value_json'][:180])
    machine['shared_resources']={'transfer_effect':resource}
    return {'machine':machine,'authority':{'entity':operation_id,'state':row['state'],
            'basis':{'param_version':1},'parameters':{'attempt':operation_id,**selected},'effects':[]}}
