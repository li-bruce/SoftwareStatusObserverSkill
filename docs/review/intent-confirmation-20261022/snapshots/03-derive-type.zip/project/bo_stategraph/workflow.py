"""Declared lifecycle of a synchronous database operation; no extra business workflow."""
from .bo_contracts import validate_runtime_definition

CONTEXT = {k: {'type': 'string'} for k in
           ('actor', 'action', 'source_id', 'target_id', 'link_id', 'reason', 'effect_id', 'value_hash')}
DEFINITION = {
    'engine': 'python.explicit', 'version': '1', 'state_type': 'OperationState',
    'states': ['checking', 'completed', 'rejected'], 'values': ['checking', 'completed', 'rejected'],
    'labels': {'checking': '检查中', 'completed': '已提交', 'rejected': '已拒绝'},
    'initial': 'checking', 'context': CONTEXT,
    'events': {'commit': {'payload': {}}, 'reject': {'payload': {}}}, 'guards': {},
    'transitions': [
        {'source': 'checking', 'trigger': 'commit', 'dest': 'completed'},
        {'source': 'checking', 'trigger': 'reject', 'dest': 'rejected'}],
}


def validate_loaded():
    validate_runtime_definition(DEFINITION, loaded_engine='python.explicit', loaded_version='1', guard_names=[])


def next_state(state: str, event: str) -> str:
    for transition in DEFINITION['transitions']:
        if transition['source'] == state and transition['trigger'] == event:
            return transition['dest']
    raise ValueError('undeclared operation transition')
