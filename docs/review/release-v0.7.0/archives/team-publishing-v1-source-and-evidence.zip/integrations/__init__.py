"""Optional observer adapter bootstrap; no domain side effects."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"observer_runtime"))
