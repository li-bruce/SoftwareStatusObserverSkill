// Optional observation of actual browser interactions; no business decisions.
import { BOProbe } from "/api/bo/runtime.mjs";
let probe = null;
export async function initializeObserver() {
  try {
    const response = await fetch("/api/bo/settings");
    const settings = await response.json();
    if (settings.enabled) probe = new BOProbe(settings);
    return settings.enabled ? settings.endpoint + "/graph?lang=zh-CN" : null;
  } catch { return null; }
}
export function recordInteraction(node, ok) {
  try { probe?.record(node, ok ? "return" : "error", () => ({ inputs: {}, outputs: { ok } })); }
  catch { /* Observation never changes the business outcome. */ }
}

