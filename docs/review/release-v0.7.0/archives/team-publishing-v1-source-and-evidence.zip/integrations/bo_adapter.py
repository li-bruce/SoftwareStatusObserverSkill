"""Project adapter for the exact supplied BOProbe and BODataRuntime."""
import json
import os
from pathlib import Path
from app.ports import NullObserver
from observer_runtime.behavior_model import capture
from observer_runtime.bo_observer.adapters.python.bo_probe import BOProbe
from observer_runtime.bo_observer.data.runtime import BODataRuntime

class BOAdapter(NullObserver):
    def __init__(self, project, build_id, *, settings=None, sink=None, enabled=True, capacity=4096):
        self.project, self.build_id, self.settings = project, build_id, settings
        self.probe=BOProbe(project,build_id,endpoint=(settings or {}).get('endpoint',''),token=(settings or {}).get('token',''),sink=sink,enabled=enabled,capacity=capacity)
        self.data_runtime=BODataRuntime(self.probe,json.loads((Path(__file__).resolve().parents[1]/'bo_stategraph/databases.json').read_text(encoding='utf-8')))
        self.last_snapshot={}

    @classmethod
    def from_settings(cls, root):
        project=json.loads((root/'bo_stategraph/project.json').read_text(encoding='utf-8'))
        settings=json.loads((root/'.stategraph/collector.json').read_text(encoding='utf-8'))
        build_id=capture(root,project['model'])['build_id']
        if build_id!=settings['build_id']: raise ValueError('observer build differs from loaded application')
        mode=os.environ.get("TEAM_OBSERVATION","on")
        def failed_transport(body,kind):
            raise OSError("Injected observer transport failure")
        result=cls(project,build_id,settings=settings,enabled=mode!="off",sink=failed_transport if mode=="fault" else None)
        result.data_runtime=BODataRuntime(result.probe,json.loads((root/'bo_stategraph/databases.json').read_text(encoding='utf-8')))
        return result

    def record(self,node,phase,inputs=None,outputs=None,material=None):
        try:
            instance=str(material['id']) if material else 'application'
            revision=material['revision'] if material else None
            eid=self.probe.record(node,phase,lambda:{'inputs':inputs or {},'outputs':outputs or {}},
                entity=instance,revision=revision,scope='entity' if material else 'application')
            if material and eid:
                context={'content_version':material['content_version'],'author_id':material['author_id'],'publication_count':int(material['state']=='approved')}
                self.probe.snapshot(instance,material['state'],context,revision,eid)
                self.last_snapshot[instance]={'id':instance,'state':material['state'],'revision':revision,'context':context}
            return eid
        except Exception:
            return None

    def data(self,node,callback,**options):
        return self.data_runtime.execute(node,callback,**options)

    def transaction(self,engine):
        return self.data_runtime.transaction('db.transaction',engine.begin())

    def transform(self,node,function,value):
        return self.data_runtime.transform(node,function,value,
            before=lambda item:{'content_version':item['content_version'],'title_length':len(item['title']),'body_length':len(item['body'])},
            after=lambda item:{'content_version':item['content_version'],'title_length':len(item['title']),'body_length':len(item['body'])})

    def flush(self):
        return self.probe.flush(15)

    def close(self):
        self.probe.flush(3)
        self.data_runtime.close()
        self.probe.close()

