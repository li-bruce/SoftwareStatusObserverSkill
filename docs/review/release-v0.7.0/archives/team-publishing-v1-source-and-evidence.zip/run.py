"""Launch the application and supplied observer as independently owned local processes."""
import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
from urllib.request import urlopen

ROOT=Path(__file__).resolve().parent

def free_port():
    with socket.socket() as listener:
        listener.bind(('127.0.0.1',0))
        return listener.getsockname()[1]

def fetch(url):
    with urlopen(url,timeout=1) as response:return json.load(response)

def spawn(arguments,log,environment):
    options={}
    if os.name=='nt':
        startup=subprocess.STARTUPINFO();startup.dwFlags|=subprocess.STARTF_USESHOWWINDOW
        options={'startupinfo':startup,'creationflags':subprocess.CREATE_NO_WINDOW}
    return subprocess.Popen(arguments,cwd=ROOT,env=environment,stdout=log,stderr=subprocess.STDOUT,**options)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--app-port',type=int,default=0)
    parser.add_argument('--graph-port',type=int,default=0)
    parser.add_argument('--database',default=str(ROOT/'data/team.sqlite'))
    parser.add_argument('--no-observer',action='store_true')
    parser.add_argument('--probe-mode',choices=['on','off','fault'],default='on')
    args=parser.parse_args()
    app_port=args.app_port or free_port();graph_port=args.graph_port or free_port()
    app_url='http://127.0.0.1:'+str(app_port);graph_url='http://127.0.0.1:'+str(graph_port)
    environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TEAM_DATABASE=str(Path(args.database).resolve()),TEAM_OBSERVATION=args.probe_mode)
    environment['TEAM_DATABASE_URL']='sqlite:///'+Path(args.database).resolve().as_posix()
    runtime=ROOT/'.stategraph';runtime.mkdir(exist_ok=True)
    processes=[];logs=[]
    try:
        from app.service import Service
        initializer=Service(args.database);initializer.initialize();initializer.close()
        if not args.no_observer:
            log=(runtime/'observer.log').open('w',encoding='utf-8');logs.append(log)
            observer=spawn([sys.executable,'-B','-X','utf8','observer_runtime/bo.py','serve','--root',str(ROOT),'--port',str(graph_port),'--origin',app_url],log,environment)
            processes.append(observer)
            deadline=time.monotonic()+30
            while time.monotonic()<deadline:
                if observer.poll() is not None:raise RuntimeError('Observer startup failed; see .stategraph/observer.log')
                try:
                    health=fetch(graph_url+'/api/bo/health')
                    if health['binding']['status']=='current':break
                except Exception:time.sleep(.2)
            else:raise RuntimeError('Observer did not become ready')
        else:
            environment['TEAM_OBSERVATION']='off'
        app_log=(runtime/'application.log').open('w',encoding='utf-8');logs.append(app_log)
        arguments=[sys.executable,'-B','-X','utf8','-m','uvicorn','app.web:create_app','--factory','--host','127.0.0.1','--port',str(app_port)]
        application=spawn(arguments,app_log,environment);processes.append(application)
        deadline=time.monotonic()+30
        while time.monotonic()<deadline:
            if application.poll() is not None:raise RuntimeError('Application startup failed; see .stategraph/application.log')
            try:app_health=fetch(app_url+'/api/bo/app-health');break
            except Exception:time.sleep(.2)
        else:raise RuntimeError('Application did not become ready')
        state={'application_url':app_url,'graph_url':None if args.no_observer else graph_url+'/graph?lang=zh-CN','app_pid':application.pid,'observer_pid':None if args.no_observer else observer.pid,'launcher_pid':os.getpid(),'database':environment['TEAM_DATABASE'],'build_id':app_health['build_id'],'probe_mode':args.probe_mode}
        (runtime/'runtime.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
        print('Application: '+app_url,flush=True)
        print('Graph: '+(state['graph_url'] or 'disabled'),flush=True)
        loaded_build=app_health['build_id']
        while application.poll() is None:
            time.sleep(1)
            if not args.no_observer and observer.poll() is None:
                try:
                    health=fetch(graph_url+'/api/bo/health')
                    if health['binding']['status']=='current' and health['build_id']!=loaded_build:
                        settings_path=runtime/'collector.json'
                        settings=json.loads(settings_path.read_text(encoding='utf-8'))
                        settings['build_id']=health['build_id']
                        settings_path.write_text(json.dumps(settings),encoding='utf-8')
                        application.terminate();application.wait(5)
                        application=spawn(arguments,app_log,environment);processes.append(application)
                        loaded_build=health['build_id']
                        state.update(app_pid=application.pid,build_id=loaded_build)
                        (runtime/'runtime.json').write_text(json.dumps(state,indent=2)+'\n',encoding='utf-8')
                except Exception:
                    pass
        raise RuntimeError('Application exited; see .stategraph/application.log')
    except KeyboardInterrupt:
        pass
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.terminate()
                try:process.wait(5)
                except subprocess.TimeoutExpired:process.kill()
        for log in logs:log.close()

if __name__=='__main__':main()

