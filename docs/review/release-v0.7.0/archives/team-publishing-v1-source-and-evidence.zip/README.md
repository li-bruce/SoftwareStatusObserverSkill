# Team publishing Demo — accepted v1

See [QUICKSTART.md](QUICKSTART.md) for installation, the two test accounts, recording and source inspection.

All four native acceptance gates passed. The exact build, recording and report locations are in [evidence/v1-release.json](evidence/v1-release.json). The full original verification receipt is [review/verification-v1.json](review/verification-v1.json).

The evidence directory preserves actual simulated-user answers, original failures, upstream fixes, retests and screenshots. No independent human usability test is claimed. The next requested iteration (message read markers and unread count) is not implemented in v1.
