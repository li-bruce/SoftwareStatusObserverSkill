"""Independent business regression entrypoint with frozen expected outcomes."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/"observer_runtime"))
from tooling.scenarios import CASES,execute

def main():
    expectations=json.loads((ROOT/'acceptance.json').read_text(encoding='utf-8'))['checks']
    results={case:execute(case)['observations'] for case in CASES}
    checked=0
    for check in expectations:
        if check['case'] not in results:continue
        value=results[check['case']]
        for part in check['path']:value=value[part]
        assert value==check['equals'],(check['id'],value,check['equals'])
        checked+=1
    assert results['concurrency']['outcomes']==[200,409]
    print(json.dumps({'passed':True,'assertions':checked+1,'cases':list(results)}))
if __name__=='__main__':main()

