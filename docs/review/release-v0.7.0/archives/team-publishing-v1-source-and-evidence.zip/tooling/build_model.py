"""Generate one source-bound graph from confirmed intent and explicit capture contracts."""
import ast
import json
import os
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/"observer_runtime"))
from observer_runtime.code_structure import scan,enrich
from observer_runtime.bo_observer.data.sync import synchronize
from observer_runtime.bo_observer.data.contract import capture_spec
from observer_runtime.implementation_coverage import static_errors
from app.service import Service

def read(name):
    return json.loads((ROOT/name).read_text(encoding='utf-8-sig'))

def write(name,value):
    p=ROOT/name;p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def build():
    doc=read('discovery.json')
    selection={'mode':'observe','source':'user','answer':'选 observe，业务代码自己执行，图用来观察。','locator':'evidence/conversation/002-user-answer.txt'}
    files=sorted([p.relative_to(ROOT).as_posix() for folder in ['app','integrations'] for p in (ROOT/folder).glob('*') if p.suffix in ('.py','.js')]+['static/app.js','bo_stategraph/query.py'])
    index=scan(ROOT,files)
    if index['errors']:raise ValueError(index['errors'])
    write('review/source-inventory.json',index)
    nodes=[];edges=[]
    service={
      'member_login':('login','成员登录',{'username_present':'boolean','password_present':'boolean','rule':'string'},{'actor_id':'number','role':'string','allowed':'boolean'},'R1'),
      'logout':('logout','退出登录',{'token_present':'boolean'},{'actor_id':'number'},'R1'),
      'current_user':('current','读取当前账号',{'token_present':'boolean'},{'actor_id':'number','role':'string'},'R1'),
      'submit_material':('submit','提交标题与文本资料',{'token_present':'boolean','title_length':'number','body_length':'number','actor_id':'number','rule':'string'},{'material_id':'number','state':'string','content_version':'number','revision':'number','allowed':'boolean'},'R2'),
      'notify_reviewer':('notify','负责人收到系统内消息',{'material_id':'number','content_version':'number'},{'recipient_id':'number'},'R2'),
      'review_material':('review','负责人审核',{'token_present':'boolean','actor_id':'number','material_id':'number','decision':'string','expected_version':'number','content_version':'number','expected_revision':'number','revision':'number','rule':'string'},{'state':'string','content_version':'number','revision':'number','publication_count':'number','allowed':'boolean'},'R6'),
      'continue_rejected':('edit','原提交人修改同一份资料',{'token_present':'boolean','actor_id':'number','material_id':'number','title_length':'number','body_length':'number','expected_version':'number','content_version':'number','expected_revision':'number','revision':'number','rule':'string'},{'state':'string','content_version':'number','revision':'number','allowed':'boolean'},'R4'),
      'resubmit_material':('resubmit','重新提交审核',{'token_present':'boolean','actor_id':'number','material_id':'number','expected_version':'number','content_version':'number','expected_revision':'number','revision':'number','rule':'string'},{'state':'string','content_version':'number','revision':'number','allowed':'boolean'},'R4'),
      'public_materials':('public','无需登录查看已发布资料',{}, {'count':'number'},'R5'),
      'list_materials':('listing','查看工作台资料',{'token_present':'boolean','actor_id':'number'},{'count':'number','role':'string'},'R3'),
      'read_messages':('inbox','查看自己的系统消息',{'token_present':'boolean','actor_id':'number'},{'count':'number','recipient_id':'number'},'R7'),
      'read_message':('message','按接收人读取消息',{'token_present':'boolean','actor_id':'number','message_id':'number','rule':'string'},{'recipient_id':'number','allowed':'boolean'},'R7'),
      'current_actor':('actor','重新读取账号权限',{'rule':'string'},{'actor_id':'number','role':'string','allowed':'boolean'},'R1'),
      'validate_content':('content','检查标题和文本',{'rule':'string'},{'allowed':'boolean'},'R2'),
      'load_material':('material','读取当前资料与版本',{'rule':'string','material_id':'number'},{'state':'string','content_version':'number','revision':'number','author_id':'number','allowed':'boolean'},'R6'),
      'edit_permission':('editable','校验原作者与驳回状态',{'rule':'string','actor_id':'number','author_id':'number','state':'string'},{'allowed':'boolean'},'R4'),
      'review_permission':('require','校验审核角色与待审核状态',{'rule':'string','actor_id':'number','state':'string'},{'allowed':'boolean'},'R3')}
    parents={'current_actor':'member_login','validate_content':'submit_material','load_material':'review_material','edit_permission':'continue_rejected','review_permission':'review_material','resubmit_material':'continue_rejected','logout':'member_login','current_user':'member_login','list_materials':'submit_material','read_messages':'notify_reviewer','read_message':'notify_reviewer'}
    for nid,(symbol,label,ins,outs,req) in service.items():
        node={'id':nid,'kind':'decision' if nid in ['edit_permission','review_permission','validate_content'] else 'action','layer':'business','label':label,'summary':label,'source':{'path':'app/service.py','symbol':'Service.'+symbol},'capture':{'in':ins,'out':outs},'requirements':[req]}
        if nid in parents:node['parent']=parents[nid]
        nodes.append(node)
    for nid,value,label in [('pending_review','pending','待审核'),('rejected','rejected','已驳回'),('approved','approved','已通过')]:
        nodes.append({'id':nid,'kind':'state','layer':'state','value':value,'label':label,'summary':label})
    for e in doc['networks'][0]['edges']:
        if e['id']=='rejected_resubmit':
            edges.extend([{'id':e['id'],'from':'continue_rejected','to':'resubmit_material','type':'flow','label':'保存修改后重新提交','evidence':'U003'}, {'id':'resubmit_pending','from':'resubmit_material','to':'pending_review','type':'flow','label':'重新进入待审核','evidence':'U003'}])
        else:edges.append({'id':e['id'],'from':e['from'],'to':e['to'],'type':'flow','label':e['label'],'evidence':'discovery '+','.join(e['source_refs'])})
    nodes.append({'id':'page_shell','kind':'function','layer':'business','parent':'member_login','label':'加载应用页面','summary':'Application HTML, JavaScript and CSS delivery.','source':{'path':'app/web.py','symbol':'create_app.index'},'capture':{'in':{},'out':{'asset':'string'}},'requirements':['R9']})
    ui_bind={'ui.login':'login','ui.logout':'logout','ui.submit':'saveMaterial','ui.edit':'saveMaterial','ui.edit_select':'startEdit','ui.resubmit':'resubmitMaterial','ui.review':'reviewMaterial','ui.public':'loadPublic','ui.workspace':'loadWorkspace','ui.cancel_edit':'resetEditor'}
    ui_owner={'ui.login':'member_login','ui.logout':'member_login','ui.submit':'submit_material','ui.edit':'continue_rejected','ui.edit_select':'continue_rejected','ui.resubmit':'continue_rejected','ui.review':'review_material','ui.public':'public_materials','ui.workspace':'list_materials','ui.cancel_edit':'continue_rejected'}
    for nid,symbol in ui_bind.items():
        nodes.append({'id':nid,'kind':'function','layer':'program','parent':ui_owner[nid],'label':'界面 · '+symbol,'summary':'Actual browser interaction; static calls do not establish execution.','source':{'path':'static/app.js','symbol':symbol},'capture':{'in':{},'out':{'ok':'boolean'}},'requirements':['R9']})
    machine=read('evidence/design/runtime-declaration.json') if (ROOT/'evidence/design/runtime-declaration.json').exists() else read('bo_stategraph/project.json')['model']['machine']
    write('evidence/design/runtime-declaration.json',machine)
    known={n['id'] for n in nodes}
    for node in nodes:
        if node.get('parent'):edges.append({'id':'contains.'+node['id'],'from':node['parent'],'to':node['id'],'type':'contains','evidence':'Explicit business ownership'})
    model={'schema_version':3,'revision':'1','project_id':'team-publishing-demo','intent':'intent.json','source_files':sorted(set(files+['intent.json','discovery.json','acceptance.json','mapping.json','whitebox.json','implementation.json','static/index.html','static/app.css']+[p.relative_to(ROOT).as_posix() for p in (ROOT/'tooling').glob('*') if p.suffix in ('.py','.mjs')])), 'nodes':nodes,'edges':edges,'overview':[{'node':n['id']} for n in nodes if not n.get('parent')],'graph_roots':[n['id'] for n in nodes if not n.get('parent')],'scope':{'unknowns':['Static call candidates do not prove dynamic dispatch. External libraries are outside indexed project source. Finite scenarios do not prove all schedules.']},'machine':machine,'presentation':{'subject':'团队资料发布','runtime_owner':'submit_material'}}
    operations=[]
    for table,actions in {'accounts':['read'],'sessions':['read','write'],'materials':['read','write'],'messages':['read','write'],'publications':['read','write']}.items():
        for action in actions:
            operations.append({'id':'db.'+table+'.'+action,'label':table+' · '+action,'parent':'review_material' if table in ['materials','publications'] else 'member_login' if table in ['accounts','sessions'] else 'notify_reviewer','source':{'path':'app/service.py','symbol':'Service.'+('read' if action=='read' else 'write')},'store':'team','action':action,'targets':['table:'+table],'parameters':{},'before':{},'after':{'count':'number'},'required_cases':['flow'],'requirements':['R8']})
    operations += [
      {'id':'db.transaction','label':'事务提交或回滚','parent':'review_material','source':{'path':'app/service.py','symbol':'begin_transaction'},'store':'team','action':'transaction','targets':[],'parameters':{},'before':{},'after':{},'required_cases':['flow','rollback'],'failure_cases':['rollback'],'requirements':['R8']},
      {'id':'db.publication_snapshot','label':'生成被审核版本快照','parent':'review_material','source':{'path':'app/service.py','symbol':'publication_snapshot'},'store':'team','action':'transform','targets':[],'parameters':{},'before':{'content_version':'number','title_length':'number','body_length':'number'},'after':{'content_version':'number','title_length':'number','body_length':'number'},'required_cases':['flow'],'requirements':['R5']}]
    db={'protocol':'bo-databases/v1','stores':[{'id':'team','label':'SQLite 团队资料库','engine':'sqlalchemy','url_env':'TEAM_DATABASE_URL','parent':'submit_material','selection':{'source':'user','answer':'选 SQLite + SQLAlchemy。就是本地运行的小 Demo，不要外部邮件服务。','locator':'evidence/conversation/002-user-answer.txt'},'model_layer':'SQLAlchemy Core','source_files':['app/models.py','tooling/export_data.py'],'declaration':'bo_stategraph/declaration.json'}],'operations':operations,'exporters':[{'store':'team','command':['{python}','-B','-X','utf8','tooling/export_data.py'],'output':'bo_stategraph/declaration.json'}]}
    write('bo_stategraph/databases.json',db)
    features=[];support={};excluded={}
    op_sources={}; node_map={n['id']:n for n in nodes}
    # Explicit route ownership. Selected request values are captured at the invoked service boundary.
    routes={'login':'member_login','logout':'logout','current_user':'current_user','list_materials':'list_materials','submit_material':'submit_material','edit_material':'continue_rejected','resubmit_material':'resubmit_material','review_material':'review_material','list_messages':'read_messages','get_message':'read_message','public_materials':'public_materials','index':'page_shell','javascript':'page_shell','stylesheet':'page_shell'}
    main_ids=['member_login','logout','current_user','submit_material','review_material','continue_rejected','resubmit_material','public_materials','list_materials','read_messages','read_message']
    for nid in main_ids:
        sources=['app/service.py::Service.'+service[nid][0]]+['app/web.py::create_app.'+r for r,owner in routes.items() if owner==nid]
        phases=['enter','commit'] if nid in ['member_login','logout','submit_material','review_material','continue_rejected','resubmit_material'] else ['enter','return'] if nid!='public_materials' else ['return']
        if nid in ['member_login','submit_material','review_material','continue_rejected','resubmit_material','read_message']:phases+=['decision']
        cases=[{'case':'flow','node':nid,'phase':phase} for phase in phases]
        params=[]
        for sid in sources:
            for p in index['symbols'][sid]['parameters']:
                name=p['name']
                if name in ['self','cls']:continue
                item={'source':sid,'name':name,'node':nid,'direction':'in','policy':'derived','reason':'Selected value or presence from the same actual service call; full request and credentials are never captured.'}
                fields=node_map[nid]['capture']['in']
                if name=='response':item.update(policy='context',reason='HTTP response carrier only.')
                elif name in ['token','request']:item['field']='token_present'
                elif name in ['username','password']:item['field']=name+'_present'
                elif name in ['title','body']:item['field']=name+'_length'
                elif name in ['content_version','revision']:item.update(field='expected_version' if name=='content_version' else 'expected_revision',policy='value')
                elif name in ['material_id','message_id','decision']:item.update(field=name,policy='value')
                else:item['field']='username_present' if nid=='member_login' else 'title_length' if nid in ['submit_material','continue_rejected'] else 'expected_version'
                params.append(item)
        features.append({'id':nid,'label':node_map[nid]['label'],'business_node':nid,'nodes':[nid],'sources':sources,'parameters':params,'cases':cases,'requirements':node_map[nid]['requirements']})
    helpers=['notify_reviewer','current_actor','validate_content','load_material','edit_permission','review_permission']
    features.append({'id':'runtime_checks','label':'Current authorization, data and notification checks','business_node':'review_material','nodes':helpers,'sources':['app/service.py::Service.notify'],'parameters':[{'source':'app/service.py::Service.notify','name':'connection','policy':'derived','reason':'The active connection is represented by the actual recipient query result.','node':'notify_reviewer','direction':'out','field':'recipient_id'},{'source':'app/service.py::Service.notify','name':'material','policy':'derived','reason':'Only material identity and version are captured; body is excluded.','node':'notify_reviewer','direction':'in','field':'material_id'}],'cases':[{'case':'flow','node':nid,'phase':phase} for nid,phases in {'notify_reviewer':['return'],'current_actor':['read','decision'],'validate_content':['decision'],'load_material':['read','decision'],'edit_permission':['decision'],'review_permission':['decision']}.items() for phase in phases],'requirements':['R1','R2','R3','R4','R7']})
    features.append({'id':'page_delivery','label':'Application page delivery','business_node':'member_login','nodes':['page_shell'],'sources':['app/web.py::create_app.'+r for r in ['index','javascript','stylesheet']],'parameters':[],'cases':[{'case':'flow','node':'page_shell','phase':'return'}],'requirements':['R9']})
    js_sources=[sid for sid,s in index['symbols'].items() if s['kind']=='function' and s['path']=='static/app.js' and (s.get('entrypoints') or s['symbol'] in set(ui_bind.values()))]
    js_params=[]
    for sid in js_sources:
        for p in index['symbols'][sid]['parameters']:
            js_params.append({'source':sid,'name':p['name'],'node':'ui.workspace','direction':'out','field':'ok','policy':'derived','reason':'DOM event/control objects are not captured. Successful actual action completion is recorded; authoritative business values are captured by the invoked Python service.'})
    features.append({'id':'browser_actions','label':'Actual browser forms and buttons','business_node':'submit_material','nodes':list(ui_bind),'sources':js_sources,'parameters':js_params,'cases':[{'case':'browser','node':nid,'phase':'return'} for nid in ui_bind],'requirements':['R9']})
    features.append({'id':'database_access','label':'Native database queries, transformations and transactions','business_node':'review_material','nodes':[o['id'] for o in operations],'sources':['app/service.py::Service.read','app/service.py::Service.write'],'parameters':[{'source':'app/service.py::Service.'+method,'name':name,'node':'db.materials.'+method,'direction':'in','field':'statement' if name=='statement' else 'operation','policy':'derived','reason':'Native SQL shape and operation kind are captured; connection and bound values are omitted.'} for method in ['read','write'] for name in ['connection','table','statement']],'cases':[{'case':'flow','node':o['id'],'phase':'commit' if o['action']=='transaction' else 'change' if o['action']=='transform' else 'return'} for o in operations]+[{'case':'rollback','node':'db.transaction','phase':'error'}],'requirements':['R8']})
    classified={s for f in features for s in f['sources']}
    for sid,s in index['symbols'].items():
        if s['kind']!='function' or sid in classified:continue
        if s['path'].startswith('integrations/') or s['path']=='app/ports.py' or s['path']=='bo_stategraph/query.py':
            excluded[sid]={'category':'observer','reason':'Optional observation wiring; no application decisions or authoritative writes.'}
        elif s.get('entrypoints') and s['symbol'].split('.')[-1] in ['observer_client','observer_runtime','observer_settings','health']:
            from observer_runtime.observation_scope import endpoint_paths
            excluded[sid]={'category':'observer','reason':'Exact developer-only metadata or observation transport endpoint.','routes':endpoint_paths(s)}
        elif s['symbol'].endswith('__init__'):excluded[sid]={'category':'construction','reason':'Object construction; behavior is represented by invoked methods.'}
        else:support[sid]={'node':'member_login' if s['path']=='app/web.py' else 'submit_material','reason':'Supporting implementation retained in source/code views; static evidence does not claim runtime execution.'}
    implementation={'schema':'bo-implementation/v1','features':features,'support':support,'excluded':excluded}
    model['implementation']=implementation
    model=enrich(model,index,1)
    write('implementation.json',implementation)
    write('bo_stategraph/project.json',{'protocol':'bo-project/v1','project_id':'team-publishing-demo','selection':selection,'model':model})
    cfg=read('sync.json');cfg['code_files']=files
    cfg['watch_files']=sorted(set(cfg['watch_files']+model['source_files']+['run.py']))
    write('sync.json',cfg)
    data=ROOT/'data/team.sqlite'
    bootstrap=Service(data);bootstrap.initialize();bootstrap.close()
    os.environ['TEAM_DATABASE_URL']='sqlite:///'+data.as_posix()
    result=synchronize(ROOT)
    if not result['valid']:raise ValueError(result)
    project=read('bo_stategraph/project.json')
    project['model']=enrich(project['model'],index,1)
    write('bo_stategraph/project.json',project)
    write('review/static-coverage.json',{'errors':static_errors(implementation,project['model'],index)})
    print(json.dumps({'nodes':len(project['model']['nodes']),'files':len(files),'symbols':len(index['symbols']),'unresolved_static_calls':len(index['unresolved']),'data_valid':result['valid']},ensure_ascii=False))

if __name__=='__main__':build()

