"""Predetermined business cases. Expected outcomes never come from graph declarations."""
import json
from contextlib import closing
import sqlite3
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from fastapi.testclient import TestClient
from app.service import Service, DomainError
from app.web import create_app

ROOT=Path(__file__).resolve().parents[1]
CASES=['flow','permissions','versions','concurrency','rollback','login']

def independent_snapshot(database,build_id):
    with closing(sqlite3.connect(database)) as connection, connection:
        connection.row_factory=sqlite3.Row
        rows=connection.execute('SELECT m.id, m.state, m.revision, m.author_id, m.content_version, (SELECT COUNT(*) FROM publications p WHERE p.material_id=m.id) AS publication_count FROM materials m ORDER BY m.id').fetchall()
        records=[dict(row)|{'id':str(row['id']),'build_id':build_id} for row in rows]
    return {'materials':records}

def execute(case,mode='off',project=None,build_id='not-observed'):
    parent=ROOT/'.stategraph/scenario-data';parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=parent) as directory:
        database=Path(directory)/'team.sqlite'
        service=Service(database);service.initialize()
        events=[];snapshots=[]
        if project:
            from integrations.bo_adapter import BOAdapter
            from observer_runtime.bo_observer.protocol import validate_event,validate_snapshot
            def sink(body,kind):
                if mode=='fault':raise OSError('Injected unavailable observer transport')
                if kind=='events':
                    validate_event(body,project,build_id);events.append(body)
                else:
                    validate_snapshot(body,project,build_id);snapshots.append(body)
            service.bo=BOAdapter(project,build_id,sink=sink,enabled=mode!='off')
        app=create_app(service)
        member=TestClient(app,raise_server_exceptions=False)
        reviewer=TestClient(app,raise_server_exceptions=False)
        anonymous=TestClient(app,raise_server_exceptions=False)
        assert member.post('/api/login',json={'username':'member','password':'member-demo'}).status_code==200
        assert reviewer.post('/api/login',json={'username':'reviewer','password':'reviewer-demo'}).status_code==200
        observations={}
        def submit():
            response=member.post('/api/materials',json={'title':'First title','body':'Original text'})
            assert response.status_code==200,response.text
            return response.json()
        def review(item,decision='approve',client=reviewer):
            return client.post('/api/materials/'+str(item['id'])+'/review',json={'decision':decision,'content_version':item['content_version'],'revision':item['revision']})
        def edit(item,client=member):
            return client.put('/api/materials/'+str(item['id']),json={'title':'Revised title','body':'Revised text','content_version':item['content_version'],'revision':item['revision']})
        if case=='flow':
            for path in ['/','/app.js','/app.css']:assert anonymous.get(path).status_code==200
            assert member.get('/api/me').json()['role']=='member'
            item=submit();original_id=item['id']
            observations['submitted_state']=item['state']
            inbox=reviewer.get('/api/messages').json()
            message=reviewer.get('/api/messages/'+str(inbox[0]['id'])).json()
            observations['notice_recipient']='reviewer' if message['recipient_id']==2 else 'wrong'
            member.get('/api/messages');member.get('/api/materials');reviewer.get('/api/materials')
            rejected=review(item,'reject').json()
            revised=edit(rejected).json()
            resubmitted=member.post('/api/materials/'+str(item['id'])+'/resubmit',json={'content_version':revised['content_version'],'revision':revised['revision']}).json()
            approved=review(resubmitted).json()
            public=anonymous.get('/api/public').json()
            observations.update(same_material=approved['id']==original_id,published_body=public[0]['body'],published_version=public[0]['content_version'],publication_count=len(public))
            member.post('/api/logout',json={})
        elif case=='permissions':
            item=submit()
            observations['member_review']=review(item,client=member).status_code
            rejected=review(item,'reject').json()
            observations['reviewer_edit']=edit(rejected,reviewer).status_code
            message=reviewer.get('/api/messages').json()[0]
            observations['other_messages']=member.get('/api/messages/'+str(message['id'])).status_code
            with closing(sqlite3.connect(database)) as connection, connection:
                connection.execute("UPDATE accounts SET role='member' WHERE id=2")
            observations['other_author_edit']=edit(rejected,reviewer).status_code
            with closing(sqlite3.connect(database)) as connection, connection:
                connection.execute("UPDATE accounts SET role='reviewer' WHERE id=2")
                connection.execute("UPDATE accounts SET role='reviewer' WHERE id=1")
            observations['revoked_role']=member.post('/api/materials',json={'title':'Denied','body':'Denied'}).status_code
            with closing(sqlite3.connect(database)) as connection, connection:
                connection.execute("UPDATE accounts SET role='member' WHERE id=1")
            revised=edit(rejected).json()
            item=member.post('/api/materials/'+str(revised['id'])+'/resubmit',json={'content_version':revised['content_version'],'revision':revised['revision']}).json()
            approved=review(item).json()
            observations['approved_edit']=edit(approved).status_code
        elif case=='versions':
            old=submit()
            observations['unpublished_hidden']=anonymous.get('/api/public').json()==[]
            rejected=review(old,'reject').json()
            revised=edit(rejected).json()
            current=member.post('/api/materials/'+str(revised['id'])+'/resubmit',json={'content_version':revised['content_version'],'revision':revised['revision']}).json()
            observations['stale_review']=review(old).status_code
            assert review(current).status_code==200
            observations['repeat_review']=review(current).status_code
        elif case=='concurrency':
            item=submit();barrier=Barrier(2)
            token=reviewer.cookies.get('team_session')
            def competing_review():
                barrier.wait()
                try:service.review(token,item['id'],'approve',item['content_version'],item['revision']);return 200
                except DomainError as error:return error.status
            with ThreadPoolExecutor(max_workers=2) as pool:
                outcomes=list(pool.map(lambda _:competing_review(),range(2)))
            observations['outcomes']=sorted(outcomes)
            with closing(sqlite3.connect(database)) as connection, connection:
                observations['publication_count']=connection.execute('SELECT COUNT(*) FROM publications').fetchone()[0]
        elif case=='rollback':
            with closing(sqlite3.connect(database)) as connection, connection:
                connection.execute("CREATE TRIGGER refuse_message BEFORE INSERT ON messages BEGIN SELECT RAISE(ABORT,'controlled write failure'); END")
            response=member.post('/api/materials',json={'title':'Rollback','body':'Must not survive'})
            observations['status']=response.status_code
            with closing(sqlite3.connect(database)) as connection, connection:
                observations['material_count']=connection.execute('SELECT COUNT(*) FROM materials').fetchone()[0]
        elif case=='login':
            observations['bad_password']=anonymous.post('/api/login',json={'username':'member','password':'incorrect'}).status_code
            assert member.post('/api/logout',json={}).status_code==200
            observations['after_logout']=member.get('/api/me').status_code
        service.bo.flush()
        authority=independent_snapshot(database,build_id)
        from bo_stategraph.query import bo_machine
        machine=bo_machine(database,build_id)
        diagnostics={}
        if project:
            diagnostics={'transport_errors':service.bo.probe.bo_errors,'dropped':service.bo.probe.bo_dropped,'data_errors':service.bo.data_runtime.bo_errors}
        service.close();member.close();reviewer.close();anonymous.close()
        return {'case':case,'mode':mode,'events':events,'observations':observations,'authority_snapshot':authority,'machine_snapshot':machine,'native_snapshots':snapshots,'diagnostics':diagnostics}

