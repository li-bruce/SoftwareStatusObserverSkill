"""Export native model metadata without opening or modifying the database."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/"observer_runtime"))
from app.models import metadata
from observer_runtime.bo_observer.data.catalog import export_sqlalchemy_metadata
print(json.dumps(export_sqlalchemy_metadata(metadata,'team'),ensure_ascii=False))

