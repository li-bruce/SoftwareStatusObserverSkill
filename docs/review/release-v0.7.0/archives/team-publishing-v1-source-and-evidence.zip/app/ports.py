"""Optional observation port. The default executes business work without capture."""
class NullObserver:
    def record(self, node, phase, inputs=None, outputs=None, material=None):
        return None

    def data(self, node, callback, **options):
        return callback()

    def transaction(self, engine):
        return engine.begin()

    def transform(self, node, function, value):
        return function(value)

    def flush(self):
        return True

    def close(self):
        return None
