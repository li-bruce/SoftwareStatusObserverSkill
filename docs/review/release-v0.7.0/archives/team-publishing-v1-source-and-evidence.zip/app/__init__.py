"""Team publishing application."""
