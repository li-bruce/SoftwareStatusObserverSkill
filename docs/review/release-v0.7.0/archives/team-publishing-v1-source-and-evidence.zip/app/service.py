"""Authoritative publishing behavior with transactional permission, status and version checks."""
import hashlib
import hmac
import secrets
from pathlib import Path
from sqlalchemy import create_engine, event, select, insert, update, delete
from .models import metadata, accounts, sessions, materials, publications, messages
from .ports import NullObserver

class DomainError(Exception):
    def __init__(self, status, code):
        self.status, self.code = status, code
        super().__init__(code)

def password_hash(password, salt):
    return hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 180000).hex()

def token_hash(token):
    return hashlib.sha256((token or '').encode()).hexdigest()

def publication_snapshot(material):
    return {key: material[key] for key in ('content_version','title','body','author_id')} | {'material_id':material['id']}

def configure_connection(connection, record):
    connection.isolation_level = None
    connection.execute('PRAGMA foreign_keys=ON')
    connection.execute('PRAGMA busy_timeout=15000')

def begin_transaction(connection):
    connection.exec_driver_sql('BEGIN IMMEDIATE')

class Service:
    def __init__(self, database, observer=None):
        self.database = Path(database).resolve()
        self.database.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_engine('sqlite:///' + self.database.as_posix(), connect_args={'check_same_thread':False,'timeout':15})
        event.listen(self.engine, 'connect', configure_connection)
        event.listen(self.engine, 'begin', begin_transaction)
        self.bo = observer or NullObserver()

    def initialize(self):
        metadata.create_all(self.engine)
        with self.engine.begin() as connection:
            if not connection.execute(select(accounts.c.id)).first():
                connection.execute(insert(accounts), [
                    {'id':1,'username':'member','password_hash':password_hash('member-demo','member'),'role':'member','active':1},
                    {'id':2,'username':'reviewer','password_hash':password_hash('reviewer-demo','reviewer'),'role':'reviewer','active':1}])

    def read(self, connection, table, statement):
        return self.bo.data('db.'+table.name+'.read', lambda: [dict(row) for row in connection.execute(statement).mappings()],
            connection=connection, statement=str(statement.compile(dialect=self.engine.dialect)), language='sql',
            parameters={}, summarize=lambda rows:{'rows':len(rows),'result':{'count':len(rows)}})

    def write(self, connection, table, statement):
        def execute():
            result=connection.execute(statement)
            return {'rows':result.rowcount,'id':result.inserted_primary_key[0] if result.is_insert else None}
        return self.bo.data('db.'+table.name+'.write', execute,
            connection=connection, statement=str(statement.compile(dialect=self.engine.dialect)), language='sql',
            parameters={}, summarize=lambda result:{'rows':result['rows'],'result':{'count':result['rows']}})

    def require(self, allowed, status, code, node, **facts):
        self.bo.record(node, 'decision', {'rule':code, **facts}, {'allowed':bool(allowed)})
        if not allowed:
            raise DomainError(status, code)

    def actor(self, connection, token):
        session = self.read(connection, sessions, select(sessions).where(sessions.c.token_hash==token_hash(token)))
        self.require(bool(session),401,'authentication_required','current_actor')
        found=self.read(connection, accounts, select(accounts).where(accounts.c.id==session[0]['account_id']))
        self.require(bool(found) and found[0]['active']==1,401,'account_inactive','current_actor')
        actor=found[0]
        self.bo.record('current_actor','read',{}, {'actor_id':actor['id'],'role':actor['role']})
        return actor

    def content(self, title, body):
        self.require(isinstance(title,str) and bool(title.strip()) and len(title)<=160,422,'invalid_title','validate_content')
        self.require(isinstance(body,str) and bool(body.strip()) and len(body)<=20000,422,'invalid_body','validate_content')
        return title, body

    def material(self, connection, material_id):
        found=self.read(connection,materials,select(materials).where(materials.c.id==material_id))
        self.require(bool(found),404,'material_not_found','load_material',material_id=material_id)
        item=found[0]
        self.bo.record('load_material','read',{'material_id':material_id},{'state':item['state'],'content_version':item['content_version'],'revision':item['revision'],'author_id':item['author_id']})
        return item

    def login(self, username, password):
        self.bo.record('member_login','enter',{'username_present':bool(username),'password_present':bool(password)}, {})
        with self.bo.transaction(self.engine) as connection:
            found=self.read(connection,accounts,select(accounts).where(accounts.c.username==username))
            valid=bool(found) and hmac.compare_digest(found[0]['password_hash'],password_hash(password,username)) and found[0]['active']==1
            self.require(valid,401,'invalid_credentials','member_login')
            actor=found[0]
            token=secrets.token_urlsafe(32)
            self.write(connection,sessions,insert(sessions).values(token_hash=token_hash(token),account_id=actor['id']))
        self.bo.record('member_login','commit',{}, {'actor_id':actor['id'],'role':actor['role']})
        return token, {'id':actor['id'],'username':actor['username'],'role':actor['role']}

    def logout(self, token):
        self.bo.record('logout','enter',{'token_present':bool(token)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            self.write(connection,sessions,delete(sessions).where(sessions.c.token_hash==token_hash(token)))
        self.bo.record('logout','commit',{}, {'actor_id':actor['id']})
        return {'ok':True}

    def current(self, token):
        self.bo.record('current_user','enter',{'token_present':bool(token)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            result={'id':actor['id'],'username':actor['username'],'role':actor['role']}
        self.bo.record('current_user','return',{}, {'actor_id':actor['id'],'role':actor['role']})
        return result

    def notify(self, connection, material):
        reviewers=self.read(connection,accounts,select(accounts).where(accounts.c.role=='reviewer',accounts.c.active==1))
        for reviewer in reviewers:
            self.write(connection,messages,insert(messages).values(recipient_id=reviewer['id'],material_id=material['id'],content_version=material['content_version'],text='有一份资料等待审核'))
            self.bo.record('notify_reviewer','return',{'material_id':material['id'],'content_version':material['content_version']},{'recipient_id':reviewer['id']})

    def submit(self, token, title, body):
        self.bo.record('submit_material','enter',{'token_present':bool(token),'title_length':len(title),'body_length':len(body)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            self.require(actor['role']=='member',403,'member_required','submit_material',actor_id=actor['id'])
            title,body=self.content(title,body)
            result=self.write(connection,materials,insert(materials).values(author_id=actor['id'],title=title,body=body,state='pending',content_version=1,revision=1))
            item=self.material(connection,result['id'])
            self.notify(connection,item)
        self.bo.record('submit_material','commit',{'actor_id':actor['id']},{'material_id':item['id'],'state':item['state'],'content_version':1,'revision':1},material=item)
        return item

    def listing(self, token):
        self.bo.record('list_materials','enter',{'token_present':bool(token)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            statement=select(materials).order_by(materials.c.id.desc())
            if actor['role']=='member': statement=statement.where(materials.c.author_id==actor['id'])
            elif actor['role']=='reviewer': statement=statement.where(materials.c.state=='pending')
            else: raise DomainError(403,'role_not_allowed')
            result=self.read(connection,materials,statement)
        self.bo.record('list_materials','return',{'actor_id':actor['id']},{'count':len(result),'role':actor['role']})
        return result

    def editable(self, actor, item):
        self.require(actor['role']=='member',403,'member_required','edit_permission',actor_id=actor['id'])
        self.require(item['author_id']==actor['id'],403,'author_required','edit_permission',actor_id=actor['id'],author_id=item['author_id'])
        self.require(item['state']=='rejected',409,'rejected_required','edit_permission',state=item['state'])

    def version_matches(self, item, content_version, revision, node):
        self.require(item['content_version']==content_version,409,'stale_content_version',node,expected_version=content_version,content_version=item['content_version'])
        self.require(item['revision']==revision,409,'stale_revision',node,expected_revision=revision,revision=item['revision'])

    def edit(self, token, material_id, title, body, content_version, revision):
        self.bo.record('continue_rejected','enter',{'token_present':bool(token)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            item=self.material(connection,material_id)
            self.editable(actor,item)
            self.version_matches(item,content_version,revision,'continue_rejected')
            title,body=self.content(title,body)
            self.write(connection,materials,update(materials).where(materials.c.id==material_id).values(title=title,body=body,content_version=content_version+1,revision=revision+1))
            item=self.material(connection,material_id)
        self.bo.record('continue_rejected','commit',{'actor_id':actor['id'],'material_id':material_id,'title_length':len(title),'body_length':len(body),'expected_version':content_version,'expected_revision':revision},{'state':item['state'],'content_version':item['content_version'],'revision':item['revision']},material=item)
        return item

    def resubmit(self, token, material_id, content_version, revision):
        self.bo.record('resubmit_material','enter',{'token_present':bool(token)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            item=self.material(connection,material_id)
            self.editable(actor,item)
            self.version_matches(item,content_version,revision,'resubmit_material')
            self.write(connection,materials,update(materials).where(materials.c.id==material_id).values(state='pending',revision=revision+1))
            item=self.material(connection,material_id)
            self.notify(connection,item)
        self.bo.record('resubmit_material','commit',{'actor_id':actor['id'],'material_id':material_id,'expected_version':content_version,'expected_revision':revision},{'state':item['state'],'content_version':item['content_version'],'revision':item['revision']},material=item)
        return item

    def review(self, token, material_id, decision, content_version, revision):
        self.bo.record('review_material','enter',{'token_present':bool(token)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            self.require(actor['role']=='reviewer',403,'reviewer_required','review_permission',actor_id=actor['id'])
            item=self.material(connection,material_id)
            self.require(item['state']=='pending',409,'pending_required','review_permission',state=item['state'])
            self.version_matches(item,content_version,revision,'review_material')
            self.require(decision in ('approve','reject'),422,'invalid_decision','review_material')
            state='approved' if decision=='approve' else 'rejected'
            if decision=='approve':
                snapshot=self.bo.transform('db.publication_snapshot',publication_snapshot,item)
                self.write(connection,publications,insert(publications).values(**snapshot))
            self.write(connection,materials,update(materials).where(materials.c.id==material_id).values(state=state,revision=revision+1))
            item=self.material(connection,material_id)
        self.bo.record('review_material','commit',{'actor_id':actor['id'],'material_id':material_id,'decision':decision,'expected_version':content_version,'expected_revision':revision},{'state':state,'content_version':item['content_version'],'revision':item['revision'],'publication_count':int(state=='approved')},material=item)
        return item

    def inbox(self, token):
        self.bo.record('read_messages','enter',{'token_present':bool(token)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            result=self.read(connection,messages,select(messages).where(messages.c.recipient_id==actor['id']).order_by(messages.c.id.desc()))
        self.bo.record('read_messages','return',{'actor_id':actor['id']},{'count':len(result),'recipient_id':actor['id']})
        return result

    def message(self, token, message_id):
        self.bo.record('read_message','enter',{'token_present':bool(token)}, {})
        with self.bo.transaction(self.engine) as connection:
            actor=self.actor(connection,token)
            result=self.read(connection,messages,select(messages).where(messages.c.id==message_id,messages.c.recipient_id==actor['id']))
            self.require(bool(result),404,'message_not_found','read_message',actor_id=actor['id'],message_id=message_id)
        self.bo.record('read_message','return',{'actor_id':actor['id'],'message_id':message_id},{'recipient_id':actor['id']})
        return result[0]

    def public(self):
        with self.bo.transaction(self.engine) as connection:
            result=self.read(connection,publications,select(publications).order_by(publications.c.material_id.desc()))
        self.bo.record('public_materials','return',{}, {'count':len(result)})
        return result

    def close(self):
        self.bo.close()
        self.engine.dispose()
