# Project contract

Use the project-local runtime installed from the exact user-selected Skill. Keep the source Skill repository read-only. The user selected observe mode in evidence/conversation/002-user-answer.txt and confirmed scope in 003-user-confirmation.txt. Preserve stable graph IDs and English source/documentation; use Chinese display labels.

Before behavior changes run `python observer_runtime/change_sync.py begin --root . --change .stategraph/CHANGE --request REQUEST`. Continue an active change. Maintain independent expectations, probes, all source parameters and database operations. Then run `python tooling/build_model.py`, `python observer_runtime/bo_sync.py scan --root .`, inspect and reconcile, verify, accept, and check. The final entrypoint is `python tooling/verify.py`. Never weaken expectations to obtain a pass. AI maintains these artifacts; ask users only about unresolved business meaning.

