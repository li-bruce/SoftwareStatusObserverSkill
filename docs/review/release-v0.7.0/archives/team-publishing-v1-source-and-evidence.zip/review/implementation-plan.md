# Implementation plan

Confirmed scope is U001-U003 in discovery.json. Independent assertions are frozen in acceptance.json before business implementation. Use serialized SQLite transactions for current authorization, status and version checks. Keep content version separate from state revision. Store an immutable publication snapshot with a unique material ID. Expose no account administration or additional business feature.

Stages: preserve baseline; implement application and neutral observation port; generate source, data and code mappings; run real scenarios in on/off/fault modes; verify browser recording, replay and source views; deliver four separate reports with failures and limits.

