# Business network draft

```mermaid
flowchart LR
  n0["已通过"]
  n1["原提交人修改同一份资料"]
  n2["成员登录"]
  n3["负责人收到系统内消息"]
  n4["待审核"]
  n5["公开页面展示（访问范围待确认）"]
  n6["已驳回"]
  n7["负责人审核"]
  n8["提交标题与文本资料"]
  n0 -->|"展示通过的资料"| n5
  n2 -->|"登录后提交"| n8
  n3 -->|"收到消息后审核"| n7
  n4 -->|"审核资料"| n7
  n6 -->|"由原提交人修改"| n1
  n1 -->|"重新提交审核"| n8
  n7 -->|"通过"| n0
  n7 -->|"驳回"| n6
  n8 -->|"通知负责人"| n3
  n8 -->|"提交"| n4
```

[Open the live graph](http://127.0.0.1:51221/graph?lang=zh-CN)

Still to confirm:

- 公开页面是否无需登录即可查看？

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
