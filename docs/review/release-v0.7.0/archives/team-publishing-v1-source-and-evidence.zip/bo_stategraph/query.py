"""Read authoritative SQLite state for unified queries, without business events."""
import sqlite3
from contextlib import closing
from pathlib import Path

def bo_machine(database,build_id):
    with closing(sqlite3.connect('file:'+Path(database).resolve().as_posix()+'?mode=ro',uri=True)) as connection:
        connection.row_factory=sqlite3.Row
        rows=connection.execute('SELECT m.id, m.state, m.revision, m.content_version, m.author_id, (SELECT COUNT(*) FROM publications p WHERE p.material_id=m.id) AS publication_count FROM materials m ORDER BY m.id').fetchall()
    return {'configurations':[{'attempt':str(row['id']),'run_id':'database','phase':row['state'],'state_revision':row['revision'],'revision':row['revision'],'run_build_id':build_id,'context':{'content_version':row['content_version'],'author_id':row['author_id'],'publication_count':row['publication_count']}} for row in rows],'journal':[]}

