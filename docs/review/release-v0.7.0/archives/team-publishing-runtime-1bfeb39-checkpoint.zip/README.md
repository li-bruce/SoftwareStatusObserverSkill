# Team publishing Demo — 1bfeb39 runtime checkpoint

**Not the final release.** The public runtime combines expired live history with dropped events. Raw health, screenshots and the retention harness failure are preserved. A separately authorized upstream fix and limited boundary retest are pending.

Business v2 is unchanged. Checkpoint public runtime: `1bfeb39853a88ac5b9d02b675a010486b0832574`. Four native gates, accept/check and actual browser reload/replay regression passed.

Start with [QUICKSTART](QUICKSTART.md). Run `python run.py` from this directory to launch both services. The launcher prints their actual URLs. In this running session: [application](http://127.0.0.1:51235), [graph](http://127.0.0.1:51236/graph?lang=zh-CN).

Read [v1-to-v2 changes](review/v1-v2-diff.md), [original v2 evidence](evidence/TRIAL_INDEX.md), [runtime evidence](evidence/RUNTIME_TRIAL_INDEX.md) and [checkpoint identity](evidence/runtime-1bfeb39-checkpoint.json). Original v1/v2, 9134c61 and e8e922e archives remain frozen. The e8e922e saved-view failure is preserved independently.

Message marking is explicit, recipient-only and idempotent. Listing does not mark messages read. Existing messages migrate to unread once; later startup preserves their state. Replay disables live-only code structure, then restores code on return to live. Saved analysis, positions, camera, notes and cleared discussion survive full-page reload.

The final focused recording has 307 events and no material transitions. Full publication regression remains separately recorded and checked. Live history is bounded to 30 minutes/10000 events; stopped recordings persist independently. This is a local scripted demonstration, not exhaustive proof or a human usability study.
