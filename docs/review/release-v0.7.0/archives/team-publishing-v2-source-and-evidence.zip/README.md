# Team publishing Demo — accepted v2

Original v2 passed all four native gates with 108/108 business assertions and a no-gap 922-event real browser recording. See [trial index](evidence/TRIAL_INDEX.md), [v1 to v2 changes](review/v1-v2-diff.md) and [release receipt](evidence/v2-release.json).

Run `python run.py`; it prints both local URLs. Use `python tooling/verify.py check` to verify the accepted inputs, or `verify` to rerun all gates. See [QUICKSTART](QUICKSTART.md).

V2 adds recipient-only explicit per-message read marking and own unread counts. Opening the message list does not mark messages read; repeated marking is idempotent. Startup migrates existing messages to unread once and preserves later read values.
