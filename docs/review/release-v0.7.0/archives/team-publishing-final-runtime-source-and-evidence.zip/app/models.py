"""Native SQLAlchemy declarations; importing this module performs no I/O."""
from sqlalchemy import MetaData, Table, Column, Integer, String, Text, ForeignKey, CheckConstraint

metadata = MetaData()
accounts = Table('accounts', metadata,
    Column('id', Integer, primary_key=True), Column('username', String(40), unique=True, nullable=False),
    Column('password_hash', String(200), nullable=False), Column('role', String(20), nullable=False),
    Column('active', Integer, nullable=False, server_default='1'),
    CheckConstraint("role IN ('member', 'reviewer')"), CheckConstraint('active IN (0,1)'))
sessions = Table('sessions', metadata,
    Column('token_hash', String(64), primary_key=True), Column('account_id', ForeignKey('accounts.id'), nullable=False))
materials = Table('materials', metadata,
    Column('id', Integer, primary_key=True), Column('author_id', ForeignKey('accounts.id'), nullable=False),
    Column('title', String(160), nullable=False), Column('body', Text, nullable=False),
    Column('state', String(20), nullable=False), Column('content_version', Integer, nullable=False),
    Column('revision', Integer, nullable=False),
    CheckConstraint("state IN ('pending','rejected','approved')"),
    CheckConstraint('content_version >= 1'), CheckConstraint('revision >= 1'))
publications = Table('publications', metadata,
    Column('material_id', ForeignKey('materials.id'), primary_key=True),
    Column('content_version', Integer, nullable=False), Column('title', String(160), nullable=False),
    Column('body', Text, nullable=False), Column('author_id', ForeignKey('accounts.id'), nullable=False))
messages = Table('messages', metadata,
    Column('id', Integer, primary_key=True), Column('recipient_id', ForeignKey('accounts.id'), nullable=False),
    Column('material_id', ForeignKey('materials.id'), nullable=False),
    Column('content_version', Integer, nullable=False), Column('text', String(240), nullable=False),
    Column('is_read', Integer, nullable=False, server_default='0'),
    CheckConstraint('is_read IN (0,1)'))
