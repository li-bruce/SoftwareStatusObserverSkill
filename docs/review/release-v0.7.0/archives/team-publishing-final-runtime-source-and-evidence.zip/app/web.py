"""HTTP delivery for the local application; developer observation routes are separate."""
import json
import os
from pathlib import Path
from fastapi import FastAPI, Request, Response
from fastapi.responses import FileResponse, JSONResponse
from pydantic import BaseModel, Field, ConfigDict
from .service import Service, DomainError

ROOT=Path(__file__).resolve().parents[1]

class Credentials(BaseModel):
    model_config=ConfigDict(extra='forbid')
    username: str=Field(max_length=40)
    password: str=Field(max_length=200)

class Content(BaseModel):
    model_config=ConfigDict(extra='forbid')
    title: str=Field(min_length=1,max_length=160)
    body: str=Field(min_length=1,max_length=20000)

class Version(BaseModel):
    model_config=ConfigDict(extra='forbid')
    content_version: int=Field(ge=1)
    revision: int=Field(ge=1)

class Edit(Content,Version):
    pass

class Decision(Version):
    decision: str

def create_app(service=None):
    app=FastAPI(docs_url=None,redoc_url=None,openapi_url=None)
    app.state.service=service or Service(os.environ.get('TEAM_DATABASE',str(ROOT/'data/team.sqlite')))
    if service is None:
        app.state.service.initialize()
        try:
            from integrations.bo_adapter import BOAdapter
            app.state.service.bo=BOAdapter.from_settings(ROOT)
        except Exception:
            pass
    svc=app.state.service

    @app.middleware('http')
    async def local_origin(request,call_next):
        host=request.headers.get('host','')
        origin=request.headers.get('origin')
        if host.split(':')[0] not in ('127.0.0.1','localhost','testserver'):
            return JSONResponse({'code':'local_host_required'},403)
        if request.method not in ('GET','HEAD') and origin and origin != 'http://'+host:
            return JSONResponse({'code':'same_origin_required'},403)
        response=await call_next(request)
        response.headers['Cache-Control']='no-store'
        response.headers['X-Content-Type-Options']='nosniff'
        return response

    @app.exception_handler(DomainError)
    async def domain_error(request,error):
        return JSONResponse({'code':error.code},error.status)

    @app.get('/')
    def index():
        svc.bo.record('page_shell','return',{}, {'asset':'index.html'})
        return FileResponse(ROOT/'static/index.html')

    @app.get('/app.js')
    def javascript():
        svc.bo.record('page_shell','return',{}, {'asset':'app.js'})
        return FileResponse(ROOT/'static/app.js',media_type='text/javascript')

    @app.get('/app.css')
    def stylesheet():
        svc.bo.record('page_shell','return',{}, {'asset':'app.css'})
        return FileResponse(ROOT/'static/app.css',media_type='text/css')

    @app.get('/api/bo/client.js')
    def observer_client():
        return FileResponse(ROOT/'integrations/bo_client.js',media_type='text/javascript')

    @app.get('/api/bo/runtime.mjs')
    def observer_runtime():
        return FileResponse(ROOT/'observer_runtime/bo_observer/adapters/javascript/bo_runtime.mjs',media_type='text/javascript')

    @app.get('/api/bo/settings')
    def observer_settings():
        settings=getattr(svc.bo,'settings',None)
        if settings is None or os.environ.get('TEAM_OBSERVATION')=='off': return {'enabled':False}
        return {'enabled':True,'project':svc.bo.project,'buildId':svc.bo.build_id,
                'endpoint':('http://127.0.0.1:1' if os.environ.get('TEAM_OBSERVATION')=='fault' else settings['endpoint']),'token':settings['token']}

    @app.get('/api/bo/app-health')
    def health():
        return {'status':'ok','project_id':'team-publishing-demo','build_id':getattr(svc.bo,'build_id','observer-unavailable')}

    @app.post('/api/login')
    def login(payload:Credentials,response:Response):
        token,actor=svc.login(payload.username,payload.password)
        response.set_cookie('team_session',token,httponly=True,samesite='strict',path='/')
        return actor

    @app.post('/api/logout')
    def logout(request:Request,response:Response):
        result=svc.logout(request.cookies.get('team_session'))
        response.delete_cookie('team_session',path='/')
        return result

    @app.get('/api/me')
    def current_user(request:Request):
        return svc.current(request.cookies.get('team_session'))

    @app.get('/api/materials')
    def list_materials(request:Request):
        return svc.listing(request.cookies.get('team_session'))

    @app.post('/api/materials')
    def submit_material(payload:Content,request:Request):
        return svc.submit(request.cookies.get('team_session'),payload.title,payload.body)

    @app.put('/api/materials/{material_id}')
    def edit_material(material_id:int,payload:Edit,request:Request):
        return svc.edit(request.cookies.get('team_session'),material_id,payload.title,payload.body,payload.content_version,payload.revision)

    @app.post('/api/materials/{material_id}/resubmit')
    def resubmit_material(material_id:int,payload:Version,request:Request):
        return svc.resubmit(request.cookies.get('team_session'),material_id,payload.content_version,payload.revision)

    @app.post('/api/materials/{material_id}/review')
    def review_material(material_id:int,payload:Decision,request:Request):
        return svc.review(request.cookies.get('team_session'),material_id,payload.decision,payload.content_version,payload.revision)

    @app.get('/api/messages')
    def list_messages(request:Request):
        return svc.inbox(request.cookies.get('team_session'))

    @app.get('/api/messages/{message_id}')
    def get_message(message_id:int,request:Request):
        return svc.message(request.cookies.get('team_session'),message_id)

    @app.get('/api/message-summary')
    def message_summary(request:Request):
        return svc.unread_count(request.cookies.get('team_session'))

    @app.post('/api/messages/{message_id}/read')
    def mark_message_read(message_id:int,request:Request):
        return svc.mark_message_read(request.cookies.get('team_session'),message_id)

    @app.get('/api/public')
    def public_materials():
        return svc.public()

    return app

