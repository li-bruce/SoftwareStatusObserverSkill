"""Small idempotent application-owned SQLite migration for existing message rows."""

def apply_message_column(connection, statement):
    connection.exec_driver_sql(statement)
    return True

def migrate_messages(engine, observer):
    observer.record('migrate_messages','enter',{}, {})
    with observer.transaction(engine) as connection:
        columns=[row[1] for row in connection.exec_driver_sql('PRAGMA table_info(messages)').all()]
        existing_count=connection.exec_driver_sql('SELECT COUNT(*) FROM messages').scalar_one()
        changed='is_read' not in columns
        if changed:
            statement="ALTER TABLE messages ADD COLUMN is_read INTEGER NOT NULL DEFAULT '0' CHECK (is_read IN (0,1))"
            observer.data('db.messages.migrate',lambda: apply_message_column(connection,statement),connection=connection,
                statement='add_message_is_read',language='command',targets=['table:messages'],parameters={},
                summarize=lambda added:{'rows':0,'result':{'added':added}})
    result={'schema_changed':changed,'existing_count':existing_count,'initialized_unread':existing_count if changed else 0}
    observer.record('migrate_messages','commit',{},result)
    return result
