# Team publishing Demo

This is the scope confirmed in U003. It is an isolated local demonstration, not a deployment service. The UI is Chinese; maintained source and documentation are English.

## Run

From this project directory, using Python 3.13 and Node.js:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
npm ci --prefix observer_runtime/bo_observer/adapters/javascript
.\.venv\Scripts\python.exe -B -X utf8 run.py
```

The launcher prints the actual application and graph URLs and saves them in `.stategraph/runtime.json`. It binds both services to `127.0.0.1`. Stop with Ctrl+C. It owns only the processes it starts. The default SQLite database is `data/team.sqlite`; select a different file with `--database PATH`. Choose explicit ports with `--app-port` and `--graph-port`.

On this machine, Windows blocked the SQLAlchemy compiled extension. The verified installation used its supported pure-Python build:

```powershell
$env:DISABLE_SQLALCHEMY_CEXT='1'
.\.venv\Scripts\python.exe -m pip install --force-reinstall --no-binary SQLAlchemy SQLAlchemy==2.1.6
```

The prepared environment for this session is `../../work/.venv/Scripts/python.exe` relative to this directory.

## Walk through the application

1. Open the application, select **工作台**, and log in as `member` / `member-demo`.
2. Submit a title and text. The same material enters **待审核**.
3. Log out, then log in as `reviewer` / `reviewer-demo`. Read **系统消息** and choose **驳回**.
4. Return to the member account, choose **修改**, save, and choose **重新提交审核**.
5. Return to the reviewer and choose **通过并发布**.
6. Log out and open **公开资料**. It shows the exact reviewed content version.

These are the only two normal accounts. Tests temporarily vary roles in separate databases to verify current permission checks and non-author rejection. Those fixtures do not add production features. Approved material is read-only. Reviewers cannot edit. Messages are visible only to their recipient. Review and publication occur in a serialized SQLite transaction; stale versions and repeated decisions fail without another publication.

## Record and inspect

Open the graph before the walkthrough. Select **开始记录**, perform real application operations, then select **结束记录**. Use **选择记录**, **播放**, **暂停**, **记录中的步骤**, and **返回实时**. Material commits have actual snapshots; arbitrary read/query events do not imply state changes. Across producers, event arrival order is display order, not a claim of causal order.

Select a node and open **源码** or **参数值**. If pointer selection is ambiguous in the browser accessibility overlay, focus the named node and press Enter. **局部代码** shows the selected region. **分析视图 → 代码结构** shows the indexed source scope; **加载更多代码节点** increases the visible budget. The full source index retains unresolved external/dynamic references as unknown. Static call edges do not establish actual execution.

Graph controls, source reads and layout operations are observational only. Personal layout is in `bo_stategraph/config/views/local.json`. Recordings contain source snapshots and selected operational metadata; keep the local project private. Passwords, session tokens and text bodies are excluded from probe fields.

## Verify

```powershell
$env:TEAM_DATABASE_URL='sqlite:///'+((Resolve-Path data/team.sqlite).Path.Replace('\','/'))
.\.venv\Scripts\python.exe -B -X utf8 tooling/test_business.py
.\.venv\Scripts\python.exe -B -X utf8 tooling/check_project.py
.\.venv\Scripts\python.exe -B -X utf8 tooling/observe.py
.\.venv\Scripts\python.exe -B -X utf8 observer_runtime/change_sync.py check --root (Get-Location).Path
```

`tooling/observe.py` executes independent cases with observation on, off and failing, then incorporates the saved browser evidence only when its build matches. A source change correctly makes old browser evidence stale. Replay history remains preserved on disk, while the viewer lists only current-version recordings.

Use `run.py --no-observer` for application-only operation, or `--probe-mode off` / `--probe-mode fault` to exercise isolation. The observer never decides business outcomes. The independent state module remains queryable when the debug Web is disabled.

See `review/` for four separate acceptance reports and `evidence/` for actual dialogue, failures, fixes, screenshots and recordings. Original expectations and the active change baseline must not be replaced to obtain a pass.

## Final runtime and portable evidence

The final runtime is `fa372897d69f0b6096392020ed3012284a011b4e`. Live history defaults to 10000 events and 1800 seconds. Normal expiry is reported separately from missing producer events; stopped recordings preserve their complete interval. The focused count/time and missing-event tests are documented in `review/05-retention-recording-boundaries-final.md`.

The source package excludes installed dependencies and the live application database. Install dependencies above; the launcher initializes the demonstration database. A different checkout/database location can refresh the generated SQLite catalog identity and therefore the build identity, as observed in the isolated test. Frozen receipts and historical recordings remain evidence of their recorded builds. To accept a changed build, run the normal synchronization/verification workflow and obtain matching actual browser evidence; do not relabel an older recording or reset its acceptance baseline.
