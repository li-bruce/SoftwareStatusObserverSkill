# Team publishing Demo — final acceptance

Final public runtime: `fa372897d69f0b6096392020ed3012284a011b4e`. Business v2 is unchanged. All four native gates, accept/check and the focused real-browser retention/replay tests passed.

Start with [QUICKSTART](QUICKSTART.md). Run `python run.py` to start both services; the launcher prints actual local URLs. This delivered session is available at [application](http://127.0.0.1:51235) and [graph](http://127.0.0.1:51236/graph?lang=zh-CN).

Read [v1-to-v2 changes](review/v1-v2-diff.md), [original business evidence](evidence/TRIAL_INDEX.md), [runtime evidence](evidence/RUNTIME_TRIAL_INDEX.md), [retention report](review/05-retention-recording-boundaries-final.md), and [final release identity](evidence/runtime-final-release.json). Earlier v1/v2/9134c61/e8e922e/1bfeb39 ZIPs remain immutable.

Read marking is explicit, recipient-only and idempotent. Listing does not mark messages read. Existing messages migrate once to unread; subsequent starts preserve read state. The unchanged material submission/rejection/edit/resubmission/review/publication workflow remains covered by the original assertions and executed cases.

The viewer preserves saved analysis, positions, camera, notes and cleared discussion. Live history remains bounded to 10000 events/1800 seconds. Normal expiry is displayed separately from missing producer events; recordings retain their complete interval across live-history expiry. A deliberately skipped event still reports a gap. Temporary test settings were confined to isolated copies and restored afterward.

Fresh final retention proof comprises 12 real read-only browser events in an isolated clone, compared with an independent event log. Earlier full publication and message recordings retain their own stage labels. Live session databases/collector credentials and installed dependencies are excluded from the shareable package; the actual historical migration fixture is retained.
