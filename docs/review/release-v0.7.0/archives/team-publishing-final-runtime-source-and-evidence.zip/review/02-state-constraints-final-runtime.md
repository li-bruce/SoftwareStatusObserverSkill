# State Constraints

Status: **passed**. Final runtime: `fa372897d69f0b6096392020ed3012284a011b4e`. Application build: `5fb8a3e5aa68a759c49bdd3ef2c719b64a575392f5504fa2d152d3370faac737`.

The material state machine, stable IDs and independent state expectations are unchanged. The existing state/projection checks passed. The final isolated real recording contains read-only public queries, not material transitions. Historical full workflows retain their actual five material commit frames and original stage labels.

See the adjacent JSON for the exact native category. Native [verify](runtime-fa37289-verification.json), [accept](runtime-fa37289-accepted.json) and [check](runtime-fa37289-check.json) are retained. [Focused retention report](05-retention-recording-boundaries-final.md), [runtime evidence](../evidence/RUNTIME_TRIAL_INDEX.md) and [final identity](../evidence/runtime-final-release.json) separate freshly executed evidence from historical same-build browser witnesses.
