# Retention and recording boundaries

Status: **passed**. Final public runtime: `fa372897d69f0b6096392020ed3012284a011b4e`.

| Boundary | Actual evidence | Result |
| --- | --- | --- |
| Live count limit | Isolated Demo, 2-event/3-second limits, actual browser public-page refresh | 2 live events retained after count limit; dropped=0 |
| Live time limit during recording | Same session after real elapsed time | Live events became 0; 74 total earlier events expired; dropped=0 |
| Complete interval | Two real public-page refreshes | Recording retained exactly sequences 63-74: 12 events, gaps=[], identical IDs/order to independent events.jsonl interval |
| Query truth | Each query returned count=6 | Independent isolated SQLite publications count=6 |
| Real producer gap | Separate isolated synthetic producer sends 1 then 3 | Missing 2 remained dropped=1 after both received events expired; recording reports a gap |
| User wording | Actual Chinese/English viewer | History expiry is named explicitly, not called missing events |
| Replay/source | Replay the expired interval and inspect returned count/source | Saved events remain inspectable |
| Observation exclusion | Main Demo graph/data/source/replay/reload; isolated replay/language/view controls | Main written 0->0; isolated written stayed 74 |
| Settings and isolation | Stop test services, restore fixture defaults | Delivery stayed at 10000 events/1800 seconds; no synthetic event entered its collector |

The positive recording uses clone build `5ae7f25287227f43e99226fb345d82831d2524e262a6211342b3424338a1866e`. Its generated SQLite catalog identity differs from the delivery build; all 28 protected source/expectation files match. It is explicitly an isolated-clone recording. The main Demo separately replayed the preserved 1bfeb39 recording without relabeling it as newly executed.

See [count/time snapshots](../evidence/checks/runtime-fa37289-count-time-boundaries.json), [positive proof](../evidence/checks/runtime-fa37289-retention-positive.json), [negative proof](../evidence/checks/runtime-fa37289-retention-negative.json), [full recording](../evidence/recordings/browser-fa37289-retention-complete.json), [restored settings](../evidence/checks/runtime-fa37289-retention-restored.json), and screenshots 086-093. Actual execution scripts and fixture notes are in [reproducers](../evidence/reproducers/runtime-fa37289/README.md).

The first post-restart preference save omitted inactive `codeFocus:null`, consistent with the existing string-only loader; every meaningful view value remained equal. The subsequent actual full-page reload was strictly byte-equal for every saved entry at revision 101. [Raw comparison](../evidence/checks/runtime-fa37289-preference-serialization.json) is preserved. Initial clone copy/parser failures were repaired before any test pass was counted; neither public code nor business expectations were patched.
