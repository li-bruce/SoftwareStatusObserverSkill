# Project Checks

Native gate status: **passed**. Release status: **checkpoint, final withheld for the public retention/recording issue**. Runtime: `1bfeb39853a88ac5b9d02b675a010486b0832574`. Application build: `5fb8a3e5aa68a759c49bdd3ef2c719b64a575392f5504fa2d152d3370faac737`.

All 12 project checks passed, including queue bounds, schema/source drift, omission/incorrect-value controls and observer-independent execution. Eight isolated code-index/ownership checks passed. Three actual saved-view reload pairs preserve every preference entry. Native replay disabling, live restoration, source/data views and old-build recording filtering passed.

The adjacent JSON contains the native report. See [verify](runtime-1bfeb39-verification.json), [accept](runtime-1bfeb39-accepted.json), [current-input check](runtime-1bfeb39-check.json), [runtime evidence](../evidence/RUNTIME_TRIAL_INDEX.md) and [checkpoint identity](../evidence/runtime-1bfeb39-checkpoint.json).

The native gate uses the accepted original v2 browser witness for identical source/build. The new 307-event runtime recording is additional evidence. Coverage is bounded to declared cases; missing or unrun evidence is not a pass.
