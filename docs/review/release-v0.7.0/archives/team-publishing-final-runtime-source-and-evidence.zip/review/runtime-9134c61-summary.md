# Public runtime 9134c61 regression

All four native gates passed. Business source and independent expectations remain byte-for-byte unchanged. 108 authored assertions, 37 standalone assertions and eight isolated code-index/source-scope checks passed.

A fresh actual browser workflow contains 919 events, five material commit frames, first/repeat message marks and no recording gaps. During recording, the full code view was loaded to 674 nodes and 946 edges while business operations continued.

The application build ID is unchanged because the upgraded files are observer internals and viewer assets, outside the application build hash. The adjacent runtime manifest and this commit identify the upgrade. Same-build recording retention is expected; earlier application-build records remain filtered. The native gate reused the valid original v2 browser witness for this identical application build; the new 919-event runtime recording is additional executed evidence, not a rewritten original receipt.

**Not the final UI release:** actual replay from Code structure retains an empty live-source-only view. Screenshot 054 preserves this result. The user separately authorized the canonical UI fix and a later final SHA.
