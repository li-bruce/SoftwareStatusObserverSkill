# Business network draft

```mermaid
flowchart LR
  n0["收件人逐条点击“标记为已读”"]
  n1["已读"]
  n2["未读（新消息及升级前已有消息）"]
  n3["负责人收到系统内消息"]
  n4["查看自己的消息列表（不自动已读）"]
  n5["列表显示自己的未读数量"]
  n2 -->|"统计自己的未读消息"| n5
  n1 -->|"读取，不再改变状态"| n4
  n2 -->|"读取当前接收人的消息"| n4
  n0 -->|"首次减少 1；重复不再减少"| n5
  n4 -->|"只操作自己收到的这一条"| n0
  n1 -->|"重复点击：保持已读"| n0
  n0 -->|"未读 → 已读"| n1
  n3 -->|"新消息初始未读"| n2
  b0["负责人审核 (outside scope)"]
  n3 -.->|"收到消息后审核"| b0
  b1["提交标题与文本资料 (outside scope)"]
  b1 -.->|"通知负责人"| n3
```

[Open the live graph](http://127.0.0.1:51234/graph?lang=zh-CN)

This is a focused view. Dashed boundaries retain original relations; open Web for the complete graph.

Still to confirm:

- 这张消息已读与未读数量的增量图是否准确，可以据此开始实现？

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
