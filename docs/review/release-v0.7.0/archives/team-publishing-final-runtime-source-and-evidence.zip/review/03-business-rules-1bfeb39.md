# Business Rules

Native gate status: **passed**. Release status: **checkpoint, final withheld for the public retention/recording issue**. Runtime: `1bfeb39853a88ac5b9d02b675a010486b0832574`. Application build: `5fb8a3e5aa68a759c49bdd3ef2c719b64a575392f5504fa2d152d3370faac737`.

All 108 authored assertions across observation on/off/failing passed. The unchanged standalone suite (37 assertions including concurrency) and existing whitebox checks passed. No business rule or expectation changed. The final actual message operation changed unread 8 to 7; repeat kept 7; independent SQLite reads agree.

The adjacent JSON contains the native report. See [verify](runtime-1bfeb39-verification.json), [accept](runtime-1bfeb39-accepted.json), [current-input check](runtime-1bfeb39-check.json), [runtime evidence](../evidence/RUNTIME_TRIAL_INDEX.md) and [checkpoint identity](../evidence/runtime-1bfeb39-checkpoint.json).

The native gate uses the accepted original v2 browser witness for identical source/build. The new 307-event runtime recording is additional evidence. Coverage is bounded to declared cases; missing or unrun evidence is not a pass.
