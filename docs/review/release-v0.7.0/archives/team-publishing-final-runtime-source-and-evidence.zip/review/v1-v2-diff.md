# v1 to v2 review

The same project identity, original business node IDs and material state machine are retained. The v1 directory and frozen archive remain unchanged.

Confirmed additions: explicitly mark one own message as read, display own unread count, preserve idempotence, keep listing read-only, initialize existing messages as unread, and create new messages unread. No mark-all or restore-unread operation was added.

The message state is `messages.is_read`, constrained by SQLite to 0 or 1. It is separate from material pending/rejected/approved state. The marking transaction rechecks the active session and recipient, then conditionally writes once. Current implementation computes counts from persisted message rows rather than maintaining a second counter.

## Inspectable changes

- [Source and declaration patch](v1-v2-source.patch)
- [Graph nodes and edges](v1-v2-graph-diff.json)
- [Independent acceptance expectations](v1-v2-acceptance-diff.json)
- [Actual database schema before and after](v1-v2-schema-diff.json)
- [Original migration receipt](../evidence/migrations/v2-applied.json)

The four core business nodes added to discovery are `message_unread`, `mark_message_read`, `message_read`, and `unread_count`. Migration, UI, route, database field and source nodes expand these regions without renaming existing identities. Selected message values are captured on actual native return/commit events. Message events do not invent material snapshot changes.

The installed public runtime is held at the supplied 920c015 version. DDL uses the existing explicit command-target API; DML still uses parsed SQL targets. `ALTER TABLE` access-direction inference is outside this runtime's parser capability, and the migration's actual effect is independently checked in SQLite.

Changed source/declaration paths:

- `acceptance.json`
- `app/migrations.py`
- `app/models.py`
- `app/service.py`
- `app/web.py`
- `bo_stategraph/database-catalog.json`
- `bo_stategraph/databases.json`
- `bo_stategraph/project.json`
- `discovery.json`
- `implementation.json`
- `intent.json`
- `mapping.json`
- `static/app.js`
- `static/index.html`
- `sync.json`
- `tooling/build_model.py`
- `tooling/check_project.py`
- `tooling/message_scenarios.py`
- `tooling/migrate.py`
- `tooling/observe.py`
- `tooling/test_business.py`
- `tooling/verify.py`
- `whitebox.json`
