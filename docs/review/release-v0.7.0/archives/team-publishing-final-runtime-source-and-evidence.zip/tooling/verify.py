"""Run the native gate on the existing change; never replace its baseline."""
import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['inspect','verify','check'],default='check',nargs='?')
    args=parser.parse_args()
    os.environ.setdefault('TEAM_DATABASE_URL','sqlite:///'+(ROOT/'data/team.sqlite').as_posix())
    command=[sys.executable,'-B','-X','utf8',str(ROOT/'observer_runtime/change_sync.py'),args.command,'--root',str(ROOT)]
    return subprocess.run(command,cwd=ROOT).returncode

if __name__=='__main__':raise SystemExit(main())
