"""Execute actual scenarios and compare public graph projections to independent SQLite reads."""
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/"observer_runtime"))
from observer_runtime.behavior_model import capture
from observer_runtime.mapping_contract import instance_witnesses
from bo_stategraph import BOStateGraph
from tooling.scenarios import CASES,execute
from tooling.message_scenarios import CASES as MESSAGE_CASES,execute as execute_message

def main():
    project=json.loads((ROOT/'bo_stategraph/project.json').read_text(encoding='utf-8'))
    model=project['model'];build_id=capture(ROOT,model)['build_id']
    graph=BOStateGraph(model,build_id=build_id,mode='observe')
    runs=[];witnesses=[]
    for mode in ['on','off','fault']:
        for case in CASES+MESSAGE_CASES:
            run=(execute if case in CASES else execute_message)(case,mode,project,build_id)
            witnesses.extend(run.pop('message_mapping_checks',[]))
            machine=run.pop('machine_snapshot')
            instances=graph.bo_instances(machine)
            run['projection']={'build_id':build_id,'machine':machine,'instances':instances}
            actual={item['id']:{'state':item['state'],'revision':item['revision'],'context':{key:item[key] for key in ['content_version','author_id','publication_count']}} for item in run['authority_snapshot']['materials']}
            witnesses.extend(instance_witnesses(instances,actual,case=case+':'+mode,source='Independent sqlite3 SELECT; see tooling/scenarios.py'))
            runs.append(run)
    browser_path=ROOT/'evidence/browser-runtime.json'
    if browser_path.exists():
        browser=json.loads(browser_path.read_text(encoding='utf-8'))
        if browser['build_id']!=build_id:raise ValueError('Browser evidence is stale; repeat the actual browser flow for the current build.')
        runs.extend(browser['runs'])
    selected=next(run for run in runs if run['case']=='flow' and run['mode']=='on')
    exported=graph.bo_export(runtime={'machine':selected['projection']['machine']})
    print(json.dumps({'build_id':build_id,'machine':model['machine'],'runs':runs,'mapping_checks':witnesses,'stategraph_export':exported},ensure_ascii=False))
if __name__=='__main__':main()

