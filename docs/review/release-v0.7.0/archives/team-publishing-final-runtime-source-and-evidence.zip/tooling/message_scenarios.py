"""Independent v2 message, migration and real concurrent marking scenarios."""
import json,sqlite3,tempfile,shutil
from pathlib import Path
from contextlib import closing
from concurrent.futures import ThreadPoolExecutor
from threading import Barrier
from fastapi.testclient import TestClient
from app.service import Service
from app.web import create_app
from bo_stategraph.query import bo_machine
from tooling.scenarios import independent_snapshot
from tooling.migrate import snapshot

ROOT=Path(__file__).resolve().parents[1]
CASES=['message_read','message_repeat','message_permissions','message_concurrency','migration']

def stored(database):
    with closing(sqlite3.connect(database)) as connection:
        return {'messages':[{'id':row[0],'recipient_id':row[1],'is_read':bool(row[2])} for row in connection.execute('SELECT id,recipient_id,is_read FROM messages ORDER BY id')],
                'unread':connection.execute('SELECT COUNT(*) FROM messages WHERE recipient_id=2 AND is_read=0').fetchone()[0]}

def execute(case,mode='off',project=None,build_id='not-observed'):
    parent=ROOT/'.stategraph/scenario-data';parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(dir=parent) as folder:
        database=Path(folder)/'team.sqlite'
        if case=='migration':shutil.copy2(ROOT/'evidence/migrations/v1-before.sqlite',database)
        service=Service(database);events=[];snapshots=[];witnesses=[];clients=[]
        def attach():
            if not project:return
            from integrations.bo_adapter import BOAdapter
            from observer_runtime.bo_observer.protocol import validate_event,validate_snapshot
            def sink(body,kind):
                if mode=='fault':raise OSError('Injected unavailable observer transport')
                if kind=='events':validate_event(body,project,build_id);events.append(body)
                else:validate_snapshot(body,project,build_id);snapshots.append(body)
            service.bo=BOAdapter(project,build_id,sink=sink,enabled=mode!='off')
        try:
            observations={}
            if case=='migration':
                before=snapshot(database);attach();migration=service.initialize();after=snapshot(database)
                observations.update(all_unread=all(not value for _,value in after['read_values']),old_facts_unchanged=before['legacy_facts_sha256']==after['legacy_facts_sha256'],migrated_count=migration['initialized_unread'])
                token,_=service.login('reviewer','reviewer-demo');service.mark_message_read(token,after['read_values'][0][0])
                again=service.initialize()
                observations.update(second_migration=again['schema_changed'],read_survives_restart=stored(database)['messages'][0]['is_read'])
            else:
                service.initialize();attach();app=create_app(service)
                member,reviewer,anonymous=[TestClient(app,raise_server_exceptions=False) for _ in range(3)];clients=[member,reviewer,anonymous]
                assert member.post('/api/login',json={'username':'member','password':'member-demo'}).status_code==200
                assert reviewer.post('/api/login',json={'username':'reviewer','password':'reviewer-demo'}).status_code==200
                for title in ['One','Two']:assert member.post('/api/materials',json={'title':title,'body':'Message fixture'}).status_code==200
                message_id=stored(database)['messages'][0]['id']
                def mark():
                    before=stored(database)
                    response=reviewer.post('/api/messages/'+str(message_id)+'/read',json={});assert response.status_code==200,response.text
                    after=stored(database);previous=next(r for r in before['messages'] if r['id']==message_id);current=next(r for r in after['messages'] if r['id']==message_id)
                    witnesses.append({'message_id':message_id,'recipient_id':current['recipient_id'],'was_read':previous['is_read'],'is_read':current['is_read'],'changed':before['unread']!=after['unread'],'unread_before':before['unread'],'unread_count':after['unread']})
                    return before,after
                if case=='message_read':
                    before=stored(database);observations['initial_count']=before['unread']
                    reviewer.get('/api/messages');reviewer.get('/api/messages');reviewer.get('/api/messages/'+str(message_id))
                    observations['list_preserves']=before==stored(database)
                    assert reviewer.get('/api/message-summary').json()['unread_count']==2
                    observations['member_count']=member.get('/api/message-summary').json()['unread_count']
                    before,after=mark();observations.update(first_delta=before['unread']-after['unread'],stored_is_read=int(after['messages'][0]['is_read']))
                elif case=='message_repeat':
                    mark();before,after=mark();observations.update(repeat_delta=before['unread']-after['unread'],final_count=after['unread'])
                elif case=='message_permissions':
                    url='/api/messages/'+str(message_id)+'/read'
                    observations['wrong_recipient']=member.post(url,json={}).status_code
                    observations['anonymous']=anonymous.post(url,json={}).status_code
                    with closing(sqlite3.connect(database)) as connection,connection:connection.execute('UPDATE accounts SET active=0 WHERE id=2')
                    observations['revoked']=reviewer.post(url,json={}).status_code
                    observations['read_count']=sum(row['is_read'] for row in stored(database)['messages'])
                elif case=='message_concurrency':
                    barrier=Barrier(2);token=reviewer.cookies.get('team_session')
                    def worker():barrier.wait();return service.mark_message_read(token,message_id)
                    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(lambda _:worker(),range(2)))
                    observations.update(changes=sum(r['changed'] for r in results),final_count=stored(database)['unread'])
            service.bo.flush()
            if mode=='on' and project and witnesses:
                captures=[e['outputs'] for e in events if e['node']=='mark_message_read' and e['phase']=='commit']
                assert len(captures)==len(witnesses)
                mapping=[{'id':case+':message:'+str(i),'source':'Independent sqlite3 reads immediately before and after each HTTP operation','projection':'Native mark_message_read commit event selected values','actual':expected,'mapped':actual} for i,(expected,actual) in enumerate(zip(witnesses,captures))]
            else:mapping=[]
            diagnostics={} if not project else {'transport_errors':service.bo.probe.bo_errors,'dropped':service.bo.probe.bo_dropped,'data_errors':service.bo.data_runtime.bo_errors}
            return {'case':case,'mode':mode,'events':events,'observations':observations,'authority_snapshot':independent_snapshot(database,build_id),'machine_snapshot':bo_machine(database,build_id),'message_mapping_checks':mapping,'native_snapshots':snapshots,'diagnostics':diagnostics}
        finally:
            service.close()
            for client in clients:client.close()
