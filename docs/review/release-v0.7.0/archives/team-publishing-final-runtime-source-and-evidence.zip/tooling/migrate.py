"""Apply the real application migration and retain independent before/after evidence."""
import json,sys,sqlite3,hashlib
from pathlib import Path
from contextlib import closing
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from app.service import Service

def snapshot(database):
    with closing(sqlite3.connect(database)) as connection:
        columns=[row[1] for row in connection.execute('PRAGMA table_info(messages)')]
        old={table:connection.execute('SELECT * FROM '+table+' ORDER BY 1').fetchall() for table in ['accounts','sessions','materials','publications']}
        old['messages']=connection.execute('SELECT id,recipient_id,material_id,content_version,text FROM messages ORDER BY id').fetchall()
        return {'columns':columns,'legacy_facts_sha256':hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest(),'message_count':len(old['messages']),'read_values':connection.execute('SELECT id,is_read FROM messages ORDER BY id').fetchall() if 'is_read' in columns else None}

def main():
    database=ROOT/'data/team.sqlite';target=ROOT/'evidence/migrations/v2-applied.json'
    if target.exists():raise SystemExit('Migration receipt already exists; never overwrite the original migration evidence.')
    before=snapshot(database);service=Service(database)
    try:
        receipt=service.initialize();after=snapshot(database)
        repeat=service.initialize();again=snapshot(database)
    finally:service.close()
    assert receipt['schema_changed'] and before['legacy_facts_sha256']==after['legacy_facts_sha256']
    assert all(value==0 for _,value in after['read_values'])
    assert not repeat['schema_changed'] and after==again
    target.write_text(json.dumps({'passed':True,'before':before,'migration':receipt,'after':after,'repeat':repeat},ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'passed':True,'existing_messages_migrated':after['message_count'],'old_facts_preserved':True}))
if __name__=='__main__':main()
