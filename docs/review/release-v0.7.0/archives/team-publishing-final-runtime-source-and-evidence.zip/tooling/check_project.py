import json,sys,os,time,shutil,sqlite3,hashlib,tempfile
from pathlib import Path
from contextlib import closing
ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT/'.stategraph/test-work';WORK.mkdir(parents=True,exist_ok=True)
sys.path[:0]=[str(ROOT),str(ROOT/'observer_runtime')]
from observer_runtime.behavior_model import capture,check
from observer_runtime.bo_observer.data.sync import synchronize
from observer_runtime.bo_observer.delivery.architecture_guard import inspect
from tooling.scenarios import execute
from tooling.message_scenarios import execute as execute_message
from integrations.bo_adapter import BOAdapter
from app.service import Service
import app.service as domain
from bo_stategraph import BOStateGraph,bo_validate_export
read=lambda name:json.loads((ROOT/name).read_text(encoding='utf-8-sig'))
project=read('bo_stategraph/project.json');model=project['model'];build=capture(ROOT,model)['build_id']
results=[]
def result(name,passed,**evidence):
    results.append({'check':name,'passed':passed,**evidence});print(name,passed,flush=True)
    (ROOT/'evidence/checks/project-extra.json').write_text(json.dumps({'build_id':build,'checks':results,'complete':False},ensure_ascii=False,indent=2),encoding='utf-8')
version=read('bo_stategraph/runtime-version.json')
bad=[p for p,h in version['files'].items() if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
result('managed_runtime_hash_parity',not bad,checked=len(version['files']),mismatches=bad)
cfg={'scan':['app','integrations','static/app.js','bo_stategraph/query.py'], 'layers':{
 'domain':{'paths':['app/models.py','app/service.py','app/ports.py','app/migrations.py','app/__init__.py'],'allows':['domain'],'reject_dynamic':True},
 'web':{'paths':['app/web.py','static/app.js'],'allows':['web','domain','observation']},
 'observation':{'paths':['integrations','bo_stategraph/query.py'],'allows':['domain','observation']}}}
architecture=inspect(ROOT,cfg)
result('application_architecture',not architecture['errors'],errors=architecture['errors'])
with tempfile.TemporaryDirectory(dir=ROOT/'.stategraph/scenario-data') as folder:
    target=Path(folder)
    for name in model['source_files']:
        p=target/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,p)
    manifest=capture(target,model)
    with (target/'app/service.py').open('a',encoding='utf-8') as f:f.write('\n# isolated source drift fixture\n')
    drift=check(target,model,manifest)
    result('unsynchronized_source_rejected',drift['status']!='current',binding=drift)
os.environ['TEAM_DATABASE_URL']='sqlite:///'+(ROOT/'data/team.sqlite').as_posix()
with tempfile.TemporaryDirectory(dir=WORK) as folder:
    database=Path(folder)/'schema.sqlite'
    with closing(sqlite3.connect(ROOT/'data/team.sqlite')) as source,closing(sqlite3.connect(database)) as target:source.backup(target)
    with closing(sqlite3.connect(database)) as connection,connection:connection.execute('ALTER TABLE materials RENAME COLUMN title TO fixture_title')
    os.environ['TEAM_DATABASE_URL']='sqlite:///'+database.as_posix()
    schema=synchronize(ROOT,update=False)
    result('real_schema_change_detected',any(isinstance(e,dict) and 'schema_difference' in e for e in schema['errors']),errors=schema['errors'])
os.environ['TEAM_DATABASE_URL']='sqlite:///'+(ROOT/'data/team.sqlite').as_posix()
original=BOAdapter.__init__
def bounded(self,*args,**kwargs):
    sink=kwargs.get('sink')
    def slow(body,kind):time.sleep(.003);return sink(body,kind)
    kwargs.update(capacity=1,sink=slow)
    return original(self,*args,**kwargs)
BOAdapter.__init__=bounded
try:limited=execute('flow','on',project,build)
finally:BOAdapter.__init__=original
result('bounded_queue_preserves_business',limited['observations']['published_body']=='Revised text' and limited['observations']['publication_count']==1 and limited['diagnostics']['dropped']>0,observations=limited['observations'],diagnostics=limited['diagnostics'])
BOAdapter.__init__=bounded
try:message_limited=execute_message('message_concurrency','on',project,build)
finally:BOAdapter.__init__=original
result('bounded_queue_preserves_message_idempotence',message_limited['observations']=={'changes':1,'final_count':1} and message_limited['diagnostics']['dropped']>0,observations=message_limited['observations'],diagnostics=message_limited['diagnostics'])
original_mark=Service.mark_message_read
def missing_message_write(self,token,message_id):
    return {'message_id':message_id,'is_read':True,'changed':True,'unread_count':1}
Service.mark_message_read=missing_message_write
try:omitted=execute_message('message_read')['observations']
finally:Service.mark_message_read=original_mark
result('omitted_message_write_detected',omitted['first_delta']!=1 and omitted['stored_is_read']!=1,expected={'first_delta':1,'stored_is_read':1},actual=omitted)
original_editable=Service.editable
def no_author_check(self,actor,item):
    self.require(actor['role']=='member',403,'member_required','edit_permission',actor_id=actor['id'])
    self.require(item['state']=='rejected',409,'rejected_required','edit_permission',state=item['state'])
with tempfile.TemporaryDirectory(dir=WORK) as folder:
    database=Path(folder)/'mutation.sqlite'
    service=Service(database);service.initialize()
    try:
        author,_=service.login('member','member-demo');reviewer,_=service.login('reviewer','reviewer-demo')
        item=service.submit(author,'Original','Original text')
        item=service.review(reviewer,item['id'],'reject',item['content_version'],item['revision'])
        with closing(sqlite3.connect(database)) as connection,connection:connection.execute("UPDATE accounts SET role='member' WHERE id=2")
        Service.editable=no_author_check
        service.edit(reviewer,item['id'],'Wrong author','Changed',item['content_version'],item['revision'])
        actual=200
    except domain.DomainError as error:actual=error.status
    finally:Service.editable=original_editable;service.close()
result('wrong_author_mutation_detected',actual!=403,expected=403,actual=actual,method='Isolated process monkeypatch and dedicated database; production files unchanged')
original_snapshot=domain.publication_snapshot
domain.publication_snapshot=lambda item:{**original_snapshot(item),'body':'Corrupted fixture'}
try:mutated=execute('flow')
finally:domain.publication_snapshot=original_snapshot
result('wrong_published_version_mutation_detected',mutated['observations']['published_body']!='Revised text',expected='Revised text',actual=mutated['observations']['published_body'])
with tempfile.TemporaryDirectory(dir=WORK) as folder:
    target=Path(folder)
    for name in ['app/__init__.py','app/service.py','app/models.py','app/ports.py','app/migrations.py']:
        p=target/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,p)
    import subprocess
    script="from app.service import Service; s=Service('isolated.sqlite'); s.initialize(); t,_=s.login('member','member-demo'); assert s.submit(t,'Independent','Business without observer')['state']=='pending'; s.close(); print('independent core passed')"
    proc=subprocess.run([sys.executable,'-B','-X','utf8','-c',script],cwd=target,capture_output=True,text=True)
    result('application_core_runs_without_observer_files',proc.returncode==0,exit_code=proc.returncode,stdout=proc.stdout,stderr=proc.stderr)
graph=BOStateGraph(model,build_id=build,mode='observe')
export=bo_validate_export(graph.bo_export())
result('public_stategraph_export_valid',export['build_id']==build and export['model']==model)
record=read('evidence/recordings/browser-on-original.json')
frames=record['runtime_frames']['frames']
result('historical_record_has_actual_commit_frames',len(frames)==5,frames=len(frames),partial=record['runtime_frames']['partial'],scope='Snapshot coverage for five material commits; not every event has an authoritative state snapshot.')
(ROOT/'evidence/checks/project-extra.json').write_text(json.dumps({'build_id':build,'checks':results,'passed':all(r['passed'] for r in results)},ensure_ascii=False,indent=2),encoding='utf-8')

