# Runtime checkpoint evidence

**Not the final release.** The public runtime combines expired live history with dropped events. Raw health, screenshots and the retention harness failure are preserved. A separately authorized upstream fix and limited boundary retest are pending.

Checkpoint runtime commit: `1bfeb39853a88ac5b9d02b675a010486b0832574`. Application build: `5fb8a3e5aa68a759c49bdd3ef2c719b64a575392f5504fa2d152d3370faac737`. These public-only upgrades do not change application build identity.

| Stage | Native receipt | Actual recording | Status |
| --- | --- | --- | --- |
| Original v2 / 920c015 | [verify](../review/verification-v2.json) | [922 events, 5 material frames](recordings/browser-on-v2-final.json) | Frozen v2 |
| 9134c61 | [verify](../review/runtime-upgrade-verification-9134c61.json) | [919 events, 5 material frames](recordings/browser-runtime-9134c61.json) | Frozen interim; replay/code failure retained |
| e8e922e | [verify](../review/runtime-e8e922-verification.json) | [307 message events, 0 material frames](recordings/browser-runtime-e8e922-final-messages.json) | Frozen checkpoint; reload failure retained |
| 1bfeb39 | [verify](../review/runtime-1bfeb39-verification.json), [accept](../review/runtime-1bfeb39-accepted.json), [check](../review/runtime-1bfeb39-check.json) | [307 fresh message events, 0 material frames](recordings/browser-runtime-1bfeb39-final-messages.json) | Checkpoint; retention/recording fix pending |

Native verification reran the unchanged on/off/fault matrix (108 assertions), standalone 37 assertions, whitebox and project checks. Its browser witness remains the original accepted v2 witness for the identical application source/build. Fresh runtime recordings are additional identified evidence; historical recordings are never relabeled.

## Iteration checks

Changed files: conversation.js and viewer.js. Neighboring checks cover saved analysis, discussion, camera, positions, expansion, notes, filters, recording/live switching and source/data navigation. Business graph and independent expectations remain unchanged.

- [Canonical checklist](iteration-graph-checks-1bfeb39.md), [formal upgrade](checks/runtime-1bfeb39-upgrade.json), [131 managed files / source identity](checks/runtime-1bfeb39-source-identity.json), [28 protected hashes](checks/runtime-upgrade-protected-hashes.json).
- [Three strict actual reload pairs](checks/runtime-1bfeb39-reload-acceptance.json): business with active discussion, code with cleared discussion, and code after replay/live return. Every preference entry is identical, including annotations, positions, camera, expansion and filters. Screenshots 072-076 and 082.
- [Replay boundary](checks/runtime-1bfeb39-replay-boundary.json): native HTMLOptionElement.disabled, replay business nodes, restored live code. The unreliable option.isDisabled helper was not used.
- [Final message outcomes and SQLite reads](checks/runtime-1bfeb39-message-outcomes.json): first 8->7, repeat 7->7. Screenshots 077/080.
- [Browser checks](checks/runtime-1bfeb39-browser-checks.json): source 081/083, local code 084, actual is_read catalog 085. Full code loaded 674 nodes/946 relations while recording (078). Local region: 53 nodes/228 relations, 80 boundary nodes, 120 omitted links.
- [Eight isolated code-index checks](checks/runtime-guardrails-1bfeb39.json) and [12 project checks](checks/runtime-1bfeb39-project-checks.json), including omitted effects, incorrect values, queue bounds, real schema drift and observer-independent execution.
- [No viewer-generated business events](checks/runtime-1bfeb39-controls-no-events.json): attempted/written remained 1533. The live viewer expired 919 old events under its 1800-second retention. No restart hides this state; reception gaps remain zero and the stopped new recording is complete.
- [Old-build filtering after actual reload](checks/runtime-1bfeb39-recording-filter.json), [visible options](checks/runtime-1bfeb39-visible-recordings.json). Same-build recordings remain valid; old evidence remains on disk.
- [Failures/fixes/retests](checks/runtime-upgrade-failures-fixes-retests.json), [e8e922 reproduction](checks/runtime-e8e922-reload-reproduction.json), [archive integrity](checks/frozen-archives-preserved.json).

This is a scripted trial, not an independent human usability study. Static unresolved references remain unknown. The SQLite catalog covers configured tables and supported constraints, not triggers/stored routines. The package includes the actual v1 migration fixture; live application databases and collector credentials are excluded.
