# Final runtime evidence

Final commit: `fa372897d69f0b6096392020ed3012284a011b4e`. Current application build: `5fb8a3e5aa68a759c49bdd3ef2c719b64a575392f5504fa2d152d3370faac737`. Public runtime changes are identified by commit and managed-file hashes; the application build remains unchanged.

| Stage | Native receipt | Executed browser evidence | Status |
| --- | --- | --- | --- |
| Original v2 | [verify](../review/verification-v2.json) | [922 events, 5 material frames](recordings/browser-on-v2-final.json) | Frozen |
| 9134c61 | [verify](../review/runtime-upgrade-verification-9134c61.json) | [919 events, 5 material frames](recordings/browser-runtime-9134c61.json) | Replay/code failure retained |
| e8e922e | [verify](../review/runtime-e8e922-verification.json) | [307 message events](recordings/browser-runtime-e8e922-final-messages.json) | Saved-view reload failure retained |
| 1bfeb39 | [verify](../review/runtime-1bfeb39-verification.json) | [307 fresh message events](recordings/browser-runtime-1bfeb39-final-messages.json), three strict reload pairs | Expiry/missing distinction failure retained |
| fa37289 final | [verify](../review/runtime-fa37289-verification.json), [accept](../review/runtime-fa37289-accepted.json), [check](../review/runtime-fa37289-check.json) | [12 actual isolated browser events](recordings/browser-fa37289-retention-complete.json), separate explicit gap negative, final delivery-view regression | Accepted |

All four native categories passed; the unchanged 37 standalone, 108 on/off/fault, 9 whitebox and 12 project checks ran. Native verification reuses the valid original v2 browser witness for identical business source/build. The 12-event final retention recording is fresh isolated evidence with its own SQLite catalog identity. Historical recordings are never relabeled.

## Final focused evidence

- [Iteration checklist](iteration-graph-checks-fa37289.md), [formal upgrade](checks/runtime-fa37289-upgrade.json), [source identity](checks/runtime-fa37289-source-identity.json), [protected hashes](checks/runtime-upgrade-protected-hashes.json).
- [Full retention report](../review/05-retention-recording-boundaries-final.md): count/time expiry, complete recording matched to independent event log, deliberate missing sequence, Chinese/English wording and settings restoration. Screenshots 086-090.
- [Delivery regression](checks/runtime-fa37289-delivery-regression.json): data/code views, preserved-record replay, native code-option boundary, actual saved-view reload, notes/positions/camera/filters, cleared discussion and zero observer-generated business events. Screenshots 091-093.
- [Raw preference normalization](checks/runtime-fa37289-preference-serialization.json): only inactive optional null codeFocus omitted on first startup; strict subsequent reload remained identical.
- [Actual live binding](checks/runtime-fa37289-final-live-binding.json), [12 project checks](checks/runtime-fa37289-project-checks.json), [restored retention](checks/runtime-fa37289-retention-restored.json).
- [Fixture setup failures and repair](checks/runtime-fa37289-fixture-copy-failure-repair.json); raw failed-start logs retained. Public runtime and business source were not patched locally.
- [1bfeb39 checkpoint index](RUNTIME_1BFEB39_CHECKPOINT_INDEX.md), [e8e922 reload failure](checks/runtime-e8e922-reload-reproduction.json), [failure ledger](checks/runtime-upgrade-failures-fixes-retests.json), [frozen archive integrity](checks/frozen-archives-preserved.json).

The earlier 1bfeb39 raw health, screenshot labels and retention harness failure remain intact. Final health separates actual producer gaps from normal history expiry; the deliberately missing-event negative proves the distinction was not implemented by suppressing all gap detection.

Static unresolved calls (354) remain unknown; code index 674 nodes/946 edges is static context. Local graph budgets and boundaries remain explicit. The catalog covers configured/default schema and dialect-supported constraints, not triggers/stored routines. This is a bounded scripted local trial, not a human usability study or exhaustive semantic proof. Upstream suite results reported by another chat are not included in this Demo's pass counts.
