# Trial evidence index — original v2

## Actual dialogue and authority

The dialogue is a user-style trial explicitly identified by the originating chat as simulated-user confirmation. It is not claimed as independent human research. The verbatim prompts and answers are retained in `conversation/000-request.txt` through `006-iteration-confirmation.txt`; `discovery.json` records source IDs, questions, decisions and previous values. External reports of 24 v1 and 20 migration checks and upstream multi-database tests are user-reported evidence, not checks executed by this chat.

## Reproduce and inspect

| Trial | Evidence |
| --- | --- |
| v1 source/evidence remains frozen | `v1-freeze-preserved` in `checks/v1-freeze-preserved.json`; sibling v1 ZIP |
| Confirmed incremental graph | `../review/message-read-preview.md`, `../review/message-read-implemented.md`, screenshots 020/021 |
| v1 to v2 source, graph, expectations and actual schema | `../review/v1-v2-diff.md` and its four linked files |
| Actual existing database migration | `migrations/v1-before.sqlite`, `migrations/v2-applied.json` |
| Recipient/anonymous/revoked access, list-read-only, idempotence, concurrency | `../tooling/message_scenarios.py`, `checks/v2-observations-final-prebrowser.json` |
| Independent business and whitebox expectations | `../acceptance.json`, `../whitebox.json`, `../review/verification-v2.json` |
| On/off/fault browser equality | `checks/v2-browser-equivalence.json`, `browser-runtime.json`, `checks/v2-browser-ui.json` |
| Final no-gap actual recording | `recordings/browser-on-v2-final.json` |
| Preserved earlier gap recording | `recordings/browser-on-v2-workflow.json` and screenshot 035 |
| First/repeat read and final publication UI | screenshots 040, 041 and 042-on/off/fault |
| Replay values/source/local code/full code/database | screenshots 043 through 047 |
| Source staleness, schema drift, queue limits, omitted write and semantic mutations | `checks/project-extra.json` |
| Failure, fix and retest ledger | `checks/v2-failures-fixes-retests.json`; all earlier verification receipts remain under `../review/` |
| Four separate native reports | `../review/01-implementation-mapping-v2.json` through `04-project-checks-v2.json` |
| Accept and current binding | `../review/accepted-v2.json`, `../review/check-v2.json`, `v2-release.json` |

The final runtime upgrade is a separate stage. These v2 receipts and the v2 ZIP remain frozen. Material snapshots cover actual commits; they do not claim a snapshot for every query or a second authoritative message state machine. Static unknown calls remain unknown. Database inspection does not cover triggers or stored routines.
