# Executed fixture scripts

These are the actual execution scripts preserved from the trial work directory. Their BASE/ROOT paths retain the original workspace layout for audit; adapt those locations for a new checkout. They are not changes to application business logic or public runtime.

Reproduction procedure: install the ordinary QUICKSTART dependencies, make independent copies with the adapter dependencies intact, back up SQLite into each copy, set only the copies to memory_events=2 and memory_seconds=3, and launch one with run.py on separate local ports. Start a recording in its real viewer, refresh the public page twice, capture the live count boundary with the monitor, then wait beyond 3 seconds. Stop and replay the recording. Compare its interval with events.jsonl. Run the deliberately skipped-sequence test in the other copy. Never inject its synthetic events into the delivery Demo.

The delivered project retains normal 10000-event/1800-second defaults. The two isolated services were stopped and their temporary configurations restored to defaults after the captured tests. The first clone copy/parser failures and their repair are retained in the corresponding checks evidence.
