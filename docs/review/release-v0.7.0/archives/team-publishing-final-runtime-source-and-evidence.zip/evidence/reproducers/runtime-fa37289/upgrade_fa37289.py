import hashlib,json,subprocess,sys
from pathlib import Path
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parents[1]/'outputs/team-publishing-next'
SKILL=Path('C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/skills/business-observer')
COMMIT='fa372897d69f0b6096392020ed3012284a011b4e'
def read(p):return json.loads((ROOT/p).read_text(encoding='utf-8-sig'))
def save(p,v):(ROOT/p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def run(script,*args,out,required=True):
    env=dict(__import__('os').environ,TEAM_DATABASE_URL='sqlite:///'+(ROOT/'data/team.sqlite').as_posix())
    p=subprocess.run([sys.executable,'-B','-X','utf8',str(script),*args],cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8')
    (ROOT/out).write_text(p.stdout,encoding='utf-8');(ROOT/(out+'.stderr.log')).write_text(p.stderr,encoding='utf-8')
    print(out,p.returncode,flush=True)
    if required and p.returncode:raise RuntimeError(p.stdout[-1500:]+p.stderr)
    return json.loads(p.stdout)
request='Officially upgrade the same Demo to '+COMMIT+'. Preserve the 1bfeb39 checkpoint. Validate four gates/protected hashes, actual recording across isolated count/time expiry, distinct expired UI, real missing-producer-event negative control in isolation, view/replay and observer exclusions. Restore normal retention. No new business.'
(ROOT/'evidence/conversation/013-final-retention-request.txt').write_text(request+'\n',encoding='utf-8')
protected=read('evidence/checks/runtime-upgrade-protected-hashes.json');assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in protected.items())
before=(ROOT/'bo_stategraph/config/views/local.json').read_bytes()
save('evidence/checks/runtime-fa37289-preferences-before.json',json.loads(before))
run(ROOT/'observer_runtime/change_sync.py','begin','--root',str(ROOT),'--change','.stategraph/runtime-retention-fix','--request',request,out='review/runtime-fa37289-begin.json')
upgrade=run(SKILL/'scripts/bo_upgrade.py','apply','--root',str(ROOT),'--runtime','observer_runtime','--module','bo_stategraph','--viewer','static/graph',out='evidence/checks/runtime-fa37289-upgrade.json')
assert upgrade['valid'] and not upgrade['conflicts']
assert before==(ROOT/'bo_stategraph/config/views/local.json').read_bytes()
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==h for p,h in protected.items())
save('evidence/checks/runtime-fa37289-upgrade-parity.json',{'commit':COMMIT,'protected_files':len(protected),'business_source_and_expectations_unchanged':True,'saved_view_file_byte_identical':True,'changes':upgrade['changes']})
run(ROOT/'tooling/build_model.py',out='evidence/checks/runtime-fa37289-build-model.json')
run(ROOT/'observer_runtime/bo_sync.py','scan','--root',str(ROOT),out='evidence/checks/runtime-fa37289-scan.json')
impact=run(ROOT/'tooling/verify.py','inspect',out='review/runtime-fa37289-inspect.json',required=False)
assert not impact['errors']
review=read('.stategraph/runtime-preference-fix/review.json');review['candidate_id']=impact['candidate_id']
save('.stategraph/runtime-retention-fix/review.json',review)
verification=run(ROOT/'tooling/verify.py','verify',out='review/runtime-fa37289-verification.json');assert verification['valid']
run(ROOT/'observer_runtime/change_sync.py','accept','--root',str(ROOT),out='review/runtime-fa37289-accepted.json')
run(ROOT/'tooling/verify.py','check',out='review/runtime-fa37289-check.json')
