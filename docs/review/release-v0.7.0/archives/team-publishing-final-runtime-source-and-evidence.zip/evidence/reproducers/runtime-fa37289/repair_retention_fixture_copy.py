import hashlib,json,shutil
from pathlib import Path
BASE=Path(__file__).resolve().parents[1];ROOT=BASE/'outputs/team-publishing-next'
checks=[]
for name in ['retention-browser-fa37289','retention-negative-fa37289']:
    dest=BASE/'work'/name
    shutil.copytree(ROOT/'observer_runtime/bo_observer/data',dest/'observer_runtime/bo_observer/data')
    managed=json.loads((ROOT/'bo_stategraph/runtime-version.json').read_text())['files']
    mismatches=[p for p,h in managed.items() if not (dest/p).is_file() or hashlib.sha256((dest/p).read_bytes()).hexdigest()!=h]
    assert not mismatches,mismatches
    checks.append({'fixture':name,'managed_files':len(managed),'all_bytes_match_delivered_runtime':True})
report={'stage':'fixture preparation only','failure':'The initial copy filter excluded every directory named data and accidentally omitted observer_runtime/bo_observer/data source. Startup failed with ModuleNotFoundError: No module named bo_observer.data. No runtime test pass was counted.','repair':'Copy the missing unchanged public package and make the fixture filter path-specific. Verify all managed file hashes before retry.','checks':checks,'business_and_public_source_edits':False}
(ROOT/'evidence/checks/runtime-fa37289-fixture-copy-failure-repair.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
shutil.copy2(BASE/'work/fa37289-retention.err.log',ROOT/'evidence/checks/runtime-fa37289-fixture-first-start.stderr.log')
shutil.copy2(BASE/'work/retention-browser-fa37289/.stategraph/observer.log',ROOT/'evidence/checks/runtime-fa37289-fixture-first-observer.log')
print(checks)
