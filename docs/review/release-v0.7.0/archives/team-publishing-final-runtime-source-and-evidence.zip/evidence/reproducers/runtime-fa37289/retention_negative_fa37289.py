import copy,json,os,sys,time
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE/'work/retention-negative-fa37289'
OUT=BASE/'outputs/team-publishing-next'
os.environ['TEAM_DATABASE']=str(ROOT/'data/team.sqlite')
os.environ['TEAM_DATABASE_URL']='sqlite:///'+(ROOT/'data/team.sqlite').as_posix()
sys.path[:0]=[str(ROOT),str(ROOT/'observer_runtime')]
from bo_observer.service import GraphSession
session=GraphSession(ROOT)
session.history.limits.update(memory_events=1,memory_seconds=1)
template=json.loads((OUT/'evidence/recordings/browser-runtime-1bfeb39-final-messages.json').read_text(encoding='utf-8'))['events'][0]
def emit(seq):
    event=copy.deepcopy(template)
    for key in ['source_seq','stream_id']:event.pop(key,None)
    event.update(run_id='isolated-negative-fa37289',producer_id='deliberate-gap-producer',seq=seq,id=f'isolated-negative-fa37289:producer:{seq}',call_id=f'isolated-negative-fa37289:call:{seq}',parent_call_id=None,depends=[])
    return session.event(event)
try:
    emit(1)
    started=session.recordings.start('Isolated actual missing producer event: intentionally omit sequence 2')
    emit(3)
    count_view=session.view()
    assert count_view['health']['dropped']==1 and count_view['health']['evicted_events']==1
    time.sleep(1.2)
    expired=session.view()
    assert expired['events']==[] and expired['health']['evicted_events']==2 and expired['health']['dropped']==1
    stopped=session.recordings.stop();saved=session.recordings.get(stopped['id'])
    assert [e['source_seq'] for e in saved['events']]==[3]
    assert any('lost events' in gap for gap in saved['gaps'])
    result={'runtime_commit':'fa372897d69f0b6096392020ed3012284a011b4e','passed':True,'fixture_root':str(ROOT),'method':'Separate GraphSession using copied Demo source and an isolated SQLite backup. Injected sequences 1 and 3 from one identified test producer; sequence 2 is deliberately absent. These are synthetic negative-control inputs, not application operations.','count_health':count_view['health'],'after_time_expiry_health':expired['health'],'recording_event_source_sequences':[3],'recording_gaps':saved['gaps'],'delivery_demo_untouched':True}
    (OUT/'evidence/checks/runtime-fa37289-retention-negative.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    (OUT/'evidence/recordings/isolated-fa37289-deliberate-gap.json').write_text(json.dumps(saved,indent=2)+'\n',encoding='utf-8')
    print({'passed':True,'actual_missing_events':1,'expired_events':2,'recording_gap_reported':True})
finally:session.recordings.close()
