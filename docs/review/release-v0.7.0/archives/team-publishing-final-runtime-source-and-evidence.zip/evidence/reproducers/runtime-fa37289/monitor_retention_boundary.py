import json,time
from pathlib import Path
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parents[1]/'outputs/team-publishing-next'
def view():
    with urlopen('http://127.0.0.1:51240/api/view',timeout=10) as r:return json.load(r)
initial=view();baseline=initial['health']['written'];start=time.monotonic();count=None
while time.monotonic()-start<45:
    current=view();health=current['health']
    if health['written']>=baseline+3 and len(current['events'])==2:
        count={'health':health,'events':current['events']};break
    time.sleep(.05)
assert count is not None,'No real operation crossed the count limit while the monitor was active'
last_written=count['health']['written'];last_change=time.monotonic()
while time.monotonic()-start<55:
    current=view();health=current['health']
    if health['written']!=last_written:last_written=health['written'];last_change=time.monotonic()
    if time.monotonic()-last_change>3.5 and not current['events']:break
    time.sleep(.05)
assert health['written']>baseline and not current['events'] and health['dropped']==0 and health['errors']==0
out={'passed':True,'runtime_commit':'fa372897d69f0b6096392020ed3012284a011b4e','method':'Read-only API monitor concurrent with an actual CUA Refresh public page click. Count limit crossed while 2 events were retained; real elapsed time then cleared all live events while the recording stayed active.','initial_health':initial['health'],'count_boundary':count,'time_boundary':{'health':health,'events':current['events']}}
(ROOT/'evidence/checks/runtime-fa37289-count-time-boundaries.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print({'passed':True,'count_retained':len(count['events']),'time_retained':0,'written':health['written'],'dropped':health['dropped'],'expired':health['evicted_events']})
