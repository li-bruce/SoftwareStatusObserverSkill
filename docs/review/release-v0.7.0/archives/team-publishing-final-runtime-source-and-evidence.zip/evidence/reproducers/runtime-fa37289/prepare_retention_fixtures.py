import json,shutil,sqlite3
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
ROOT=BASE/'outputs/team-publishing-next'
ignored={'node_modules','__pycache__','scenario-data','test-work'}
def exclude(path,names):
    result=[n for n in names if n in ignored or n in ['collector.json','runtime.json'] or n.endswith(('.pyc','.lock','.log'))]
    if Path(path) in [ROOT,ROOT/'bo_stategraph'] and 'data' in names:result.append('data')
    return result
fixtures=[]
for name in ['retention-browser-fa37289','retention-negative-fa37289']:
    dest=BASE/'work'/name
    assert not dest.exists(), 'Preserve an existing test fixture instead of overwriting it'
    shutil.copytree(ROOT,dest,ignore=exclude)
    (dest/'data').mkdir(exist_ok=True)
    with sqlite3.connect(ROOT/'data/team.sqlite') as source,sqlite3.connect(dest/'data/team.sqlite') as target:source.backup(target)
    config=dest/'bo_stategraph/config/retention.json'
    config.parent.mkdir(parents=True,exist_ok=True)
    limits={'memory_events':2,'memory_seconds':3,'log_bytes':8388608,'log_backups':2}
    config.write_text(json.dumps(limits,indent=2)+'\n',encoding='utf-8')
    fixtures.append({'path':str(dest),'limits':limits,'database':'Independent SQLite backup of Demo; no delivery database writes.'})
main=ROOT/'bo_stategraph/config/retention.json'
evidence={'runtime_commit':'fa372897d69f0b6096392020ed3012284a011b4e','fixtures':fixtures,'delivery_retention_config_exists':main.exists(),'delivery_retention_config':json.loads(main.read_text()) if main.exists() else None,'delivery_defaults':{'memory_events':10000,'memory_seconds':1800},'delivery_settings_changed':False}
(ROOT/'evidence/checks/runtime-fa37289-fixtures.json').write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
print({'fixtures':[f['path'] for f in fixtures],'main_retention_unchanged':True})
