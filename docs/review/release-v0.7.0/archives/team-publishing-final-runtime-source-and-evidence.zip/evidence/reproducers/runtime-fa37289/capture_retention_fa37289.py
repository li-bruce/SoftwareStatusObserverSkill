import hashlib,json,sqlite3
from pathlib import Path
from urllib.request import urlopen
BASE=Path(__file__).resolve().parents[1];ROOT=BASE/'outputs/team-publishing-next';FIX=BASE/'work/retention-browser-fa37289'
def get(port,path):
    with urlopen(f'http://127.0.0.1:{port}'+path,timeout=20) as response:return json.load(response)
def save(name,v):(ROOT/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
record=get(51240,'/api/recordings/d00973fea73c4bd0aec67b45b07c827b')
view=get(51240,'/api/view');main=get(51236,'/api/view')
assert record['status']=='stopped' and len(record['events'])==12 and record['gaps']==[]
assert record['start_seq']==62 and record['end_seq']==74
log=[json.loads(line) for line in (FIX/'bo_stategraph/data/events.jsonl').read_text(encoding='utf-8').splitlines() if line]
interval=[e for e in log if record['start_seq']<e['seq']<=record['end_seq']]
assert [e['id'] for e in interval]==[e['id'] for e in record['events']]
assert [e['seq'] for e in record['events']]==list(range(63,75))
returns=[e['outputs'] for e in record['events'] if e['node']=='public_materials' and e['phase']=='return']
if not returns:returns=[{'node':e['node'],**e['outputs']} for e in record['events'] if 'count' in e.get('outputs',{})]
assert len(returns)==2 and all(e['count']==6 for e in returns)
health=view['health'];assert health['written']==health['attempted']==74 and health['dropped']==health['errors']==0 and health['evicted_events']==74 and not view['events']
with sqlite3.connect(FIX/'data/team.sqlite') as connection:publications=connection.execute('SELECT COUNT(*) FROM publications').fetchone()[0]
assert publications==6
protected=json.loads((ROOT/'evidence/checks/runtime-upgrade-protected-hashes.json').read_text());assert all(hashlib.sha256((FIX/f).read_bytes()).hexdigest()==h for f,h in protected.items())
file_differences=[f for f in set(main['manifest']['files'])|set(view['manifest']['files']) if main['manifest']['files'].get(f)!=view['manifest']['files'].get(f)]
assert file_differences==['bo_stategraph/database-catalog.json']
save('evidence/recordings/browser-fa37289-retention-complete.json',record)
save('evidence/checks/runtime-fa37289-retention-positive.json',{'runtime_commit':'fa372897d69f0b6096392020ed3012284a011b4e','passed':True,'recording_id':record['id'],'events':12,'start_seq':62,'end_seq':74,'gaps':[],'independent_event_log_interval_matches':True,'event_log_interval':interval,'actual_ui_operations':'Two real Refresh public page clicks in the isolated Demo browser. No synthetic events in this recording.','returned_counts':returns,'independent_sqlite_publications':publications,'health_after_recording_and_observer_controls':health,'observer_controls_added_events':False,'source_and_expectation_hashes_match_delivery':True,'delivery_build':main['manifest']['build_id'],'fixture_build':view['manifest']['build_id'],'build_identity_boundary':'The clone has its own generated SQLite catalog identity and model hash. All 28 protected business/expectation files match; only database-catalog.json differs in the two source manifests. This recording is explicitly an isolated-fixture recording, not relabeled as a delivery-build recording.','manifest_file_differences':file_differences})
save('evidence/checks/runtime-fa37289-main-health-after-restart.json',{'health':main['health'],'manifest':main['manifest'],'binding':main['binding_status']})
print({'passed':True,'real_recorded_events':12,'independent_log_matches':True,'gaps':[],'retained_live':0,'expired':health['evicted_events'],'observer_only_event_delta':0,'fixture_build':view['manifest']['build_id']})
