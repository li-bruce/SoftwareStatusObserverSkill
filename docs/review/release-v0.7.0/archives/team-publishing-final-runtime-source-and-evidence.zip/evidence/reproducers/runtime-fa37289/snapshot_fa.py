import json,sys
from pathlib import Path
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parents[1]/'outputs/team-publishing-next'
def get(path):
    with urlopen('http://127.0.0.1:51236'+path,timeout=15) as response:return json.load(response)
view=get('/api/view');prefs=get('/api/preferences')
value={'preferences':prefs,'health':view['health'],'build_id':view['manifest']['build_id'],'binding':view['binding_status'],'recordings':get('/api/recordings')}
(ROOT/('evidence/checks/runtime-fa37289-'+sys.argv[1]+'.json')).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
analysis=json.loads(prefs['entries']['business-observer.layout.v2:team-publishing-demo:analysis'])
print({'snapshot':sys.argv[1],'revision':prefs['revision'],'selected':analysis['selected'],'written':view['health']['written'],'dropped':view['health']['dropped'],'retention':view['health']['retention']})
