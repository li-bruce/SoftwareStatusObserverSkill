# Frozen candidate findings

Project: `C:\Users\Lvi_P\Documents\Codex\2026-10-23\business-observer-gallery-python`.
Only the project-local frozen candidate is under test. Its 142 copied files are
unchanged. No public candidate, main repository, or other trial was edited.

## D01: Windows viewer metadata key normalization

Reproduction: `review/defects/windows-viewer-paths/reproduction.json`.
Full failed scan: `review/commands/25-source-scan.stdout.log`.
Before metadata: `review/defects/windows-viewer-paths/runtime-version.before.json`.
Local patch: `review/defects/windows-viewer-paths/metadata.patch`.

Concrete frozen source locations:

- `.agents/skills/business-observer/scripts/bo_upgrade.py`, `plan()`, lines 48 and 69-70:
  concatenates the `--viewer` argument without normalizing Windows separators.
- `.agents/skills/business-observer/scripts/bo_observer/workflow/bo_sync.py`,
  `source_inventory()`, lines 51 and 69-72: creates POSIX relative names and
  performs `known.get(name)` on the mixed-separator metadata.

Actual example: generated key `static\\graph/analysis.js`; lookup key
`static/graph/analysis.js`. Both refer to the same unmodified file and SHA256.
It incorrectly proceeds to JavaScript parser checks on the managed viewer.
This was reported in conversation before the local workaround.

Local workaround changes only generated metadata keys to forward slashes.
It preserves all file hashes and source checks. Rebuild and inspect remove the
managed-viewer parser gaps. Upstream installer remains unmodified.

## D02: Chained calls produce colliding coding-question identities

Reproduction: `review/defects/chained-call-question-ids/reproduction.json`.
Frozen function: `.agents/skills/business-observer/scripts/bo_observer/development.py`,
`questions()`: `ident = from + line + column`; expression is not part of identity.
`reconciliation_errors()` then indexes expected questions by this colliding ID.

For actual `Gallery.login` source line 47, both `db.execute` and the chained
`.fetchone` have column 18. Five such collisions occur in the first implementation.
The initial project reconciliation preserved both records and inspect rejected
them as `duplicate implementation answer` (command 31-inspect).

Project-local workaround: group colliding IDs and retain all original expressions
in one answer. These five groups all refer to the same external sqlite3 boundary.
Do not claim this fixes general multi-target collisions. The frozen source and
the original failed reconciliation are retained through command evidence.

## G01: Conversation-first graph guidance gap

The initial phase showed a real Web URL and its screenshot, but no concise inline
business network before asking the questions. The parent task explicitly required
a direct conversation graph, such as Mermaid, before later iteration. This is a
guidance gap in the candidate's conversation workflow, not an application failure.

Relevant frozen files: `SKILL.md` section 1 and
`references/conversation-web.md`, "开始讨论". They instruct opening the Web graph
but do not explicitly require both a concise inline graph and clickable real URL.
The actual current same-source business network was subsequently shown inline in
conversation with the live URL. No settled rule was asked again. The diagram and
its provenance are saved at `review/confirmed-network.mmd`.

## D03: Valid model omits labels but runtime viewer assumes them

The project declaration passed `validate_project` and all static/model checks
without machine.labels. The actual runtime viewer crashed only once a real
instance had a current state. Source:
`.agents/skills/business-observer/assets/stategraph-viewer/viewer.js`,
`updateFacts()` line 382, reads `view.model.machine.labels[phase]` without a
fallback. The project schema's machine required fields do not include labels.

Minimal retained payload: `review/evidence/live-final-view.raw.json` (real HTTP
response from the failing build), with machine.labels absent and current state
`rejected`. Exact browser errors: `review/evidence/browser-state-label-errors.json`.
Screenshot: `review/screenshots/browser-label-contract-failure.png`.

Project-local repair adds presentation labels for the four actual declared states.
No executable transition, expected effect, frozen asset, or check is changed.
The project regression check verifies that its returned model supplies labels for
every declared state. Upstream should either require labels or handle absence.

## L01: Locale migration

See `review/limitations.md`. The frozen viewer still has Chinese fixed controls
and no explicit language selector. A later candidate upgrade is expected from the
parent task; this trial continues business verification without patching its UI.

## D04: Design focus command cannot read bo-project/v1 envelopes

Reproduction command and raw traceback:
`review/commands/48-refresh-focus.json` and `.stderr.log`.
`sync.json.model` points to the valid required `bo_stategraph/project.json`.
Frozen source:
`.agents/skills/business-observer/scripts/bo_observer/web/bo_design.py`,
`BODesign.focus()` line 75, directly indexes `read(model_path)['nodes']`.
The protocol places those nodes in `project['model']['nodes']`.

Project-local workaround: `tooling/focus_project.py` uses the frozen common
`read_model` reader in that command process, then invokes the same unchanged
`bo_design.main()` and focus logic. It retains plain record reading behavior and
unwraps only the project envelope. No file in the frozen Skill or managed runtime
is patched. Actual command retest is recorded separately, preserving exit 1 from
the original command. This workaround does not repair the candidate upstream.

## D05: Candidate 2 replay prioritizes a generic activity label over a project state

Status: reproduced, not patched in the frozen candidate or viewer copy under test.
Concrete source: candidate-2 `assets/stategraph-viewer/viewer.js`, `boText()`:
it evaluates `stateLabels[value]` before `view.model.machine.labels[value]`.
The shared activity label for pending is Not started / 尚未开始. This project's
declared business state pending is 待审核. Both languages preserve model labels,
but the replay change panel displays the activity meaning for the business state.

Minimal actual evidence:

- `review/evidence/candidate2-browser-recording-original.json`: upload commit
  outputs.state is pending, revision 1; the model labels pending as 待审核.
- `review/evidence/candidate2-pending-label-defect-state.txt`: the actual browser
  change panel displays 尚未开始 for state and for the later review.before.
- `review/screenshots/candidate2-pending-label-defect.png`: original screenshot.

This does not alter the actual SQL value, public-instance mapping, or business
decision. It is a semantic display failure, so complete viewer acceptance must
not be called passed. No history is rewritten and no state ID is renamed to
avoid this collision. The trial's other locale and replay checks remain separate.

## Project implementation mistakes (not Skill defects)

The first whitebox contract used a protocol name instead of `schema_version: 1`.
The actual plan command failed, was preserved, and the project generator was
corrected. No assertion was removed or weakened.

The candidate-2 state-boundary adapter also needed runtime_frames.partial=true
to avoid diagnosing ordinary calls as missing state snapshots. This scope marker
is implemented in the frozen recorder but is absent from the frame integration
description in references/recorded-analysis.md. Treat this as an integration
documentation gap, not a confirmed defect in the recorder's declared partial
behavior. Both the original record and a real missing-state-frame counterexample
are retained. See review/failures.md F05.
