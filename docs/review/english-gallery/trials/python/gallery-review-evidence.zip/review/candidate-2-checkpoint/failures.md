# Failures, repairs, and retests

## F01: Default Python virtual environment creation

Command: `python work/prepare_trial.py`, using
`C:\Users\Lvi_P\miniforge3\python.exe`.

The first virtual environment creation returned exit code 1. Raw evidence:
`commands/01-create-venv.json`, `.stdout.log`, and `.stderr.log`.
The underlying diagnostic was `Failed to find real location of ...python.exe`,
followed by an `ensurepip` subprocess failure. An independent import also showed
that the default interpreter has no `jsonschema` installed.

This is an environment failure, not evidence of a frozen Skill defect.
Repair: retain the incomplete `work/venv` and use the app-bundled Python 3.12.14
to create a separate `work/runtime-venv`. Retest evidence uses a new command ID,
`01b-create-runtime-venv`, preserving the failed command rather than replacing it.

The bundled interpreter also failed at ensurepip (exit 1). Direct reproduction
with `work/runtime-venv/Scripts/python.exe -m ensurepip --upgrade --default-pip`
revealed a PermissionError writing a pip wheel to the sandbox's external Temp
directory. The virtual environment interpreter itself runs successfully.
Repair: set TMP and TEMP to the writable project `work/tmp`, then rerun ensurepip
with a new command ID `01c-ensurepip-workspace-temp`. This avoids escalation and
preserves both previous failures. The earlier interpreter diagnostic did not by
itself establish the root cause; the Temp-path failure is the concrete finding.

## S00: Exploratory search with no matches

The initial workspace/memory/environment inspection command returned exit code 1
because its final `rg --files -g AGENTS.md` search found no applicable files.
The PowerShell output listed the default Python path. This was a read-only
exploratory search; no project check or business test failed.

## F02: Design server process lifecycle and reachability

`work/start_design.py` exited 0 and captured actual HTTP 200 responses from its
first child process (recorded PID 83964); after the parent command completed,
the browser reported ERR_CONNECTION_REFUSED, and a new PowerShell HTTP request
also failed. The old startup record is retained as historical startup evidence,
not evidence of a currently accessible server.

A second sandbox-hosted foreground attempt (exec session 54507, port 8840) did
not produce a cross-tool reachable endpoint. A hidden Start-Process launch using
the local venv (launcher PID 46164; Python child PID 52544) showed a listener on
127.0.0.1:8840, but both browser and independent HTTP requests timed out. A
direct request with ProxyHandler({}) also timed out; a proxy bypass was not a fix.
The exact root cause of these attempts is unresolved. Do not label this as a
Skill defect on that evidence alone.

Repair: use the bundled Python executable directly in a foreground hosted
session, with `-B`, the exact project-local frozen script, absolute project root,
and loopback port 8841. It printed the design URL; a new in-app browser tab
successfully rendered all five nodes and four relations. Actual browser state,
raw HTTP responses, and screenshot are preserved. No firewall, network isolation,
or Skill source changes were made. The server has no exit code while running.

## F03: Application viewer adapter omitted the journal field

Business and mapping checks passed, but the first actual runtime viewer showed
an empty graph. Original browser error and screenshot are retained as
`evidence/browser-runtime-integration-errors.json` and
`screenshots/browser-runtime-integration-failure.png`.

The frozen viewer accessed `run?.journal.some` at viewer.js line 417; the project
adapter supplied no journal for its flat instance. This was a project integration
mistake. Repair: explicitly return an empty per-instance journal (no activity
history is invented), the actual instance revision, and the fixed parameter
version. Event-bound history continues to come from actual SQLite journal rows
and retained runtime frames. Also set the current selected state from SQL rows
and map the frozen viewer's program link to the real `/` page.

No frozen viewer asset was changed. The regression check now requests the real
view API and verifies its journal contract. Browser retest remains required.

## F04: Managed file hashes not sealed in the project ownership manifest

The first standalone architecture check failed because the new ownership.json
had empty managed_hashes. Raw report: `commands/35-architecture.stdout.log`.
Before sealing, independently compare every installed managed file to the
bo_upgrade metadata hash. Seal those verified files with an explicit reason,
then rerun the check and add it to the normal change_sync project checks.
This is project setup, not a change to or weakening of the architecture check.

## F05: Ordinary-call frame scope was not declared

The first candidate-2 browser recording contained all 41 real events and two
actual state-change frames. Its stored `gaps` listed 39 ordinary calls without
snapshots. Original data: `evidence/candidate2-browser-recording-original.json`.
The project adapter omitted the existing `runtime_frames.partial` scope marker.
The frozen recorder interprets omitted partial as a frame obligation for every
event. Multilanguage.md states ordinary calls need not have state snapshots.

Project-local repair: declare partial=true for this state-boundary-only frame
stream. This never fills ordinary events with later state. Revision-bearing
state changes still require their matching frame. A new negative checker fixture
removes one frame from an actual captured record and asserts that the recorder
still diagnoses the missing state snapshot. Existing assertions are preserved.
The original browser record is historical evidence and is not rewritten.

## F06: One browser login form token was rejected

During the first candidate-2 browser recording, the reviewer login POST was
rejected as Invalid form token. The exact error screenshot and UI state are
`screenshots/candidate2-login-form-token-rejection.png` and
`evidence/candidate2-login-form-token-rejection.txt`.
After following Return to obtain the current login form, the same reviewer login
succeeded and approval completed. No credential, cookie, or token was recorded.
The cause is not established; do not claim a proven fix or a clean first attempt.
The failed response remains in the original event recording.

## F07: Event snapshot omitted its selected current-state summary

The first browser record's per-entity configurations contained the actual phase,
but its machine.current was null. The project adapter now supplies the same
SQLite journal row's actual state as current; it does not read a later final
state. The exact event revision and full configuration remain unchanged.
The project regression compares each frame's current summary with its captured
instance phase. The original record is retained, and a new recording is required.

## F08: Hosted PowerShell redirection did not retain server streams

The native hosted command ran and both HTTP URLs were verified, but its
PowerShell-redirection stdout/stderr files remained empty after shutdown. A
follow-up assertion checking printed URL evidence therefore failed. Do not
claim those empty files contain startup or access logs.

Repair: `tooling/dev_logged.py` runs the unchanged normal run.py entrypoint in
the same interpreter and tees output directly in Python to durable UTF-8 files.
The actual application arguments and URL output remain those of run.py. This
is internal evidence capture; the documented user command still runs run.py
directly. Verify actual printed URLs and both endpoints on that execution.

The first patch adding this helper failed its context check; no files changed.
The next patch used the actual paragraph context and applied successfully.
