# Frozen Skill defect: Windows viewer metadata paths

The unchanged candidate installed `static\\graph/analysis.js` and similar mixed
separator keys in `bo_stategraph/runtime-version.json`. `source_inventory` uses
POSIX relative paths, so its `known.get(name)` lookup misses those managed files.
It then parses excluded viewer JavaScript, requiring a parser for a Python-only
application and reporting excluded implementation gaps.

Minimal reproduction and actual byte hashes are preserved in reproduction.json.
The full first failing scan is in review/commands/25-source-scan.stdout.log.
The defect was reported in conversation before applying the workaround.

Project-local workaround: normalize only generated metadata dictionary keys to
forward slashes. No source hash changes, frozen Skill patch, parser bypass,
or removed source checks. The complete before file and reviewable patch are here.
The metadata is subsequently included in the model's tracked source files.

This workaround does not repair the upstream installer; a later candidate upgrade
must verify its Windows path handling again.
