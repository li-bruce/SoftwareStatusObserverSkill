# Session namespace mechanism: reproduced, repaired, and bounded

The parent explicitly requested a bounded same-host/different-port interference
probe. This does not add a product feature. It is separate from diagnosing the
historical F06 reviewer-login rejection.

Before repair, real HTTP requests against two independent Flask applications on
random loopback ports produce: gallery control login successful; other application
sets its own default session; gallery's old form returns 400. Command 149 and
v2/cookie-mechanism-before.json retain that actual result without cookie or token
values. The gallery's CSRF check remains active.

The production change is one configuration field in app/web.py:create_app:
a project-specific SESSION_COOKIE_NAME. HTTP-only and SameSite settings remain.
The same real requests now succeed (command 150). Source inspection 154 and
verification 155 then correctly reject an excluded application entrypoint in the
test peer; state, business and project checks in 155 are not_run, not passed.

The regression peer was made an explicit independent WSGI test fixture that
serves a genuinely signed session from a separate Flask application. It defines
no gallery route or business feature. Its source is explicitly watched. It still
writes the foreign cookie over real HTTP and uses CookieJar's ordinary host/port
handling. Command 156 succeeds with the repaired application. Command 162 executes
the same current peer against SHA-verified pre-repair core code and reproduces
400, supporting that the fixture refactor did not remove the interference.

No cookie/header/token values are emitted or saved. Probe records contain only
paths, methods, status, final path, namespace equality, and independent row counts.
All test servers are owned by the probe and shut down with joined threads.

Rebound source, scan and inspect (157-160), full verify (161), accept (163), and
ordinary gates (164/169) pass. All original business assertions and tests remain;
the new actual-HTTP regression brings project tests from 12 to 13. Mapping is
44 witnesses / 132 projections / 18 features; business is 162/162; state and
architecture checks pass. Stable business IDs and capture schemas do not change.

The final browser repeated JPEG rejection, independent zero-row/no-message checks,
the reviewer empty inbox, PNG pending plus one message, reviewer login/approval,
and public display. Its current record has 58 contiguous events, two real state
frames and no gaps; the only HTTP error is the intentional JPEG 415. Actual replay
reaches 4/4. Final build:
389a6fb6b293dc32cfdde1f39bf71e478f4ec9af9f88b839ac539fe2cfc9db83.

Conclusion: this cookie-collision mechanism is reproduced and repaired in the
bounded test. F06's historical root cause cannot be traced from the retained
evidence because its contemporaneous cookie state was not collected. No claim
is made that this proves F06 was caused by the same mechanism. Pre-repair passing
v2 receipts, raw recordings and screenshots are preserved unchanged.
