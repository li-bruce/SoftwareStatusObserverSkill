# Frozen candidate limitations

## L01: Viewer locale migration is incomplete

No local Skill patch was made.

Reproduction: run the frozen `scripts/bo_web.py serve --root <project> --port 8841`
and open `/graph`. The copied `assets/stategraph-viewer/index.html` declares
`lang="zh-CN"` and contains fixed Chinese UI text. The actual browser state
shows Chinese controls and no explicit language selector. The current asset
inventory contains no locale catalog.

Expected by the frozen Skill: English UI fallback and an explicit language choice
(`SKILL.md`, language-policy reference). Observed in this candidate: the design
viewer still uses Chinese controls. This records the user-identified migration
boundary; it is not a claim about every future runtime surface. Original labels
and evidence are preserved. This does not establish a language-switching test.

Evidence: `evidence/design-page-final.raw.html`, `evidence/browser-state.txt`,
`screenshots/phase-01-design.png`, and the complete frozen provenance manifest.

## L02: Clarification is not implementation acceptance

The graph is a design projection with no executable states or business events.
No business correctness, state constraint, or implementation mapping pass is
claimed. Runtime capture, observer exclusion, off/failing/limited collection,
export, UI hiding, real business effects, application browser flows, and a
subsequent iteration still need verification after explicit answers arrive.
