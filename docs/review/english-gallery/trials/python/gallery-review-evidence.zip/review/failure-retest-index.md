# Failure, repair, and retest index

Historical evidence is retained verbatim. This index reports current scope without
rewriting the earlier reports. Raw command records include argv, cwd, exit code,
stdout, and stderr under commands/. Screenshots and AX snapshots are separate.

| ID | Failure | Repair / current status | Evidence and retest |
| --- | --- | --- | --- |
| D01 | Candidate-1 Windows metadata path keys | Public candidate 2 fixed | skill-defects.md; 62-65; 102/107 C3 independent hashes |
| D02 | Candidate-1 chained-call question ID collisions | Public candidate 2 fixed; old answers rejected | 66; original/regenerated reconciliation; 103/105 current 81 answers |
| D03 | Optional machine.labels causes viewer failure | Public candidate 3 fallback verified | candidate3-optional-labels-fixture.json and browser TXT/PNG; explicit derived display fixture |
| D04 | Public focus fails on project envelope | Public candidate 2 fixed; compatibility helper archived | 71/77; 112 current public focus |
| G01 | Initial conversation lacked inline diagram | Same stable network added, no fabricated confirmation | confirmed-network.mmd; phase reports and public preview 77 |
| D05 | pending business state displayed as generic activity Not started | Public candidate 3 context-aware display verified | candidate2-pending-label-defect TXT/PNG; candidate3-pending-en/zh and review-en TXT/PNG |
| F01 | Interpreter/ensurepip Temp failures | Workspace TMP/TEMP and venv | failures.md; commands 01/01b/01c; subsequent gates |
| F02 | Early server lifecycle/reachability failures | Hosted foreground server verified; exact early cause unresolved | failures.md original startup evidence; 111 actual startup plus both HTTP200 |
| F03 | Adapter omitted journal | Empty journal plus actual revisions returned | original failure screenshot/log; 106 tests; current browser |
| F04 | Ownership managed hashes absent | Independently verified explicit seal; check retained | 35/36; 101/102/107; 106 architecture |
| F05 | Ordinary calls diagnosed as missing frames | partial=true; missing actual state frame still rejected | original 41-event record; negative checker fixture; 106 test; final 37-event record has no gaps |
| F06 | One initial reviewer login token rejection | Retry succeeded; cause unresolved, no claimed fix | original screenshot/AX/record; clean final C2 and C3 browser flows |
| F07 | Frame current summary null | Same transactional row supplies phase and current | original record; 106 exact-frame tests; final 2 frames and independent SQL |
| F08 | Hosted PowerShell redirection files empty | Python tee retains actual main-server output | original empty logs and failed assertion retained; 88/111 tee logs |
| U01 | First candidate-2 frozen-copy sandbox denial | Authorized escalation installed new independent copy | commands 61-64; no security settings changed |
| C301 | Strict whole preferences object comparison failed | Revision 30 to 31; all entries exactly equal | before-upgrade vs candidate3-preferences-before-browser; current upgrade report |
| C302 | Initial textual diff included false newline differences | Compare decoded original bytes on both sides | helper patch; 102 vs 107; final diff contains only four files |
| S01 | Exploratory PowerShell rg wildcard path/missing receipt filenames | Use directory glob or actual inventory | Tool transcript; no project/business gate affected |
| S02 | CIM process inspection denied by environment | No retry or permission weakening required | Tool transcript; known owned server sessions used |

Candidate-3 commands 95-116 retain passing precheck, change workflow, independent
hash checks, full verify, accept/check, core export/challenges, and actual collection.
Candidate-2 upgrade record's earlier pending paragraph is historical; its final
status was partial on D05. Candidate-3 final scope supersedes it as described in
candidate-3-upgrade.md, while candidate-1/2 checkpoints remain immutable evidence.
