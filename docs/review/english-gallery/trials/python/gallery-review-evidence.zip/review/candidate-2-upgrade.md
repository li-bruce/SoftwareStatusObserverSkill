# Candidate 2 upgrade record

This upgrade is explicitly authorized by the parent task. Candidate 2 is a trial
candidate, not presumed fully accepted. Candidate 1's 142-file installation,
all failures, original simulated dialogue, accepted source ZIP, and gate evidence
remain preserved. Its compatibility scripts are archived under
`review/candidate-1-checkpoint/compatibility-scripts/` and removed from active tooling.

Candidate 2 is independently installed at
`.agents/skills/business-observer-candidate-2`. All 144 files match both the
provided manifest and source SHA256. The first install attempt failed because
the sandbox protected `.agents`; the authorized copy was retried through normal
escalation. This was an environment permission failure, not a candidate defect.
Commands 61-64 preserve the failure, missing-file follow-up, and successful retry.

The ordinary candidate-1 gate passed immediately before upgrade (command 59).
`change_sync begin` saved `.stategraph/candidate-2-upgrade/baseline.json` (command 60).
The public candidate-2 upgrade plan and apply changed 25 managed files with no
conflicts (commands 64-65). The original assertions and probe modes are retained.

The new public inspect rejected old coding answers (command 66), including
chained-call IDs newly disambiguated by expression fingerprints. These old answers
were not silently accepted; candidate-1 records remain in the checkpoint. The
project coding reconciler no longer groups duplicate IDs and now verifies public
question identities are unique. It produced 81 separate current answers.

The new development launcher binds one local HTTP server, prints its actual
business and graph URLs, and owns only that server and its own observation
threads. Observation startup failure falls back to business-only operation.
Malformed observation Web configuration is isolated from business responses.
New regression tests cover both failures while retaining existing checks.

Candidate-1 isolated exported/mutated source copies were moved into
`work/.validation/` after their execution. Their original logs retain the paths
where they actually ran. They are retained test artifacts rather than application
implementation in the current source inventory. The restored normal gate passed.

Language-switch, note/layout retention, real recorded business operation, replay,
new public focus/preview commands, and the full gate are pending until their
actual results are appended. No claim here substitutes for those results.
