"""Trial-local reader compatibility for the frozen BODesign focus command."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from observer_runtime.bo_observer.web import bo_design
from observer_runtime.bo_observer.model_io import read_model

# The frozen function uses one JSON reader for both plain records and envelopes.
# Limit the compatibility injection to this command process, not the app or Skill.
bo_design.read=read_model
raise SystemExit(bo_design.main())
