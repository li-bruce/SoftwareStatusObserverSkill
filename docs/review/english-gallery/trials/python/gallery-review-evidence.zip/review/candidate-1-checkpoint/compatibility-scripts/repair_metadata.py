"""Reviewable Windows metadata workaround; never modify the frozen candidate."""
import difflib
import hashlib
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
path=root/"bo_stategraph/runtime-version.json"
before=path.read_text(encoding="utf-8")
doc=json.loads(before)
files=doc["files"]
name="static/graph/analysis.js"
matching=[key for key in files if key.replace("\\","/")==name]
proof={"lookup_path":name,"original_exact_lookup":files.get(name),"matching_original_keys":matching,
    "actual_sha256":hashlib.sha256((root/name).read_bytes()).hexdigest(),
    "hash_at_original_key":files[matching[0]],"diagnostic":"Unmodified installed asset is not recognized because installer metadata keys contain backslashes."}
assert proof["original_exact_lookup"] is None
assert proof["actual_sha256"]==proof["hash_at_original_key"]
folder=root/"review/defects/windows-viewer-paths"
folder.mkdir(parents=True,exist_ok=True)
(folder/"reproduction.json").write_text(json.dumps(proof,indent=2),encoding="utf-8")
(folder/"runtime-version.before.json").write_text(before,encoding="utf-8")
doc["files"]={key.replace("\\","/"):value for key,value in files.items()}
after=json.dumps(doc,ensure_ascii=False,indent=2)+"\n"
path.write_text(after,encoding="utf-8")
(folder/"metadata.patch").write_text("".join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile="runtime-version.before.json",tofile="runtime-version.json")),encoding="utf-8")
print(json.dumps(proof))
