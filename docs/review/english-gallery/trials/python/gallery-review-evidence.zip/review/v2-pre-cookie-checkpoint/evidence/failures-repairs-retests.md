# v2 failures, repairs, and retests

## V201: Deliberate pre-implementation requirement counterexample

Command 122 executed the v2 JPEG expectation against the still-v1 implementation.
It failed with exit 1: expected images 0, actual 1. This demonstrates the requested
behavior change; it is not a defect in v1's confirmed PNG/JPEG contract. Command
123 passed after the actual decoder policy and drive guard changed. After the
coverage repair, command 138 verifies the independently named JPEG-only scenario
with zero images/messages and status 415.

## V202: Protected reviewer fixture coverage

Inspect command 127 returned exit 1 with review_errors.weakened_feature_coverage
for review/cases/reject_jpeg/commit. Existing v1 feature records lack explicit
feature-level requirements, so the recorded requirement-change allowance does
not waive this immutable coverage obligation. No frozen checker was changed.

Repair: preserve legacy case ID reject_jpeg and all 45 original assertions
exactly; its valid upload fixture is PNG in v2. Add jpeg_upload_denied for actual
JPEG rejection and jpeg_spoof_png for JPEG bytes with a PNG filename. Nine
independent assertions are added. This is explicitly documented fixture migration,
not evidence of a JPEG image being reviewed in v2. Initial planned expectations
and acceptance are retained as initial-*-before-coverage-repair.json. The original
v1 expectations remain unchanged. Inspect 131 and final inspect 135 pass;
full verify 136, accept 139, and ordinary gate 140 pass.

## V203: UI automation selector mismatch and intermediate snapshots

The browser wait for exact DOM text valid: timed out with no matches even though
the accessibility tree subsequently showed valid: false and actual JPEG content.
The field is split among presentation elements. Fresh AX inspection resolved
the test locator issue; no application or Skill repair was made. Confirmed
evidence is replay-JPEG-decision-confirmed.txt and the matching confirmed PNG.
The earlier replay-JPEG-decision snapshot/screenshot represents an intermediate
initial frame and is retained, not used as proof of the JPEG decision. The first
JPEG upload AX snapshot similarly preceded navigation; browser-jpeg-rejected-final
and the actual rejection screenshot are the settled evidence.

## V204: Read-thread argument limits

The first read_thread request used turnLimit 20 and maxOutputCharsPerItem 24000;
the tool rejected those arguments (limits 10 and 20000). A corrected read succeeded.
Only actual user-facing messages and exact targeted delegation prompts are
exported. Private reasoning and unrelated conversations are excluded. The tool
does not provide user messages inside child turn.items; this limitation is stated
instead of reconstructing absent dialogue. The original instruction/answer files
and parent delegation tool export supply those primary records separately.

## Final retests

Four reports pass: mapping 44 witnesses / 132 projection checks / 18 features;
state constraints; business 162/162 assertions; project 12 tests plus architecture.
The actual browser record has 58 contiguous events, two matching state frames,
and no gaps. The only HTTP error is the requested JPEG upload rejection (415).
Independent SQL before PNG: images/messages/journal all zero. After PNG approval:
one PNG published at revision 2, one reviewer message, two journal boundaries.
Browser playback actually reached the last of four state-view steps.

Core export and source-drift/mutation challenges pass in command 146. Original
v1 failures and their unresolved diagnoses remain in the prior failure index;
none is silently reclassified as a new fix. In particular the old isolated form
token rejection cause remains unknown and did not recur in this final v2 flow.
