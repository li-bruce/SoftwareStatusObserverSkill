# Business network draft

```mermaid
flowchart LR
  n0["公开画展：仅展示通过图片"]
  n1["解码实际内容：仅接受 PNG"]
  n2["拒绝 JPEG 与非 PNG：无待审项、无消息"]
  n3["预置两种账号登录与权限"]
  n4["合格上传生成审核者站内消息"]
  n5["待审核"]
  n6["已通过并公开展示"]
  n7["已驳回：不公开展示"]
  n8["审核者通过 / 驳回"]
  n9["前端上传文件"]
  n1 -->|"仅内容检查通过后通知"| n4
  n3 -->|"审核者权限"| n8
  n3 -->|"上传者权限"| n9
  n8 -->|"审核决定是否展示"| n0
  n1 -->|"实际内容不符合"| n2
  n4 -->|"收到上传消息后审核"| n8
  n8 -->|"通过"| n6
  n8 -->|"驳回"| n7
  n9 -->|"对上传文件判断"| n1
  n1 -->|"实际内容符合"| n5
```

[Open the live graph](http://127.0.0.1:8842/graph)

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
