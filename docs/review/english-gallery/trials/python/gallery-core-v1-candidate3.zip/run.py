"""Run the independent gallery on a local interface."""
import argparse
from pathlib import Path
import sys
from app.service import Gallery
from app.web import create_app
from werkzeug.serving import make_server

def build_application(root, database, observe=True):
    database.parent.mkdir(parents=True, exist_ok=True)
    service = Gallery(database, root / "bo_stategraph/project.json")
    app = create_app(service)
    adapter = None
    if observe:
        try:
            from integrations.bo_adapter import BOAdapter
            from integrations.bo_web import bo_attach
            adapter = BOAdapter(root, database)
            adapter.graph.bo_require_definition(service.machine.definition)
            bo_attach(app, adapter, root)
            service.bo, service.build_id = adapter.port, adapter.build_id
        except Exception as error:
            if adapter is not None: adapter.bo_close()
            adapter = None
            print(f"Observer unavailable; business remains available: {type(error).__name__}: {error}", file=sys.stderr, flush=True)
    return app, service, adapter

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8842)
    parser.add_argument("--core", action="store_true")
    parser.add_argument("--database", default="work/gallery.sqlite")
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    app, service, adapter = build_application(root, root / args.database, not args.core)
    server = make_server("127.0.0.1", args.port, app, threaded=True)
    print(f"Gallery URL: http://127.0.0.1:{server.server_port}/", flush=True)
    print(f"Graph URL: http://127.0.0.1:{server.server_port}/graph" if adapter else "Graph URL: unavailable (business-only mode)", flush=True)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        server.server_close()
        if adapter is not None: adapter.bo_close()

if __name__ == "__main__": main()
