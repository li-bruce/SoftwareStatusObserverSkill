"""Application executor for the explicitly supported flat declaration subset."""
from copy import deepcopy
import json
from pathlib import Path
from .bo_contracts import validate_runtime_definition, value_errors

class GalleryMachine:
    def __init__(self, path):
        document = json.loads(Path(path).read_text(encoding="utf-8"))
        self.definition = deepcopy(document["model"]["machine"])
        self.guards = {"uploader": self.is_uploader, "reviewer": self.is_reviewer,
                       "content": self.valid_content}
        validate_runtime_definition(self.definition, loaded_engine="bo.fsm", loaded_version="1", guard_names=self.guards)

    def is_uploader(self, context: dict, payload: dict) -> bool:
        return payload["role"] == "uploader"

    def is_reviewer(self, context: dict, payload: dict) -> bool:
        return payload["role"] == "reviewer"

    def valid_content(self, context: dict, payload: dict) -> bool:
        return context["format"] in {"PNG", "JPEG"}

    def transition(self, state: str, event: str, context: dict, payload: dict) -> dict:
        machine = self.definition
        if state not in machine["states"] or event not in machine["events"]:
            raise ValueError("Unknown state or event")
        if set(context) != set(machine["context"]) or set(payload) != set(machine["events"][event]["payload"]):
            raise ValueError("Context or payload fields differ from declaration")
        for name, spec in machine["context"].items():
            if value_errors(context[name], spec, name): raise ValueError("Invalid context value")
        for name, spec in machine["events"][event]["payload"].items():
            if value_errors(payload[name], spec, name): raise ValueError("Invalid event payload")
        evaluated = {}
        for item in machine["transitions"]:
            if item["source"] != state or item["trigger"] != event: continue
            allowed = True
            for guard in item.get("conditions", []):
                evaluated[guard] = self.guards[guard](context, payload)
                if not evaluated[guard]:
                    allowed = False
                    break
            if allowed:
                return {"before": state, "state": item["dest"], "event": event, "guards": evaluated}
        raise ValueError("No enabled transition")
