"""Server-rendered business pages and form actions."""
from io import BytesIO
import secrets
from flask import Blueprint, Flask, current_app, redirect, render_template, request, send_file, session
from .service import DomainError

routes = Blueprint("business", __name__)

def gallery_service():
    return current_app.config["GALLERY"]

def respond(node: str, response, inputs=None):
    result = current_app.make_response(response)
    gallery_service().bo.record(node, "response", inputs or {}, {"status": result.status_code})
    return result

def page_context():
    return {"actor": session.get("actor", ""), "role": session.get("role", ""), "csrf": session.setdefault("csrf", secrets.token_hex(24)), "bo_enabled": bool(current_app.config.get("BO_ENABLED",False))}

def verify_form():
    if request.method == "POST" and request.form.get("csrf") != session.get("csrf"):
        raise DomainError(400, "Invalid form token")

@routes.get("/")
def exhibition_page():
    return respond("http_exhibition", render_template("gallery.html", images=gallery_service().exhibition(), **page_context()))

@routes.get("/login")
def login_page():
    return respond("http_login_page", render_template("login.html", **page_context()))

@routes.post("/login")
def login_action():
    verify_form()
    identity = gallery_service().login(request.form.get("username", ""), request.form.get("password", ""))
    session.clear()
    session.update(actor=identity["username"], role=identity["role"], csrf=secrets.token_hex(24))
    return respond("http_login", redirect("/upload" if identity["role"] == "uploader" else "/messages"))

@routes.post("/logout")
def logout_action():
    verify_form()
    session.clear()
    return respond("http_logout", redirect("/"))

@routes.get("/upload")
def upload_page():
    gallery_service().authorize(session.get("actor", ""), "uploader")
    return respond("http_upload_page", render_template("upload.html", saved=request.args.get("saved"), **page_context()))

@routes.post("/upload")
def upload_action():
    verify_form()
    file = request.files.get("file")
    if file is None: raise DomainError(400, "Choose a file")
    result = gallery_service().upload(session.get("actor", ""), file.filename or "Untitled", file.read())
    return respond("http_upload", redirect("/upload?saved=" + result["id"]))

@routes.get("/messages")
def messages_page():
    rows = gallery_service().messages(session.get("actor", ""))
    return respond("http_messages", render_template("messages.html", messages=rows, **page_context()))

@routes.post("/review/<image_id>")
def review_action(image_id: str):
    verify_form()
    gallery_service().review(session.get("actor", ""), image_id, request.form.get("decision", ""))
    return respond("http_review", redirect("/messages"), {"image_id": image_id})

@routes.get("/image/<image_id>")
def image_content(image_id: str):
    body, mime = gallery_service().image(image_id, session.get("actor", ""))
    result = send_file(BytesIO(body), mimetype=mime, max_age=0)
    result.headers["Cache-Control"] = "no-store"
    return respond("http_image", result, {"image_id": image_id})

def domain_error(error):
    node = {"business.login_action": "http_login", "business.upload_action": "http_upload", "business.review_action": "http_review", "business.messages_page": "http_messages", "business.image_content": "http_image", "business.upload_page": "http_upload_page"}.get(request.endpoint, "http_login")
    inputs = {"image_id": request.view_args["image_id"]} if request.view_args and "image_id" in request.view_args else {}
    return respond(node, (render_template("error.html", message=str(error), **page_context()), error.status), inputs)

def create_app(service):
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.secret_key = secrets.token_hex(32)
    app.config.update(GALLERY=service, MAX_CONTENT_LENGTH=16 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")
    app.register_blueprint(routes)
    app.register_error_handler(DomainError, domain_error)
    return app
