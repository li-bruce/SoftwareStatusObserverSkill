"""Neutral, failure-isolated observation port; business has no collector dependency."""
class BOPort:
    def __init__(self, handler=None):
        self.handler = handler
        self.errors = 0

    def record(self, node, phase, inputs, outputs, entity="application", depends=()):
        if self.handler is None:
            return None
        try:
            return self.handler(node, phase, inputs, outputs, entity, depends)
        except Exception:
            self.errors += 1
            return None
