"""Gallery application package."""
