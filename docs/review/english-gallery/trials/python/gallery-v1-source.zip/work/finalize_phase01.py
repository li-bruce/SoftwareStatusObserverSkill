"""Save phase results without claiming application acceptance."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
from urllib.request import urlopen
from zipfile import ZipFile, ZIP_DEFLATED

root = Path(__file__).resolve().parents[1]
review = root / "review"
evidence = review / "evidence"
base = "http://127.0.0.1:8841"
responses = []
for endpoint, filename in [("/api/view", "design-view-final.raw.json"),
                           ("/api/design", "design-focus-final.raw.json"),
                           ("/graph", "design-page-final.raw.html")]:
    with urlopen(base + endpoint, timeout=5) as response:
        raw = response.read()
        status = response.status
    (evidence / filename).write_bytes(raw)
    responses.append({"url": base + endpoint, "status": status,
                      "body_sha256": hashlib.sha256(raw).hexdigest()})
view = json.loads((evidence / "design-view-final.raw.json").read_bytes())
assert view["stage"] == "design" and len(view["events"]) == 0
assert len(view["model"]["nodes"]) == 5 and len(view["model"]["edges"]) == 4
focus = json.loads((evidence / "design-focus-final.raw.json").read_bytes())
assert focus["stale"] is False
provenance = json.loads((review / "skill-provenance.json").read_text(encoding="utf-8"))
mismatches = []
for item in provenance["files"]:
    installed = root / ".agents/skills/business-observer" / item["path"]
    digest = hashlib.sha256(installed.read_bytes()).hexdigest()
    if digest != item["source_sha256"]:
        mismatches.append(item["path"])
assert not mismatches
assessment = {"phase": "01_clarification", "project_root": str(root),
    "timestamp_utc": datetime.now(timezone.utc).isoformat(), "graph_url": base + "/graph",
    "skill_files_verified": len(provenance["files"]), "modified_skill_files": mismatches,
    "skill_inventory_sha256": provenance["inventory_sha256"], "http_responses": responses,
    "browser": {"result": "rendered", "observed_nodes": 5, "observed_relations": 4,
        "screenshot": "review/screenshots/phase-01-design.png", "console_check": "not collected in this phase"},
    "checks": {
        "implementation_mapping": {"status": "not_run", "reason": "No application implementation exists."},
        "state_constraints": {"status": "not_run", "reason": "No executable state machine before explicit mode and business answers."},
        "business_rules": {"status": "pending_answers", "blocking": ["D_mode", "D_image", "D_identity"], "discovery_check_exit": 1, "expected": True},
        "project_checks": {"status": "preparation_only", "copy_hashes": "pass", "pip_check": "pass", "discovery_validate": "pass", "focus_current": "pass", "http_design": "pass", "browser_design": "pass", "application_tests": "not_run"}},
    "application_implemented": False, "business_events": 0, "simulated_user_answers": [],
    "next_action": "Wait for explicit simulated-user answers in this conversation. Do not implement or choose defaults."}
(evidence / "phase-01-assessment.json").write_text(json.dumps(assessment, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

server_record = {"argv": [r"C:\Users\Lvi_P\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe", "-B", str(root / ".agents/skills/business-observer/scripts/bo_web.py"), "serve", "--root", str(root), "--port", "8841"], "cwd": str(root), "execution": "foreground hosted exec session", "session_id": 90709, "exit_code": None, "status": "running and browser verified", "url": base + "/graph", "startup_stdout": "Design graph: http://127.0.0.1:8841/graph\n"}
(review / "commands/09d-design-server.json").write_text(json.dumps(server_record, indent=2), encoding="utf-8")
report = f"""# Gallery trial: clarification checkpoint

Project: `{root}`.

Frozen skill source: `{provenance['source']}`.
Installed project-local copy: `{provenance['installed']}`.
All {len(provenance['files'])} source files match SHA256 after design launch.
Inventory SHA256: `{provenance['inventory_sha256']}`.

The installed dependency is jsonschema==4.25.1, with resolved transitive
dependencies preserved in the raw pip freeze evidence. Pip check passed.
The frozen Skill has not been patched. No existing application was copied.

Graph: {base}/graph. The actual frozen viewer rendered five design nodes and
four relationships, with a visible declaration-only status and zero business
events. Node IDs and layout ID are reserved for the later implementation.
The identity enforcement, image decision and invalid-file branch, notification
timing, and execution mode remain unresolved. No executable state values have
been invented. No application authentication or other business has been built.

| Area | Result |
| --- | --- |
| Implementation mapping | Not run: no application implementation yet. |
| State constraints | Not run: executable model awaits explicit answers. |
| Business rules | Pending: three blocking decisions; discovery check correctly exits 1. |
| Project checks | Preparation passed: source hashes, dependency check, draft validation, current focus, HTTP and real browser rendering. Application checks remain unrun. |

The exact original request, questions, empty answer list, decision records,
commands and exit codes, failures, repairs, raw HTTP bodies, and actual screenshot
are retained under review/. This is an independent AI trial with simulated-user
answers expected; it is not a human usability study. No GitHub submission was made.

The initial background and sandbox-hosted launch attempts did not establish a
usable cross-tool service. The successful graph uses the bundled interpreter in
a foreground hosted session, limited to 127.0.0.1:8841. The URL depends on that
session remaining active; the screenshot remains a durable checkpoint.

See review/limitations.md for the frozen viewer's locale migration limitation.
Next: wait for the three explicit answers in review/questions.zh-CN.txt, then
update the same graph. Implementation, runtime acceptance, and one subsequent
iteration remain future phases, as requested.
"""
(review / "phase-01-report.md").write_text(report, encoding="utf-8")
(root / "outputs/phase-01-report.md").write_text(report, encoding="utf-8")
with ZipFile(root / "outputs/phase-01-review.zip", "w", ZIP_DEFLATED) as archive:
    for path in sorted(review.rglob("*")):
        if path.is_file():
            archive.write(path, path.relative_to(root).as_posix())
    for relative in ["discovery.json", "AGENTS.md", "work/prepare_trial.py", "work/start_design.py", "work/finalize_phase01.py"]:
        archive.write(root / relative, relative)
print(json.dumps({"result": "awaiting_answers", "graph": base + "/graph", "skill_files_matched": len(provenance["files"]), "business_events": len(view["events"])}))
