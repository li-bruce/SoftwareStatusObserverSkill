"""Run the independent gallery on a local interface."""
import argparse
from pathlib import Path
from app.service import Gallery
from app.web import create_app

parser = argparse.ArgumentParser()
parser.add_argument("--port", type=int, default=8842)
parser.add_argument("--core", action="store_true")
parser.add_argument("--database", default="work/gallery.sqlite")
args = parser.parse_args()
root = Path(__file__).resolve().parent
database = root / args.database
database.parent.mkdir(parents=True, exist_ok=True)
if args.core:
    service = Gallery(database, root / "bo_stategraph/project.json")
    app = create_app(service)
else:
    from integrations.bo_adapter import BOAdapter
    from integrations.bo_web import bo_attach
    adapter = BOAdapter(root, database)
    service = Gallery(database, root / "bo_stategraph/project.json", adapter.port, adapter.build_id)
    adapter.graph.bo_require_definition(service.machine.definition)
    app = create_app(service)
    bo_attach(app, adapter, root)
app.run(host="127.0.0.1", port=args.port, debug=False, threaded=True, use_reloader=False)
