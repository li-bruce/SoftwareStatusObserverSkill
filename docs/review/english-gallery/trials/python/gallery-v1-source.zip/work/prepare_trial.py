"""Prepare the frozen trial, retaining provenance and unmodified command evidence."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(r"C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/gallery-trials/candidate-1/business-observer")
SKILL = ROOT / ".agents/skills/business-observer"
REVIEW = ROOT / "review"
(ROOT / "work/tmp").mkdir(parents=True, exist_ok=True)
os.environ.update({"TMP": str(ROOT / "work/tmp"), "TEMP": str(ROOT / "work/tmp"),
                   "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"})

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def run(name, arguments, expected=0):
    result = subprocess.run(arguments, cwd=ROOT, capture_output=True)
    prefix = REVIEW / "commands" / name
    prefix.with_suffix(".stdout.log").write_bytes(result.stdout)
    prefix.with_suffix(".stderr.log").write_bytes(result.stderr)
    record = {"timestamp_utc": datetime.now(timezone.utc).isoformat(), "cwd": str(ROOT),
              "argv": [str(v) for v in arguments], "exit_code": result.returncode,
              "expected_exit_code": expected}
    write_json(prefix.with_suffix(".json"), record)
    print(json.dumps(record), flush=True)
    if result.returncode != expected:
        raise RuntimeError(f"Unexpected exit code: {name}; inspect saved raw logs")
    return result

request = """这是用户明确授权的新会话独立试用，测试本地 business-observer 多语言 Skill。主体应用使用 Python；观测公共服务使用 Skill 的 Python 实现。项目在本会话独立目录中创建，不修改主仓库或另一试用项目，不提交 GitHub。

先读取并完整安装冻结 Skill：C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/gallery-trials/candidate-1/business-observer/SKILL.md。仅以这个冻结副本为被测版本，不使用旧的全局安装，也不把主仓库现有应用当成新项目复制。复制整个 Skill（含 references、scripts、assets、依赖清单），记录其来源与 SHA256。维护中的代码、注释和标识符使用英文；与模拟需求方用中文对话。当前候选的界面本地化仍在迁移，若发现局限请如实记录。

原始需求：『我要创建一个工程，一个人可以通过前端上传文件，审核是否为图片，另一个人可以收到上传的消息，审核是否在展览页展示这个图片，展览页是一个简单的画展 web。』

这是完整开发试用：必要澄清→确认图→实现与同步→真实程序和图的运行验收→一次后续迭代。现在先按 Skill 提出会改变业务理解或执行模式的必要问题，形成待确认的局部图，然后暂停等待本会话回复，不要自行替用户选择。不要扩大业务或推荐附加功能。后续回答会明确标注为模拟用户回答；不是人类易用性测试。

全过程在项目 review/ 下记录用户原话、问题、回答、决定、命令、退出码、失败、修复、复测、原始运行证据和浏览器截图；每个阶段都报告绝对项目路径。业务正确、状态约束、实现映射和项目检查分别报告，必须保留原有检查。所有已实现业务都进入图和采集，包括若实际开发的身份认证、上传、图片判断、消息、审批和展览查询；排除观察器自身事件。不要伪造事件、用模型自证效果或因为集成困难删掉检查。若遇到 Skill 缺陷，记录最小复现并先报告，修复只在本试用目录可审查地进行。"""
(REVIEW / "request.original.txt").write_text(request + "\n", encoding="utf-8")

manifest = []
source_files = sorted(p for p in SOURCE.rglob("*") if p.is_file())
for path in source_files:
    relative = path.relative_to(SOURCE)
    target = SKILL / relative
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    copied_digest = hashlib.sha256(target.read_bytes()).hexdigest() if target.is_file() else None
    manifest.append({"path": relative.as_posix(), "bytes": path.stat().st_size,
                     "source_sha256": digest, "installed_sha256": copied_digest,
                     "matches": digest == copied_digest})
source_set = {p.relative_to(SOURCE).as_posix() for p in source_files}
target_set = {p.relative_to(SKILL).as_posix() for p in SKILL.rglob("*") if p.is_file()}
inventory_digest = hashlib.sha256("".join(f"{item['path']}\0{item['source_sha256']}\n" for item in manifest).encode()).hexdigest()
write_json(REVIEW / "skill-provenance.json", {
    "source": str(SOURCE), "installed": str(SKILL), "file_count": len(manifest),
    "inventory_sha256": inventory_digest,
    "inventory_hash_definition": "SHA256 of sorted relative POSIX path + NUL + file SHA256 + LF, encoded UTF-8",
    "extra_installed_files": sorted(target_set - source_set), "files": manifest})
assert all(item["matches"] for item in manifest) and source_set == target_set
print(f"Frozen skill: {len(manifest)} files matched; inventory SHA256 {inventory_digest}", flush=True)

questions = [
    ("D_mode", "scope", "开发执行模式", "选择 drive（业务从状态声明执行），还是 observe（业务自行执行，图读取实际状态作观测）？两者都维护图和监控。", "首次接入必须明确执行模式；答案决定实际执行器与状态声明的关系。", ["upload", "image_check", "message", "review", "exhibition"]),
    ("D_image", "completion", "图片判断与通知顺序", "“审核是否为图片”由程序自动检查，还是由人判断？如果不是图片，应直接拒绝，还是也通知另一人审核？", "答案决定判断者、非图片路径，以及图片判断和上传通知之间的关系。", ["image_check", "message", "upload_check", "check_message"]),
    ("D_identity", "authority", "两位参与者的身份", "“一个人”和“另一个人”需要登录后区分身份并限制上传/审核权限，还是本次仅用固定的上传入口和审核入口，不做身份认证？", "答案决定是否实际实现身份认证，以及另一人的审核权限如何成立。", ["upload", "message", "review"]),
]
write_json(ROOT / "discovery.json", {
    "schema": "business-discovery/v1", "project_id": "gallery-python-trial", "layout_id": "gallery-python-trial",
    "title": "画展上传与审核 · 待确认设计", "goal": "Create a simple gallery web with upload, image checking, upload notification, and a second person's display review.",
    "sources": [
        {"id": "U_original", "kind": "user", "text": "我要创建一个工程，一个人可以通过前端上传文件，审核是否为图片，另一个人可以收到上传的消息，审核是否在展览页展示这个图片，展览页是一个简单的画展 web。", "locator": "review/request.original.txt; original requirement quoted in delegated request; not a simulated answer"},
        {"id": "P_mode", "kind": "project_rule", "text": "At first adoption, ask whether the project uses drive or observe. Until answered, continue only mode-independent preparation.", "locator": ".agents/skills/business-observer/SKILL.md section 1"},
        {"id": "A_pending", "kind": "inference", "text": "Image checker, non-image handling, notification timing, actor identity enforcement, and execution mode remain unconfirmed. Arrows express a discussion draft, not an executable state machine.", "locator": "review/dialogue.json phase 01"},
        {"id": "A_questions", "kind": "assistant", "text": "\n".join(f"{i + 1}. {q[3]}" for i, q in enumerate(questions)), "locator": "review/questions.zh-CN.txt; assistant clarification round 1; awaiting simulated answers"}
    ],
    "networks": [{"id": "gallery_flow", "title": "上传、消息、审核与展览", "actors": ["上传者（身份待确认）", "另一位审核人（身份待确认）"],
        "trigger": "一个人通过前端上传文件", "outcome": "另一人审核图片是否在简单画展页展示；待确认分支仍保持未知",
        "nodes": [
            {"id": "upload", "label": "前端上传文件", "kind": "action", "source_refs": ["U_original"], "summary": "Uploader identity enforcement is unresolved."},
            {"id": "image_check", "label": "判断是否为图片 · 判断者待定", "kind": "condition", "source_refs": ["U_original", "A_pending"]},
            {"id": "message", "label": "另一人收到上传消息 · 时机待定", "kind": "effect", "source_refs": ["U_original", "A_pending"]},
            {"id": "review", "label": "另一人审核是否展示", "kind": "action", "source_refs": ["U_original"]},
            {"id": "exhibition", "label": "简单画展页展示图片", "kind": "action", "source_refs": ["U_original"]}
        ], "edges": [
            {"id": "upload_check", "from": "upload", "to": "image_check", "relation": "flow", "label": "对上传文件判断", "source_refs": ["U_original"]},
            {"id": "check_message", "from": "image_check", "to": "message", "relation": "data", "label": "通知是否只发图片通过项？待确认", "source_refs": ["A_pending"], "decision_refs": ["D_image"]},
            {"id": "message_review", "from": "message", "to": "review", "relation": "flow", "label": "收到上传消息后审核", "source_refs": ["U_original"]},
            {"id": "review_exhibition", "from": "review", "to": "exhibition", "relation": "guard", "label": "审核决定是否展示", "source_refs": ["U_original"]}
        ]}],
    "decisions": [{"id": ident, "topic": topic, "title": title, "question": question, "why": why,
        "affects": affects, "blocking": True, "status": "open", "priority": 1,
        "source_refs": ["P_mode"] if ident == "D_mode" else ["U_original"], "asked_in": ["A_questions"]}
        for ident, topic, title, question, why, affects in questions], "changes": []})
(REVIEW / "questions.zh-CN.txt").write_text("\n\n".join(f"{i+1}. {q[3]}" for i,q in enumerate(questions)) + "\n", encoding="utf-8")
write_json(REVIEW / "dialogue.json", {"trial_kind": "independent AI development trial with pending simulated-user answers; not a human usability study", "phase": "01_clarification", "request": "request.original.txt", "questions": "questions.zh-CN.txt", "answers": [], "decisions": "../discovery.json", "status": "awaiting_explicit_answers", "implementation_started": False})

venv_python = ROOT / "work/runtime-venv/Scripts/python.exe"
if not venv_python.exists():
    run("01b-create-runtime-venv", [sys.executable, "-m", "venv", str(ROOT / "work/runtime-venv")])
run("01c-ensurepip-workspace-temp", [str(venv_python), "-m", "ensurepip", "--upgrade", "--default-pip"])
run("02-install-frozen-requirements", [str(venv_python), "-m", "pip", "install", "-r", str(SKILL / "requirements.txt")])
run("03-dependency-check", [str(venv_python), "-m", "pip", "check"])
run("04-dependency-freeze", [str(venv_python), "-m", "pip", "freeze"])
for name, action, expected in [("05-discovery-validate", "validate", 0), ("06-discovery-questions", "questions", 0), ("07-discovery-check", "check", 1)]:
    run(name, [str(venv_python), str(SKILL / "scripts/requirements_dialogue.py"), action, "--file", str(ROOT / "discovery.json")], expected)
run("08-focus-current-discussion", [str(venv_python), str(SKILL / "scripts/bo_design.py"), "focus", "--root", str(ROOT), "--nodes", "upload", "image_check", "message", "review", "exhibition", "--label", "待确认：执行模式、图片判断及通知分支、两位参与者身份；尚未实现业务。"])
