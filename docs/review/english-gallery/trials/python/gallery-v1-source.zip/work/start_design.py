"""Launch the frozen design viewer and retain process and HTTP evidence."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import time
from urllib.request import urlopen

root = Path(__file__).resolve().parents[1]
review = root / "review"
python = root / "work/runtime-venv/Scripts/python.exe"
argv = [str(python), str(root / ".agents/skills/business-observer/scripts/bo_web.py"),
        "serve", "--root", str(root), "--port", "8840"]
env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1",
           TMP=str(root / "work/tmp"), TEMP=str(root / "work/tmp"))
with (review / "commands/09-design-server.stdout.log").open("wb") as stdout, \
     (review / "commands/09-design-server.stderr.log").open("wb") as stderr:
    process = subprocess.Popen(argv, cwd=root, env=env, stdout=stdout, stderr=stderr,
                               creationflags=subprocess.CREATE_NO_WINDOW)
record = {"timestamp_utc": datetime.now(timezone.utc).isoformat(), "cwd": str(root),
          "argv": argv, "pid": process.pid, "exit_code": None, "status": "running",
          "note": "A running process alone is not delivery evidence; HTTP responses follow."}
(review / "commands/09-design-server.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
for attempt in range(30):
    try:
        with urlopen("http://127.0.0.1:8840/api/view", timeout=2) as response:
            raw = response.read()
            assert response.status == 200
        break
    except OSError:
        if process.poll() is not None:
            raise RuntimeError("Design server exited; inspect raw stderr")
        time.sleep(0.2)
else:
    raise RuntimeError("Design server did not become HTTP-ready")
(review / "evidence/design-view.raw.json").write_bytes(raw)
view = json.loads(raw)
assert view["stage"] == "design"
assert len(view["model"]["nodes"]) == 5 and len(view["model"]["edges"]) == 4
assert view["events"] == [] and view["machine"]["current"] is None
with urlopen("http://127.0.0.1:8840/api/design") as response:
    focus_raw = response.read()
(review / "evidence/design-focus.raw.json").write_bytes(focus_raw)
assert json.loads(focus_raw)["stale"] is False
with urlopen("http://127.0.0.1:8840/graph") as response:
    assert response.status == 200
    (review / "evidence/design-page.raw.html").write_bytes(response.read())
print(json.dumps({"pid": process.pid, "url": "http://127.0.0.1:8840/graph", "nodes": 5,
                  "edges": 4, "business_events": 0, "focus_stale": False}))
