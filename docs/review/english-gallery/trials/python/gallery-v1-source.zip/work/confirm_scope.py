"""Record the simulated answer and prepare the first implementation baseline."""
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
def write(name, value):
    path = root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

answer = "模拟用户回答（这是本轮独立试用的测试角色回答，并非真实用户新增需求，请在证据中如实标记）：1. 选择 drive，基于声明的状态机开发。2. 程序检查上传文件的实际内容，只接受 PNG、JPEG 图片；不是图片就拒绝，不进入待审核，也不发送通知。3. 需要两个人登录，先用预置的上传者和审核者账号；上传者只能上传，审核者才能审核，不需要注册或找回密码。补充对原有消息和展览含义的确认：通知就在程序中的消息列表显示，不发邮件；审核者通过后才出现在公开画展，驳回则不展示。本轮先不加修改、删除、重新提交等功能。请继续展示/保存确认后的局部图，实施并完成全流程验收。所有问题、这份模拟回答、实现范围、失败、修复、复测及浏览器截图都要保存；不要把这些测试回答归为原始人类需求。最终语言切换候选稍后会提供升级复测，现阶段可继续业务验证。"
(root / "review/answer-02.simulated.original.txt").write_text(answer + "\n", encoding="utf-8")
doc = json.loads((root / "discovery.json").read_text(encoding="utf-8"))
write("review/evidence/discovery-before-answer.json", doc)
doc["sources"].append({"id": "S_simulated_02", "kind": "user", "text": answer,
    "locator": "review/answer-02.simulated.original.txt; TEST ROLE ANSWER, NOT ORIGINAL HUMAN REQUIREMENT", "test_role": "simulated_user"})
resolutions = {"D_mode": "drive: the application executor consumes the declaration.",
    "D_image": "Validate actual file content; only PNG and JPEG. Invalid content is rejected without a pending item or notification.",
    "D_identity": "Two preset accounts log in; uploader may upload and reviewer may review. No registration or password recovery."}
for decision in doc["decisions"]:
    decision["status"] = "resolved"
    decision["resolution"] = {"kind": "user_answer", "text": resolutions[decision["id"]], "source_refs": ["S_simulated_02"]}
net = doc["networks"][0]
net["actors"] = ["登录的上传者", "登录的审核者", "公开画展访客"]
labels = {"image_check": "程序检查实际内容：PNG / JPEG", "message": "合格上传生成审核者站内消息", "review": "审核者通过 / 驳回", "exhibition": "公开画展：仅展示通过图片"}
for node in net["nodes"]:
    if node["id"] in labels: node["label"] = labels[node["id"]]
    node.pop("summary", None)
    node["source_refs"] = ["U_original", "S_simulated_02"]
net["nodes"].extend([
    {"id": "login", "label": "预置两种账号登录与权限", "kind": "action", "source_refs": ["S_simulated_02"]},
    {"id": "invalid_file", "label": "拒绝非 PNG / JPEG：无待审项、无消息", "kind": "effect", "source_refs": ["S_simulated_02"]},
    {"id": "pending", "label": "待审核", "kind": "state", "source_refs": ["S_simulated_02"]},
    {"id": "published", "label": "已通过并公开展示", "kind": "state", "source_refs": ["S_simulated_02"]},
    {"id": "rejected", "label": "已驳回：不公开展示", "kind": "state", "source_refs": ["S_simulated_02"]}])
for edge in net["edges"]:
    edge["source_refs"] = ["U_original", "S_simulated_02"]
    if edge["id"] == "check_message": edge["label"] = "仅内容检查通过后通知"
net["edges"].extend([
    {"id": "login_upload", "from": "login", "to": "upload", "relation": "guard", "label": "上传者权限", "source_refs": ["S_simulated_02"]},
    {"id": "login_review", "from": "login", "to": "review", "relation": "guard", "label": "审核者权限", "source_refs": ["S_simulated_02"]},
    {"id": "check_invalid", "from": "image_check", "to": "invalid_file", "relation": "flow", "label": "实际内容不符合", "source_refs": ["S_simulated_02"]},
    {"id": "upload_pending", "from": "image_check", "to": "pending", "relation": "flow", "label": "实际内容符合", "source_refs": ["S_simulated_02"]},
    {"id": "review_pass", "from": "review", "to": "published", "relation": "flow", "label": "通过", "source_refs": ["S_simulated_02"]},
    {"id": "review_reject", "from": "review", "to": "rejected", "relation": "flow", "label": "驳回", "source_refs": ["S_simulated_02"]}])
doc["title"] = "画展上传与审核 · 模拟回答已确认"
net["outcome"] = "PNG/JPEG 上传后待审并生成站内消息；审核通过公开展示，驳回不展示。"
write("discovery.json", doc)
dialogue = json.loads((root / "review/dialogue.json").read_text(encoding="utf-8"))
dialogue.update(phase="02_implementation", answers=[{"source": "answer-02.simulated.original.txt", "kind": "simulated_user", "original_human_requirement": False}], status="scope_resolved")
write("review/dialogue.json", dialogue)
requirements = [
    ("R_mode", "Use a declaration-driven state machine."),
    ("R_identity", "Two preset login accounts; uploader may only upload, reviewer may review and read its message list."),
    ("R_content", "Verify actual content, accept only decodable PNG/JPEG, reject all others with no item and no message."),
    ("R_pending", "A valid upload creates a pending item and one reviewer in-app message."),
    ("R_review", "Reviewer may approve or reject a pending image. Approved images alone appear in the public gallery."),
    ("R_scope", "No registration, recovery, email, modification, deletion, or resubmission in this phase.")]
write("intent.json", {"intent_id": "gallery-python-trial", "project_id": "gallery-python-trial", "revision": "2", "goal": "Simple image exhibition with reviewed uploads", "requirements": [{"id": ident, "text": text, "status": "confirmed", "source": "S_simulated_02: explicitly simulated test-role answer, not original human requirement"} for ident,text in requirements], "exclusions": ["Registration", "Password recovery", "Email", "Editing", "Deletion", "Resubmission"]})
(root / "app").mkdir(exist_ok=True)
(root / "app/__init__.py").write_text('"""Gallery application package."""\n', encoding="utf-8")
checks = []
expected = {
    "approve_png": {"items": 1, "messages": 1, "public_count": 1, "last_state": "published"},
    "reject_jpeg": {"items": 1, "messages": 1, "public_count": 0, "last_state": "rejected"},
    "pending_hidden": {"items": 1, "messages": 1, "public_count": 0, "last_state": "pending"},
    "non_image": {"items": 0, "messages": 0, "public_count": 0, "status": 415},
    "spoof_extension": {"items": 0, "messages": 0, "public_count": 0, "status": 415},
    "unsupported_gif": {"items": 0, "messages": 0, "public_count": 0, "status": 415},
    "uploader_review_denied": {"items": 1, "messages": 1, "public_count": 0, "status": 403},
    "reviewer_upload_denied": {"items": 0, "messages": 0, "status": 403},
    "anonymous_upload_denied": {"items": 0, "messages": 0, "status": 401},
    "bad_login": {"items": 0, "messages": 0, "status": 401},
    "repeat_review": {"items": 1, "messages": 1, "public_count": 1, "status": 409},
    "private_image_hidden": {"items": 1, "messages": 1, "public_count": 0, "status": 404}}
for case, fields in expected.items():
    for field, value in fields.items():
        req = "R_identity" if "denied" in case or case == "bad_login" else "R_content" if case in {"non_image", "spoof_extension", "unsupported_gif"} else "R_review"
        checks.append({"id": f"{case}.{field}", "requirement": req, "case": case, "path": [field], "equals": value})
write("acceptance.json", {"description": "Independent expected effects written from the simulated answer before implementation", "checks": checks, "model_checks": []})
write("review/evidence/independent-expectations-before-implementation.json", expected)
write("behavior.json", {"schema_version": 3, "revision": "draft-baseline", "intent": "intent.json", "source_files": ["app/__init__.py", "intent.json", "discovery.json"], "nodes": [{"id": "upload", "kind": "data", "label": "Design baseline", "summary": "No implementation yet"}], "edges": [], "overview": [{"node": "upload"}], "scope": {"unknowns": ["Implementation has not started"]}})
write("sync.json", {"model": "behavior.json", "manifest": "manifest.json", "code_files": ["app/__init__.py"], "watch_files": ["discovery.json", "intent.json"], "acceptance": "acceptance.json", "discovery": "discovery.json", "observations_command": ["{python}", "-B", "observe.py"], "probe_modes": ["on", "off", "fault"], "test_commands": [["{python}", "-B", "test_app.py"]]})
