"""Separate human business confirmations from coding-side implementation evidence."""
from copy import deepcopy


MODE_QUESTION = {
    'id':'development-mode', 'audience':'user',
    'question':'后续开发是否以这张状态图为执行依据，还是保留项目自己的实现方式、由图跟随观察？两种方式都会持续维护图和监控。',
    'options':{'drive':'基于状态图开发','observe':'仅用于观察'},
}


def validate_selection(selection):
    if not isinstance(selection,dict) or selection.get('mode') not in {'drive','observe'}:
        raise ValueError('initial user choice is required: drive or observe')
    if selection.get('source')!='user' or not selection.get('answer','').strip() or not selection.get('locator','').strip():
        raise ValueError('mode needs the user answer and conversation locator; silence is not a choice')
    return deepcopy(selection)


def questions(project,index=None,discovery=None):
    human=[];coding=[]
    try:validate_selection(project.get('selection'))
    except (ValueError,TypeError):human.append(deepcopy(MODE_QUESTION))
    for decision in (discovery or {}).get('decisions',[]):
        if decision.get('status')=='open':
            human.append({'id':decision['id'],'audience':'user','question':decision.get('question',''),
                          'basis':decision.get('basis',decision.get('reason','')),'affects':decision.get('affects',[]),
                          'purpose':'confirm_current_intent'})
    owned={sid for f in project.get('model',{}).get('implementation',{}).get('features',[]) for sid in f.get('sources',[])}
    for call in (index or {}).get('unresolved',[]):
        if call['from'] not in owned:continue
        ident=f"{call['from']}:{call['line']}:{call['column']}"
        coding.append({'id':ident,'audience':'coding','symbol':call['from'],'expression':call['expression'],
                       'question':'核对实际调用目标及是否属于本项目；若为动态调用，用实际场景补充目标与参数证据。',
                       'accepted_evidence':['source binding','external dependency with explicit boundary','runtime case and target']})
    return {'user':human,'coding':coding,'instruction':'业务歧义问用户；实现绑定由编码过程核对。不要据此推荐或扩大业务范围。'}


def reconciliation_errors(record,index,model):
    """Bindings must exist in current source. Assertions alone are not runtime proof."""
    try:
        from ..behavior_model import digest
    except ImportError:
        from behavior_model import digest
    errors=[]
    identity=digest({p:u['file_hash'] for p,u in index['units'].items()})
    if not isinstance(record,dict) or record.get('schema')!='bo-reconciliation/v1': return ['implementation reconciliation is missing']
    if record.get('source_id')!=identity:errors.append('implementation answers refer to an earlier source version')
    expected={q['id']:q for q in questions({'model':model},index)['coding']}
    items=record.get('answers',[])
    if not isinstance(items,list) or any(not isinstance(i,dict) for i in items):return ['invalid implementation answers']
    answers={a.get('id'):a for a in items}
    if len(answers)!=len(items):errors.append('duplicate implementation answer')
    for ident,q in expected.items():
        a=answers.get(ident,{})
        if not a.get('reason','').strip():errors.append({'unanswered_implementation':ident});continue
        if a.get('status')=='bound':
            if a.get('target') not in index['symbols']:errors.append({'missing_implementation_target':ident})
            cases={c['case'] for f in model.get('implementation',{}).get('features',[]) for c in f.get('cases',[])}
            if not a.get('case') or a['case'] not in cases:errors.append({'dynamic_binding_requires_runtime_case':ident})
        elif a.get('status')=='external':
            if not a.get('dependency','').strip():errors.append({'missing_external_boundary':ident})
        else:errors.append({'unresolved_implementation':ident})
    for ident in set(answers)-set(expected):errors.append({'stale_implementation_answer':ident})
    return errors
