# Trial instructions

Use the project-local frozen candidate 3 at `.agents/skills/business-observer-candidate-3`.
The earlier candidate 1 and candidate 2 copies are retained as immutable evidence.
Do not use the global installation or modify the source candidate or other trials.
Keep maintained code, identifiers, comments, and canonical documentation in English.
Preserve original Chinese dialogue and screenshot evidence without rewriting it.
Record requests, questions, answers, decisions, commands, exit codes, failures,
repairs, retests, raw runtime evidence, and screenshots under `review/`.
Do not implement mode-dependent behavior until drive or observe is explicitly answered.
Keep design IDs and layout identity stable as the graph gains implementation evidence.
For each future coding batch, run the frozen skill's change_sync begin, bo_sync scan,
change_sync inspect, verify, accept, and check workflow with the absolute project root.
Keep implementation mapping, state constraints, business rules, and project checks separate.
Do not weaken existing checks or manufacture runtime evidence to obtain a pass.
Do not publish to GitHub.

