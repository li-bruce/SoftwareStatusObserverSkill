"""Optional observer integrations."""
