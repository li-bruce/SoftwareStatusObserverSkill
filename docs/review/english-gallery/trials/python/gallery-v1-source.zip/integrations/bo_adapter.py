"""Bounded observation adapter using the frozen Python public implementation."""
from collections import deque
from copy import deepcopy
import json
from pathlib import Path
import sqlite3
import threading
import uuid
from bo_stategraph import BOStateGraph
from app.ports import BOPort
from observer_runtime.behavior_model import capture, check
from observer_runtime.semantic_probe import Pins, Trace
from observer_runtime.bo_retention import EventHistory
from observer_runtime.recording_session import Recordings

class BOAdapter:
    def __init__(self, root, database, mode="on", capacity=2048, recording_dir=None):
        self.root, self.database = Path(root), str(database)
        self.project = json.loads((self.root / "bo_stategraph/project.json").read_text(encoding="utf-8"))
        self.model = self.project["model"]
        self.manifest = capture(self.root, self.model)
        self.build_id = self.manifest["build_id"]
        self.mode, self.metadata = mode, {}
        self.lock = threading.RLock()
        self.history = EventHistory(path=self.root / "work/runtime/events.jsonl", limits={"memory_events": 5000})
        self.frames = deque(maxlen=500)
        self.graph = BOStateGraph(self.model, build_id=self.build_id, mode="drive", instance_provider=self.bo_machine)
        self.pins = Pins(self.model, self.build_id, enabled=mode != "off", sink=self.bo_sink, capacity=capacity)
        self.port = BOPort(self.bo_record)
        self.recordings = Recordings(recording_dir or self.root / "work/recordings", self.bo_view,
            {p: (self.root / p).read_text(encoding="utf-8") for p in self.model["source_files"] if p.endswith(".py")},
            scope_setter=self.pins.bo_set_scope, event_source=self.history, interval=0.2)

    def bo_rows(self):
        with sqlite3.connect(self.database, timeout=10) as db:
            db.row_factory = sqlite3.Row
            try:
                return [dict(row) for row in db.execute("SELECT id,state,revision,build_id,format,uploader FROM images ORDER BY rowid")]
            except sqlite3.OperationalError:
                return []

    def bo_configuration(self, row):
        return {"attempt": row["id"], "phase": row["state"], "state_revision": row["revision"],
            "revision": row["revision"], "param_version": 1, "journal": [],
            "run_build_id": row["build_id"], "context": {"format": row["format"], "uploader": row["uploader"]}, "source_status": "current"}

    def bo_machine(self):
        configurations = [self.bo_configuration(row) for row in self.bo_rows()]
        return {"configurations": configurations, "current": configurations[-1]["phase"] if configurations else None, "journal": []}

    def bo_record(self, node, phase, inputs, outputs, entity, depends):
        if self.mode == "fault": raise OSError("Injected observer transport failure")
        call_id = uuid.uuid4().hex
        meta = None
        if phase == "commit" and "revision" in outputs:
            with sqlite3.connect(self.database, timeout=10) as db:
                db.row_factory = sqlite3.Row
                row = db.execute("SELECT j.image_id AS id,j.state,j.revision,i.build_id,i.format,i.uploader FROM journal j JOIN images i ON i.id=j.image_id WHERE j.image_id=? AND j.revision=?", (entity, outputs["revision"])).fetchone()
            if row:
                cfg = self.bo_configuration(dict(row))
                meta = {"revision": row["revision"], "machine": {"state_revision": row["revision"], "configurations": [cfg], "journal": [], "current": row["state"]},
                    "authority": {"entity": entity, "state": row["state"], "basis": {"param_version": 1}, "parameters": {**cfg["context"],"attempt":entity,"param_version":1}}}
        if meta:
            with self.lock: self.metadata[call_id] = meta
        event = Trace(self.pins, entity, entity).record(node, phase, {"param_version": 1},
            lambda: {"inputs": inputs, "outputs": outputs}, call_id=call_id, depends=depends,
            scope="application" if entity == "application" else "entity")
        if not event:
            with self.lock: self.metadata.pop(call_id, None)
        return event

    def bo_sink(self, text):
        event = json.loads(text)
        with self.lock:
            meta = self.metadata.pop(event["call_id"], None)
            if meta:
                event["revision"] = meta["revision"]
                self.frames.append({"event_id": event["id"], "run_id": event["run_id"], "build_id": self.build_id, **meta})
        self.history.append(event)

    def bo_view(self):
        machine = self.bo_machine()
        rows = machine["configurations"]
        current = rows[-1] if rows else None
        with self.lock: frames = deepcopy(list(self.frames))
        return {"layout_id": "gallery-python-trial", "model": self.model, "manifest": self.manifest,
            "binding_status": check(self.root, self.model, self.manifest), "events": self.history.snapshot(), "machine": machine,
            "authority": {"entity": current["attempt"] if current else None, "state": current["phase"] if current else None,
                "basis": {"param_version": 1}, "parameters": {**current["context"],"attempt":current["attempt"],"param_version":1} if current else {}},
            "health": self.pins.health(), "historical": False, "busy": False, "available_cases": ["live"],
            "runtime_frames": {"schema": "stategraph-runtime-frames/v1", "partial": True, "frames": frames}}

    def bo_projection(self):
        machine = self.bo_machine()
        return {"build_id": self.build_id, "machine": machine, "instances": self.graph.bo_instances(machine)}

    def bo_close(self):
        self.pins.flush()
        self.recordings.close()
        self.pins.close()
