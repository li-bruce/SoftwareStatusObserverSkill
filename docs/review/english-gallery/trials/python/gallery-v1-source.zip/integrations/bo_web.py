"""Observer-only Flask routes; these never emit business observations."""
from pathlib import Path
from flask import Blueprint, abort, current_app, jsonify, request, send_file
from observer_runtime.bo_web import BOWeb
from observer_runtime.view_preferences import Preferences, PreferenceConflict

routes = Blueprint("observer", __name__)

def bo_adapter():
    return current_app.config["BO_ADAPTER"]

def bo_surface():
    return current_app.config["BO_WEB"]

@routes.get("/graph")
def bo_graph():
    html = (bo_surface().assets / "index.html").read_text(encoding="utf-8")
    for name in bo_surface().assets.iterdir():
        if name.is_file(): html = html.replace('"/' + name.name + '"', '"/api/bo/assets/' + name.name + '"')
    html = html.replace('href="/control"', 'href="/"')
    return current_app.response_class(html, mimetype="text/html")

@routes.get("/api/bo/assets/<name>")
def bo_asset(name: str):
    if name not in {p.name for p in bo_surface().assets.iterdir() if p.is_file()}: abort(404)
    return send_file(bo_surface().assets / name)

@routes.get("/api/view")
def bo_view():
    return jsonify(bo_adapter().bo_view())

@routes.get("/api/design")
def bo_design():
    return jsonify(bo_surface().design.snapshot())

@routes.get("/api/source")
def bo_source():
    name = request.args.get("path", "")
    if name not in bo_adapter().model["source_files"]: abort(404)
    return jsonify({"path": name, "source": (bo_adapter().root / name).read_text(encoding="utf-8"), "build_id": bo_adapter().build_id})

@routes.get("/api/preferences")
def bo_preferences_read():
    return jsonify(current_app.config["BO_PREFERENCES"].read())

@routes.post("/api/preferences")
def bo_preferences_save():
    try: return jsonify(current_app.config["BO_PREFERENCES"].save(request.get_json()))
    except PreferenceConflict as exc: return jsonify(error=str(exc)), 409

@routes.get("/api/recordings")
def bo_recordings_list():
    return jsonify(bo_adapter().recordings.list())

@routes.post("/api/recordings/start")
def bo_recordings_start():
    body = request.get_json() or {}
    return jsonify(bo_adapter().recordings.start(body.get("label", ""), body.get("scope")))

@routes.post("/api/recordings/stop")
def bo_recordings_stop():
    return jsonify(bo_adapter().recordings.stop())

@routes.get("/api/recordings/<ident>")
def bo_recordings_get(ident: str):
    return jsonify(bo_adapter().recordings.get(ident))

@routes.get("/api/stategraph")
@routes.get("/api/stategraph/export")
def bo_export():
    return jsonify(bo_adapter().graph.bo_export(runtime={"machine": bo_adapter().bo_machine(), "events": bo_adapter().history.snapshot()}))

def bo_before_request():
    web = bo_surface()
    if web.is_observer_request(request.path):
        if request.method == "POST" and request.headers.get("Origin") not in {None, request.host_url.rstrip("/")}:
            return jsonify(error="Observer origin mismatch"), 403
        try:
            if not web.allowed(request.path): return jsonify(code="bo_web_disabled"), 404
        except Exception:
            return jsonify(code="bo_web_unavailable"), 503

def bo_after_request(response):
    if response.mimetype == "text/html" and not bo_surface().is_observer_request(request.path):
        try: response.set_data(bo_surface().entry_html(response.get_data()))
        except Exception: current_app.logger.warning("Observer Web configuration unavailable; business response preserved")
    response.headers["X-Content-Type-Options"] = "nosniff"
    return response

def bo_attach(app, adapter, root):
    app.config.update(BO_ENABLED=True, BO_ADAPTER=adapter, BO_WEB=BOWeb(root, assets=Path(root) / "static/graph"),
                      BO_PREFERENCES=Preferences(root, "gallery-python-trial"))
    app.register_blueprint(routes)
    app.before_request(bo_before_request)
    app.after_request(bo_after_request)
