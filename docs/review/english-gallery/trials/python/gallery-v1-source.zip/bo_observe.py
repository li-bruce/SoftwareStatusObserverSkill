"""Execute real application cases and independently read SQL/HTTP effects."""
from io import BytesIO
import json
from pathlib import Path
import re
import sqlite3
import uuid
from PIL import Image
from app.service import Gallery
from app.web import create_app
from integrations.bo_adapter import BOAdapter
from integrations.bo_web import bo_attach

ROOT = Path(__file__).resolve().parent

def image_bytes(fmt="PNG"):
    stream = BytesIO()
    Image.new("RGB", (48, 32), (78, 119, 101)).save(stream, format=fmt)
    return stream.getvalue()

def csrf(client):
    page = client.get("/login")
    return re.search(rb'name="csrf" value="([^"]+)"', page.data).group(1).decode()

def login(client, username, password=None):
    token = csrf(client)
    return client.post("/login", data={"csrf":token,"username":username,"password":password or {"uploader":"upload-demo-2026","reviewer":"review-demo-2026"}.get(username,"bad")})

def session_csrf(client):
    with client.session_transaction() as session:
        return session["csrf"]

def upload(client, data=None, filename="test.png"):
    return client.post("/upload", data={"csrf":session_csrf(client),"file":(BytesIO(image_bytes() if data is None else data),filename)}, content_type="multipart/form-data")

def sql_snapshot(database):
    with sqlite3.connect(database) as db:
        db.row_factory = sqlite3.Row
        rows = [dict(row) for row in db.execute("SELECT id,state,revision,build_id,format,uploader FROM images ORDER BY rowid")]
        messages = db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]
        recipients = [row[0] for row in db.execute("SELECT recipient FROM messages ORDER BY rowid")]
    return rows, messages, recipients

def execute_case(case, mode, parent=None):
    folder = parent or ROOT/"work/cases"/uuid.uuid4().hex
    folder.mkdir(parents=True, exist_ok=True)
    database = folder/f"{case}-{mode}.sqlite"
    adapter = BOAdapter(ROOT,database,mode=mode,recording_dir=folder/(case+"-"+mode+"-recordings"))
    service = Gallery(database,ROOT/"bo_stategraph/project.json",adapter.port,adapter.build_id)
    adapter.graph.bo_require_definition(service.machine.definition)
    app = create_app(service)
    bo_attach(app,adapter,ROOT)
    client=app.test_client()
    client.get("/")
    status=200
    if case == "bad_login":
        status=login(client,"uploader","wrong").status_code
    elif case == "anonymous_upload_denied":
        csrf(client)
        status=upload(client).status_code
    elif case == "reviewer_upload_denied":
        login(client,"reviewer")
        status=upload(client).status_code
    else:
        login(client,"uploader")
        client.get("/upload")
        if case in {"non_image","spoof_extension"}:
            status=upload(client,b"This is not an image", "image.png" if case=="spoof_extension" else "notes.txt").status_code
        elif case == "unsupported_gif":
            status=upload(client,image_bytes("GIF"),"pretend.jpg").status_code
        else:
            content=image_bytes("JPEG" if case=="reject_jpeg" else "PNG")
            response=upload(client,content,"image.jpg" if case=="reject_jpeg" else "image.png")
            status=response.status_code
            rows,_,_=sql_snapshot(database)
            ident=rows[0]["id"]
            if case == "uploader_review_denied":
                status=client.post("/review/"+ident,data={"csrf":session_csrf(client),"decision":"approve"}).status_code
            elif case == "private_image_hidden":
                client.post("/logout",data={"csrf":session_csrf(client)})
                status=client.get("/image/"+ident).status_code
            elif case != "pending_hidden":
                client.post("/logout",data={"csrf":session_csrf(client)})
                login(client,"reviewer")
                client.get("/messages")
                preview=client.get("/image/"+ident)
                assert preview.data==content, "Reviewer preview must return actual uploaded bytes"
                status=client.post("/review/"+ident,data={"csrf":session_csrf(client),"decision":"reject" if case=="reject_jpeg" else "approve"}).status_code
                client.get("/messages")
                if case == "repeat_review":
                    status=client.post("/review/"+ident,data={"csrf":session_csrf(client),"decision":"reject"}).status_code
                if case == "approve_png":
                    client.post("/logout",data={"csrf":session_csrf(client)})
                    assert client.get("/image/"+ident).data==content, "Public image bytes differ"
    public=app.test_client().get("/")
    rows,messages,recipients=sql_snapshot(database)
    observations={"items":len(rows),"messages":messages,"recipients":recipients,"public_count":public.data.count(b"<figure>"),"status":status,"last_state":rows[-1]["state"] if rows else ""}
    adapter.pins.flush()
    projection=adapter.bo_projection()
    events=adapter.history.snapshot()
    export=adapter.graph.bo_export(runtime={"machine":projection["machine"],"events":events})
    mapping_checks=[{"id":case+":"+mode+":ids","source":"independent SQL images.id","projection":"bo_instances.instance_id","actual":[r["id"] for r in rows],"mapped":[i["observed"]["instance_id"] for i in projection["instances"]]}]
    if case == "approve_png" and mode == "on":
        observed=next(e for e in events if e["node"]=="review" and e["phase"]=="commit")
        mapping_checks.append({"id":"approval-state","source":"independent SQL images.state","projection":"review commit outputs.state","actual":rows[0]["state"],"mapped":observed["outputs"]["state"]})
        msg=next(e for e in events if e["node"]=="message")
        mapping_checks.append({"id":"message-recipient","source":"independent SQL messages.recipient","projection":"message commit outputs.recipient","actual":recipients[0],"mapped":msg["outputs"]["recipient"]})
    result={"case":case,"mode":mode,"events":events,"observations":observations,"authority_rows":rows,"projection":projection,"health":adapter.pins.health(),"port_errors":adapter.port.errors,"database":str(database)}
    adapter.bo_close()
    return result,mapping_checks,export

def main():
    plan=json.loads((ROOT/"mapping.json").read_text(encoding="utf-8"))
    folder=ROOT/"work/cases"/uuid.uuid4().hex
    runs,checks=[],[]
    selected=None
    for case in plan["cases"]:
        for mode in plan["modes"]:
            run,mapping,export=execute_case(case,mode,folder)
            runs.append(run)
            checks.extend(mapping)
            if {"case":case,"mode":mode}==plan["export"]: selected=export
    model=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
    payload={"build_id":selected["build_id"],"machine":model["machine"],"runs":runs,"mapping_checks":checks,"stategraph_export":selected}
    print(json.dumps(payload,ensure_ascii=False))

if __name__=="__main__": main()
