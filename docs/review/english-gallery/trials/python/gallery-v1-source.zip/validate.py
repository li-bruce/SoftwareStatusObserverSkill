"""Normal project gate: preserve observer synchronization failures."""
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
raise SystemExit(subprocess.call([sys.executable,"-B",str(root/"observer_runtime/change_sync.py"),"check","--root",str(root)],cwd=root))
