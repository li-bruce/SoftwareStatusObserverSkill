"""Exercise the real loopback HTTP server without saving credentials or tokens."""
import hashlib
from http.cookiejar import CookieJar
import json
from pathlib import Path
import re
import sqlite3
import time
from urllib.error import HTTPError
from urllib.parse import urlencode
from urllib.request import Request,build_opener,HTTPCookieProcessor,urlopen

root=Path(__file__).resolve().parents[1]
base="http://127.0.0.1:8842"
evidence=root/"review/evidence"
client=build_opener(HTTPCookieProcessor(CookieJar()))
requests=[]
def call(path,data=None,headers=None):
    req=Request(base+path,data=data,headers=headers or {})
    try: response=client.open(req,timeout=10)
    except HTTPError as error: response=error
    raw=response.read()
    requests.append({"method":"POST" if data is not None else "GET","path":path,"status":response.status,"response_sha256":hashlib.sha256(raw).hexdigest()})
    return response.status,raw,response.geturl()
def token(raw): return re.search(rb'name="csrf" value="([^"]+)"',raw).group(1).decode()
def form(path,fields): return call(path,urlencode(fields).encode(),{"Content-Type":"application/x-www-form-urlencoded"})
def login(username,password):
    _,raw,_=call("/login")
    return form("/login",{"csrf":token(raw),"username":username,"password":password})
def upload(filename):
    _,raw,_=call("/upload")
    boundary="gallery_trial_boundary"
    data=(root/"work/browser-fixtures"/filename).read_bytes()
    body=(f'--{boundary}\r\nContent-Disposition: form-data; name="csrf"\r\n\r\n{token(raw)}\r\n--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="{filename}"\r\nContent-Type: application/octet-stream\r\n\r\n').encode()+data+f'\r\n--{boundary}--\r\n'.encode()
    return call("/upload",body,{"Content-Type":"multipart/form-data; boundary="+boundary})

initial=json.loads(urlopen(base+"/api/view").read())
assert initial["machine"]["configurations"]==[],"Use a fresh final live fixture database"
call("/")
login("uploader","upload-demo-2026")
status,_,_=upload("not-image.png");assert status==415
status,_,url=upload("test-exhibition.png");assert status==200
approved=url.split("saved=")[1]
status,raw,url=upload("test-reject.jpg");assert status==200
rejected=url.split("saved=")[1]
_,raw,_=call("/upload")
form("/logout",{"csrf":token(raw)})
_,raw,_=call("/");assert raw.count(b"<figure>")==0
login("reviewer","review-demo-2026")
_,raw,_=call("/messages")
assert b"test-exhibition.png" in raw and b"test-reject.jpg" in raw
form("/review/"+approved,{"csrf":token(raw),"decision":"approve"})
_,raw,_=call("/messages")
form("/review/"+rejected,{"csrf":token(raw),"decision":"reject"})
_,raw,_=call("/messages")
form("/logout",{"csrf":token(raw)})
_,raw,_=call("/");assert raw.count(b"<figure>")==1 and b"test-exhibition.png" in raw and b"test-reject.jpg" not in raw
assert call("/image/"+rejected)[0]==404
time.sleep(0.2)
before=json.loads(urlopen(base+"/api/view").read())
for path in ["/graph","/api/design","/api/preferences","/api/source?path=app/service.py","/api/stategraph/export","/api/recordings"]:
    assert urlopen(base+path).status==200
after=json.loads(urlopen(base+"/api/view").read())
assert before["events"]==after["events"],"Observer polling must not create business events"
assert after["binding_status"]["status"]=="current"
assert after["health"]["errors"]==0 and after["health"]["dropped"]==0
export=json.loads(urlopen(base+"/api/stategraph/export").read())
assert all(item["status"]=="observed" for item in export["instances"])
with sqlite3.connect(root/"work/gallery-delivery.sqlite") as db:
    facts={"states":db.execute("SELECT state,COUNT(*) FROM images GROUP BY state ORDER BY state").fetchall(),"messages":db.execute("SELECT recipient,COUNT(*) FROM messages GROUP BY recipient").fetchall()}
assert facts["states"]==[("published",1),("rejected",1)] and facts["messages"]==[("reviewer",2)]
for name,value in [("delivery-live-view.raw.json",after),("delivery-live-export.raw.json",export),("delivery-http-requests.json",requests),("delivery-independent-sql.json",facts)]:
    (evidence/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"http_requests":len(requests),"business_events":len(after["events"]),"invalid_upload_rejected":True,"public_images":1,"sql_states":facts["states"],"observer_poll_delta":0,"build_id":after["manifest"]["build_id"]}))

