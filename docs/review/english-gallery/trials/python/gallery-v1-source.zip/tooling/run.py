"""Execute a trial command and retain raw output and exit status."""
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

root = Path(__file__).resolve().parents[1]
name, *argv = sys.argv[1:]
env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONDONTWRITEBYTECODE="1",
           TMP=str(root / "work/tmp"), TEMP=str(root / "work/tmp"))
if argv[0] == "{python}":
    argv[0] = str(root / ".venv/Scripts/python.exe")
result = subprocess.run(argv, cwd=root, env=env, capture_output=True)
folder = root / "review/commands" / name
folder.parent.mkdir(parents=True, exist_ok=True)
if folder.with_suffix(".json").exists():
    raise RuntimeError("Command ID already used; preserve prior evidence")
folder.with_suffix(".stdout.log").write_bytes(result.stdout)
folder.with_suffix(".stderr.log").write_bytes(result.stderr)
folder.with_suffix(".json").write_text(json.dumps({"argv": argv, "cwd": str(root),
    "exit_code": result.returncode, "timestamp_utc": datetime.now(timezone.utc).isoformat()}, indent=2), encoding="utf-8")
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
raise SystemExit(result.returncode)

