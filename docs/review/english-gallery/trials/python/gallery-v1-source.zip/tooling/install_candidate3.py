"""Preserve candidate 2, then install and verify independent frozen candidate 3."""
from pathlib import Path
import hashlib
import json
import shutil
import runpy

root = Path(__file__).resolve().parents[1]
checkpoint = root / "review/candidate-2-checkpoint"
checkpoint.mkdir(exist_ok=True)
for folder in ["evidence", "screenshots"]:
    shutil.copytree(root / "review" / folder, checkpoint / folder, dirs_exist_ok=True)
for name in ["final-assessment.json", "failures.md", "skill-defects.md"]:
    shutil.copy2(root / "review" / name, checkpoint / name)
source = (root / "tooling/install_candidate2.py").read_text(encoding="utf-8")
source = source.replace("candidate-2", "candidate-3").replace("candidate_1", "candidate_2").replace("candidate 1", "candidate 2").replace("candidate 2", "candidate 3")
source = source.replace("candidate-1", "candidate-2").replace(".stategraph/initial-gallery", ".stategraph/candidate-2-upgrade")
manifest = Path(r"C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/gallery-trials/candidate-3/manifest.json")
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == "fd022e1377b17e2679a8e1e8e0b9cbba51d1bb41c2f4af017383cc7dab1ccb8c"
exec(compile(source, "candidate3-public-copy", "exec"))
