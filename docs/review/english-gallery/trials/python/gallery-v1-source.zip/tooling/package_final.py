"""Package current source, frozen provenance, and local trial evidence."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import shutil
from zipfile import ZipFile,ZIP_DEFLATED

root=Path(__file__).resolve().parents[1]
outputs=root/"outputs"
shutil.copy2(root/"review/candidate-3-upgrade.md",outputs/"FINAL-REPORT.md")
shutil.copy2(root/"review/failure-retest-index.md",outputs/"FAILURE-RETEST-INDEX.md")
shutil.copy2(root/"review/screenshots/candidate3-pending-en.png",outputs/"candidate3-state-values.png")
shutil.copy2(root/"review/screenshots/candidate3-final-graph.png",outputs/"gallery-graph.png")
assessment=json.loads((outputs/"final-assessment.json").read_text(encoding="utf-8"))
assessment["optional_label_fixture"]={"status":"passed","kind":"Explicitly derived display fixture, not fabricated runtime evidence","fallback":"pending"}
assessment["preferences_upgrade"]={"entries_identical":True,"before_revision":30,"after_revision":31,"whole_object_equality":"failed; entry-level retention passed"}
assessment["failure_retest_index"]="FAILURE-RETEST-INDEX.md"
console=json.loads((root/"review/evidence/candidate3-browser-console.json").read_text())
assert console["graph"]==[] and console["application"]==[]
assessment["browser"]["current_interval_console_errors_or_warnings"]=0
for name in ["review/final-assessment.json","outputs/final-assessment.json"]:
    (root/name).write_text(json.dumps(assessment,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
files=set()
for prefix in ["app","bo_stategraph","integrations","observer_runtime","static/graph","tooling",".agents/skills",".stategraph","review"]:
    files.update(p for p in (root/prefix).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix not in {".pyc",".lock"})
files.update(p for p in root.iterdir() if p.is_file() and p.suffix in {".py",".json",".md",".txt"})
files.update(p for p in (root/"work/browser-fixtures").iterdir() if p.is_file())
for name in ["FINAL-REPORT.md","FAILURE-RETEST-INDEX.md","final-assessment.json","gallery-stategraph.json","candidate3-state-values.png","gallery-final.png","gallery-graph.png","gallery-core.zip","gallery-core-candidate2.zip","gallery-core-candidate3.zip","candidate-1-accepted-source.zip","candidate-2-accepted-source.zip"]:
    files.add(outputs/name)
target=outputs/"gallery-source-and-evidence.zip"
with ZipFile(target,"w",ZIP_DEFLATED) as archive:
    for path in sorted(files): archive.write(path,path.relative_to(root).as_posix())
result={"created_utc":datetime.now(timezone.utc).isoformat(),"files":len(files),"bytes":target.stat().st_size,"sha256":hashlib.sha256(target.read_bytes()).hexdigest(),"excluded":["virtualenv","live runtime databases","work test copies","Git metadata"],"includes":"Current source, all three frozen Skills, accepted changes, raw review evidence, screenshots, core exports and image fixtures"}
(outputs/"package-manifest.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
print(json.dumps(result))
