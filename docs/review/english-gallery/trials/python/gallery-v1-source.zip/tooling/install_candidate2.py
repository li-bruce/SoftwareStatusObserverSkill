"""Archive candidate 1 and install a separately frozen candidate 2 with hashes."""
import hashlib
import json
from pathlib import Path
import shutil
from zipfile import ZipFile,ZIP_DEFLATED

root=Path(__file__).resolve().parents[1]
checkpoint=root/"review/candidate-1-checkpoint"
checkpoint.mkdir(exist_ok=True)
for name in ["sync.json","intent.json","discovery.json","implementation.json","acceptance.json","whitebox.json","mapping.json","reconciliation.json","ownership.json","manifest.json","bo_stategraph/project.json","bo_stategraph/runtime-version.json"]:
    target=checkpoint/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/name,target)
if not (checkpoint/"accepted-change").exists():
    shutil.copytree(root/".stategraph/initial-gallery",checkpoint/"accepted-change")
model=json.loads((root/"bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
paths=set(model["source_files"]+["bo_stategraph/project.json","sync.json","manifest.json"])
for prefix in ["observer_runtime","static/graph"]:
    paths.update(p.relative_to(root).as_posix() for p in (root/prefix).rglob("*") if p.is_file() and "__pycache__" not in p.parts)
if not (root/"outputs/candidate-1-accepted-source.zip").exists():
    with ZipFile(root/"outputs/candidate-1-accepted-source.zip","x",ZIP_DEFLATED) as archive:
        for name in sorted(paths): archive.write(root/name,name)
source=Path(r"C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/gallery-trials/candidate-2/business-observer")
installed=root/".agents/skills/business-observer-candidate-2"
if not installed.exists(): shutil.copytree(source,installed)
supplied=json.loads((source.parent/"manifest.json").read_text(encoding="utf-8"))
shutil.copy2(source.parent/"manifest.json",root/"review/candidate-2.supplied-manifest.json")
files=[]
for path in sorted(source.rglob("*")):
    if not path.is_file(): continue
    relative=path.relative_to(source).as_posix()
    original=hashlib.sha256(path.read_bytes()).hexdigest()
    copied=hashlib.sha256((installed/relative).read_bytes()).hexdigest()
    assert original==copied
    assert supplied["files"][relative]==original
    files.append({"path":relative,"source_sha256":original,"installed_sha256":copied,"bytes":path.stat().st_size})
digest=hashlib.sha256("".join(item["path"]+"\0"+item["source_sha256"]+"\n" for item in files).encode()).hexdigest()
(root/"review/candidate-2-provenance.json").write_text(json.dumps({"candidate":"candidate-2","status":"installed; acceptance pending","source":str(source),"installed":str(installed),"file_count":len(files),"inventory_sha256":digest,"files":files},indent=2),encoding="utf-8")
print(json.dumps({"files_verified":len(files),"inventory_sha256":digest,"candidate_1_preserved":True}))
