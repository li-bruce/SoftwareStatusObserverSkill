"""Explicit display fixture: omit optional model labels, keeping actual runtime facts."""
import json
from pathlib import Path
import sys
root = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from run import build_application
from werkzeug.serving import make_server
app, service, adapter = build_application(root, root / "work/gallery-final-candidate3.sqlite")
@app.after_request
def omit_optional_display_labels(response):
    from flask import request
    if request.path == "/api/view" and response.is_json:
        body = response.get_json()
        body["model"]["machine"].pop("labels",None)
        response.set_data(json.dumps(body,ensure_ascii=False))
    elif request.path.startswith("/api/recordings/") and response.is_json:
        body = response.get_json()
        if "context" in body:
            body["context"]["model"]["machine"].pop("labels",None)
            response.set_data(json.dumps(body,ensure_ascii=False))
    return response
print("Explicit optional-label display fixture: http://127.0.0.1:8844/graph",flush=True)
server = make_server("127.0.0.1",8844,app)
try: server.serve_forever()
except KeyboardInterrupt: pass
finally:
    server.server_close()
    if adapter: adapter.bo_close()
