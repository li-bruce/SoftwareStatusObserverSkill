"""Bind coding-side answers to current source; prepare the candidate review."""
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from observer_runtime.code_structure import scan
from observer_runtime.behavior_model import digest
from observer_runtime.bo_observer.development import questions
from observer_runtime.sync_config import config,snapshot

root=Path(__file__).resolve().parents[1]
cfg=json.loads((root/"sync.json").read_text(encoding="utf-8"))
cfg["reconciliation"]="reconciliation.json"
(root/"sync.json").write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
model=json.loads((root/cfg["model"]).read_text(encoding="utf-8"))["model"]
index=scan(root,cfg["code_files"])
own={"gallery_service()."+name:"app/service.py::Gallery."+name for name in ["login","authorize","upload","review","messages","exhibition","image"]}
own["self.machine.transition"]="bo_stategraph/workflow.py::GalleryMachine.transition"
own["gallery_service"]="app/web.py::gallery_service"
answers=[]
for question in questions({"model":model},index)["coding"]:
    expr=question["expression"]
    if expr in own:
        answer={"status":"bound","target":own[expr],"case":"approve_png","reason":"Explicit current Flask GALLERY binding or GalleryMachine method, exercised through real approve_png requests and verified callback/guard identities in project checks."}
    else:
        dependency="Python built-in/container methods or standard library"
        if any(part in expr for part in ("Image.","image.verify","image.load")): dependency="Pillow 11.3.0 image decoder"
        elif any(part in expr for part in ("request.","session.","render_template","redirect","send_file","current_app.","Flask")): dependency="Flask 3.1.2 and its declared Werkzeug/Jinja dependencies"
        elif "password_hash" in expr: dependency="Werkzeug password hashing"
        elif expr.startswith("db."): dependency="Python sqlite3 connection and SQLite transaction engine"
        answer={"status":"external","dependency":dependency,"reason":"Current imports and executed application cases establish this bounded external call. External internals are not represented as project-owned functions."}
    answers.append({"id":question["id"],"expression":expr,**answer})
assert len({answer["id"] for answer in answers})==len(answers),"Public candidate must supply unique call-question IDs"
record={"schema":"bo-reconciliation/v1","source_id":digest({p:u["file_hash"] for p,u in index["units"].items()}),"answers":answers}
(root/"reconciliation.json").write_text(json.dumps(record,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
active=json.loads((root/".stategraph/active.json").read_text(encoding="utf-8"))["change"]
snap=snapshot(root,config(root,"sync.json"))
plan=model["implementation"]
review={"candidate_id":snap["id"],"decisions":{name:{"action":"updated","reason":reason} for name,reason in {
    "business":"Implement only the original request clarified by explicitly simulated test role S_simulated_02.",
    "state_machine":"Flat drive declaration, loaded by the real executor; no duplicate authoritative machine.",
    "abstraction":"Stable design IDs retained; independent source inventory includes real routes, support functions, and exact observer exclusions.",
    "probes":"Capture actual login, role checks, decode results, commits, messages, queries, and form responses; observer APIs emit no business events."}.items()},
    "excluded_symbols":{sid:item["reason"] for sid,item in plan["support"].items()},"requirement_changes":{},"source_moves":[]}
(root/active/"review.json").write_text(json.dumps(review,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"candidate_id":snap["id"],"coding_answers":len(answers)}))
