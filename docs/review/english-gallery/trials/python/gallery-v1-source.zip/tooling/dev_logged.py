"""Run the normal development entrypoint while retaining exact server output."""
import argparse
import io
from pathlib import Path
import runpy
import sys
import threading

class BODualLog(io.TextIOBase):
    def __init__(self, original, file):
        self.original,self.file=original,file
        self.lock=threading.Lock()
    def write(self, value):
        with self.lock:
            self.file.write(value);self.file.flush()
            self.original.write(value);self.original.flush()
        return len(value)
    def flush(self):
        self.file.flush();self.original.flush()
    def isatty(self): return False

root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
parser=argparse.ArgumentParser(add_help=False)
parser.add_argument("--log-prefix",required=True)
options,arguments=parser.parse_known_args()
prefix=root/options.log_prefix
prefix.parent.mkdir(parents=True,exist_ok=True)
with prefix.with_suffix(".stdout.log").open("w",encoding="utf-8",buffering=1) as stdout, prefix.with_suffix(".stderr.log").open("w",encoding="utf-8",buffering=1) as stderr:
    original_out,original_err=sys.stdout,sys.stderr
    sys.stdout,sys.stderr=BODualLog(original_out,stdout),BODualLog(original_err,stderr)
    sys.argv=[str(root/"run.py"),*arguments]
    try: runpy.run_path(str(root/"run.py"),run_name="__main__")
    finally: sys.stdout,sys.stderr=original_out,original_err
