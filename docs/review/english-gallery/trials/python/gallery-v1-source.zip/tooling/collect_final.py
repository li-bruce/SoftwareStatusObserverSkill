"""Collect actual final evidence and a bounded trial assessment."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import sqlite3
from urllib.request import urlopen
from zipfile import ZipFile,ZIP_DEFLATED
from bo_stategraph import bo_export_view,bo_validate_export

root=Path(__file__).resolve().parents[1]
evidence=root/"review/evidence"
base="http://127.0.0.1:8842"
def fetch(path):
    with urlopen(base+path,timeout=10) as response:
        assert response.status==200
        return json.loads(response.read())
def write(path,value):
    target=root/path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

view=fetch("/api/view")
before=view["events"]
for path in ["/api/design","/api/preferences","/api/recordings","/api/source?path=app/service.py","/api/stategraph/export"]: fetch(path)
after=fetch("/api/view")
assert before==after["events"],"Observer controls emitted business events"
accepted=json.loads((root/".stategraph/candidate-2-upgrade/accepted.json").read_text(encoding="utf-8"))
assert view["manifest"]["build_id"]==accepted["build_id"]
assert view["binding_status"]["status"]=="current"
assert view["health"]["errors"]==0 and view["health"]["dropped"]==0
records=fetch("/api/recordings")["recordings"]
selected=[item for item in records if item["build_id"]==accepted["build_id"]]
assert len(selected)==1
record=fetch("/api/recordings/"+selected[0]["id"])
assert record["gaps"]==[]
assert len(record["events"])==39
assert record["end_seq"]-record["start_seq"]==len(record["events"])
required={"login","authorize","image_check","upload","message","messages","review","exhibition","image","http_login","http_upload","http_review","http_logout"}
assert required <= {event["node"] for event in record["events"]}
assert not any(event["outputs"].get("status",200)>=400 for event in record["events"])
raw_events=json.dumps(record["events"])
assert "upload-demo-2026" not in raw_events and "review-demo-2026" not in raw_events
frames=record["runtime_frames"]["frames"]
assert len(frames)==2
assert [frame["machine"]["current"] for frame in frames]==["pending","published"]
assert [frame["revision"] for frame in frames]==[1,2]
assert all(frame["machine"]["current"]==frame["machine"]["configurations"][0]["phase"] for frame in frames)
event_ids={event["id"] for event in record["events"]}
assert all(frame["event_id"] in event_ids for frame in frames)
write("review/evidence/final-browser-recording.json",record)
write("review/evidence/final-live-view.json",view)
complete=bo_export_view(view,mode="drive")
bo_validate_export(complete)
assert complete["runtime"]["runtime_frames"]["frames"]==view["runtime_frames"]["frames"]
write("review/evidence/final-complete-stategraph-export.json",complete)
write("outputs/gallery-stategraph.json",complete)

with sqlite3.connect(root/"work/gallery-final-candidate2.sqlite") as db:
    db.row_factory=sqlite3.Row
    rows=[dict(row) for row in db.execute("SELECT id,state,revision,build_id,format,uploader,sha256,width,height FROM images")]
    notifications=[dict(row) for row in db.execute("SELECT image_id,recipient FROM messages")]
assert len(rows)==1 and rows[0]["state"]=="published" and rows[0]["revision"]==2
assert rows[0]["build_id"]==accepted["build_id"]
assert notifications==[{"image_id":rows[0]["id"],"recipient":"reviewer"}]
assert rows[0]["sha256"]==hashlib.sha256((root/"work/browser-fixtures/test-exhibition.png").read_bytes()).hexdigest()
write("review/evidence/final-independent-sql.json",{"images":rows,"messages":notifications})

provenance=json.loads((root/"review/skill-provenance.json").read_text(encoding="utf-8"))
assert all(hashlib.sha256((root/".agents/skills/business-observer"/item["path"]).read_bytes()).hexdigest()==item["source_sha256"] for item in provenance["files"])
provenance2=json.loads((root/"review/candidate-2-provenance.json").read_text(encoding="utf-8"))
assert all(hashlib.sha256((root/".agents/skills/business-observer-candidate-2"/item["path"]).read_bytes()).hexdigest()==item["source_sha256"] for item in provenance2["files"])
runtime=json.loads((root/"bo_stategraph/runtime-version.json").read_text(encoding="utf-8"))
assert all(hashlib.sha256((root/name).read_bytes()).hexdigest()==value for name,value in runtime["files"].items())
preferences=fetch("/api/preferences")
write("review/evidence/final-preferences.json",preferences)
assert "升级保留标记：审核通过后才公开展示。" in json.dumps(preferences,ensure_ascii=False)
before_pref=json.loads((root/"review/candidate-1-checkpoint/preferences-before-upgrade.json").read_text(encoding="utf-8"))
first_english=json.loads((root/"review/evidence/candidate2-preferences-en.json").read_text(encoding="utf-8"))
key="business-observer.layout.v2:gallery-python-trial"
old_layout=json.loads(before_pref["entries"][key]);new_layout=json.loads(first_english["entries"][key])
assert old_layout["positions"]==new_layout["positions"]
assert old_layout["expanded"]==new_layout["expanded"]
assert old_layout.get("annotations")==new_layout.get("annotations")
assert not (root/"tooling/focus_project.py").exists() and not (root/"tooling/repair_metadata.py").exists()

record_folder=root/"review/programmatic-recordings"
record_folder.mkdir(exist_ok=True)
for path in (root/"work/tests").rglob("*.json"):
    try: item=json.loads(path.read_text(encoding="utf-8"))
    except (ValueError,UnicodeError): continue
    if item.get("schema")=="stategraph-recording/v1" and item.get("events"):
        prefix="negative-checker-" if item.get("label","").startswith("Negative checker fixture") else "actual-"
        target=record_folder/(prefix+item["id"]+".json")
        if not target.exists(): shutil.copy2(path,target)

verification=json.loads((root/".stategraph/candidate-2-upgrade/verification.json").read_text(encoding="utf-8"))
checks=json.loads((root/".stategraph/candidate-2-upgrade/checks/test-0.json").read_text(encoding="utf-8"))
test_count=int(re.search(r"Ran (\d+) tests",checks["stderr"]).group(1))
assessment={"timestamp_utc":datetime.now(timezone.utc).isoformat(),"project_root":str(root),"trial_kind":"Independent AI development trial with explicit simulated-user clarification; not human usability evidence",
    "candidate_1_frozen_files":len(provenance["files"]),"candidate_2_frozen_files":len(provenance2["files"]),"frozen_copies_modified":False,"managed_runtime_modified":False,
    "candidate_id":accepted["candidate_id"],"build_id":accepted["build_id"],"urls":{"business":base+"/","graph":base+"/graph"},
    "automated_reports":verification["reports"],"project_test_count":test_count,
    "browser":{"full_business_flow":"passed on final clean attempt","recording_events":len(record["events"]),"state_frames":len(frames),"recording_gaps":record["gaps"],"playback":"reached final step in real browser","locale_switch":"English and Chinese verified","locale_persistence":"English restored after navigating to graph without lang parameter","layout_positions_and_expanded":"preserved","notes":"preserved verbatim","camera_and_focus":"changed during later interaction; not claimed pixel-identical",
        "semantic_state_label":{"status":"failed","defect":"D05","actual_enum":"pending","declared_label":"待审核","displayed_replay_label":"尚未开始","scope":"Frozen candidate-2 change panel; source and SQL values remain correct"}},
    "overall_viewer_acceptance":"partial: D05 remains reproduced and unpatched",
    "observer_control_event_delta":0,"complete_public_export_frames":len(complete["runtime"]["runtime_frames"]["frames"]),
    "known_failures_retained":["Candidate-1 Windows metadata paths","Candidate-1 chained call IDs","Candidate-1 project-envelope focus","Viewer labels contract mismatch","Project frame-scope and current-summary repairs","One initial form-token rejection with successful retry","Pending semantic display defect D05"],
    "no_github_submission":True}
write("review/final-assessment.json",assessment)
write("outputs/final-assessment.json",assessment)
print(json.dumps({"build_id":accepted["build_id"],"events":len(record["events"]),"frames":len(frames),"gaps":record["gaps"],"project_tests":test_count,"automated_gate":verification["valid"],"viewer_acceptance":"partial_D05"}))
