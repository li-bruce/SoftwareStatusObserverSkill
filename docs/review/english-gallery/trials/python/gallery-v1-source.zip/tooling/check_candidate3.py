"""Independently check upgrade bytes, requirements, identity, and retained views."""
from pathlib import Path
import difflib
import hashlib
import json
from zipfile import ZipFile

root = Path(__file__).resolve().parents[1]
runtime = json.loads((root / "bo_stategraph/runtime-version.json").read_text())
for name, digest in runtime["files"].items():
    assert hashlib.sha256((root / name).read_bytes()).hexdigest() == digest, name
frozen = root / ".agents/skills/business-observer-candidate-3"
for name in ["graph-core.js", "renderer.js", "replay-steps.js", "viewer.js"]:
    assert (root / "static/graph" / name).read_bytes() == (frozen / "assets/stategraph-viewer" / name).read_bytes()
checkpoint = root / "review/candidate-2-checkpoint"
for name in ["acceptance.json", "whitebox.json", "mapping.json"]:
    assert json.loads((root / name).read_text(encoding="utf-8")) == json.loads((checkpoint / name).read_text(encoding="utf-8")), name
old = json.loads((checkpoint / "bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
new = json.loads((root / "bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
assert old["machine"] == new["machine"]
assert [n["id"] for n in old["nodes"]] == [n["id"] for n in new["nodes"]]
with ZipFile(root / "outputs/candidate-2-accepted-source.zip") as archive:
    diff = []
    for name in runtime["files"]:
        before = archive.read(name).decode("utf-8"); after = (root / name).read_bytes().decode("utf-8")
        if before != after:
            diff.extend(difflib.unified_diff(before.splitlines(True), after.splitlines(True), "candidate2/"+name, "candidate3/"+name))
(root / "review/candidate-3-upgrade.diff").write_text("".join(diff), encoding="utf-8")
print(json.dumps({"managed_hashes":len(runtime["files"]),"frozen_viewer_bytes":True,"prior_checks_unchanged":True,"machine_and_node_ids_unchanged":True}))
