# Independent gallery trial

[中文说明](README.zh-CN.md)

Project: `C:\Users\Lvi_P\Documents\Codex\2026-10-23\business-observer-gallery-python`.

The application is Python/Flask with SQLite. It consumes the flat state machine
in `bo_stategraph/project.json`. The optional Python observer uses the frozen
candidate-3 common implementation and its complete viewer. Candidates 1 and 2 are retained
in a separate immutable installation and evidence checkpoint.

## Run

From this project directory:

```powershell
.\.venv\Scripts\python.exe -B run.py --port 8842 --database work/gallery-v2-candidate3.sqlite
```

The command binds one loopback server and prints the actual business and graph
URLs. Ctrl+C closes its own server and observation threads. It does not terminate
other processes. If observation cannot initialize, the business app still starts
and the command explicitly reports the graph as unavailable. `--core` starts the
business app alone. When the delivered server is already running, open its URLs
instead of starting a second process on the same port.

| Account | Demo password | Scope |
| --- | --- | --- |
| uploader | upload-demo-2026 | Upload PNG images |
| reviewer | review-demo-2026 | Read upload messages and approve/reject pending images |

The exhibition is public. Actual decoded content determines image acceptance;
invalid content creates neither an item nor a notification. A valid upload and
its in-app message commit together. Approval publishes; rejection stays private.
There is no registration, password recovery, email, edit, delete, or resubmission.
The HTTP upload limit is 16 MiB, an implementation boundary of this local trial.

## Development and verification

The authoritative model is `bo_stategraph/project.json`; `discovery.json` preserves
the original Chinese request and the explicitly simulated-role clarification.
It must not be described as human usability evidence.

```powershell
.\.venv\Scripts\python.exe -B validate.py
```

This normal gate propagates `change_sync check` failures. Each coding change uses
begin, source scan, inspect, verify, accept, then check. Do not reset baselines to
hide source drift. `tooling/build_model.py` generates the model and source-first
inventory; `tooling/reconcile.py` records current coding bindings and review.
Run these inside an active change, then rerun the complete gate.

Independent scenarios compare real HTTP/SQL effects in on/off/fault modes.
Project checks also cover concurrent review, observer queue/builder failures,
control exclusion, exact replay frames, invalid declarations/actual states,
Web disablement, observation startup failure, and architecture ownership.
The evidence reports mapping, state constraints, business assertions, and project
checks separately. A passed finite trial does not prove arbitrary execution paths.

`review/` retains source manifests, commands, all failures and repairs, raw runtime
evidence, screenshots, original simulated dialogue, mutation checks, and upgrade
records. Runtime databases and personal views remain local. Nothing is published
to GitHub. User-facing packages and reports are in `outputs/`.


