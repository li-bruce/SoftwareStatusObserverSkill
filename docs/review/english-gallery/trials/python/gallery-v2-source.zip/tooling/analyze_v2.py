"""Compare the actual v2 change with immutable accepted v1 inputs."""
import ast
from copy import deepcopy
import difflib
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile

root=Path(__file__).resolve().parents[1]
checkpoint=root/"review/v1-candidate3-checkpoint"
load=lambda path:json.loads(path.read_text(encoding="utf-8"))
old=load(checkpoint/"bo_stategraph/project.json")["model"]
new=load(root/"bo_stategraph/project.json")["model"]
assert [n["id"] for n in old["nodes"]]==[n["id"] for n in new["nodes"]]
assert old["machine"]==new["machine"],"Existing state and permission transition declaration changed"
old_checks=load(checkpoint/"acceptance.json")["checks"]
new_checks=load(root/"acceptance.json")["checks"]
assert all(item in new_checks for item in old_checks)
old_decision=next(d for d in load(checkpoint/"discovery.json")["decisions"] if d["id"]=="D_image")
discovery=load(root/"discovery.json")
assert next(c for c in discovery["changes"] if c["id"]=="C_png_only_v2")["previous"]==old_decision
for old_node in old["nodes"]:
    current=next(n for n in new["nodes"] if n["id"]==old_node["id"])
    assert old_node.get("capture")==current.get("capture"),old_node["id"]
for name,installed in [("skill-provenance.json","business-observer"),("candidate-2-provenance.json","business-observer-candidate-2"),("candidate-3-provenance.json","business-observer-candidate-3")]:
    for item in load(root/"review"/name)["files"]:
        assert hashlib.sha256((root/".agents/skills"/installed/item["path"]).read_bytes()).hexdigest()==item["source_sha256"]
diff=[]
with ZipFile(root/"outputs/gallery-v1-candidate3-source-and-evidence.zip") as archive:
    for name in ["app/service.py","bo_stategraph/workflow.py","app/templates/upload.html","bo_observe.py","test_app.py","tooling/build_model.py","tooling/reconcile.py","intent.json","discovery.json","acceptance.json","whitebox.json","mapping.json","bo_stategraph/project.json"]:
        before=archive.read(name).decode("utf-8");after=(root/name).read_bytes().decode("utf-8")
        if before!=after: diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),"v1/"+name,"v2/"+name))
(root/"review/v2/source-and-contract.diff").write_text("".join(diff),encoding="utf-8")
functions=[]
for name,targets in [("app/service.py",{"Gallery.inspect_image","Gallery.upload"}),("bo_stategraph/workflow.py",{"GalleryMachine.valid_content"})]:
    tree=ast.parse((root/name).read_text(encoding="utf-8"))
    for cls in tree.body:
        if isinstance(cls,ast.ClassDef):
            for function in cls.body:
                symbol=cls.name+"."+getattr(function,"name","")
                if symbol in targets:functions.append({"path":name,"symbol":symbol,"line":function.lineno})
analysis={"stable_node_ids":len(old["nodes"]),"all_capture_schemas_unchanged":True,"state_transition_declaration_unchanged":True,"original_assertions_preserved":len(old_checks),"current_assertions":len(new_checks),"source_files":functions,"affected_nodes":["image_check","invalid_file","upload"],"unchanged_meanings":["login","authorize","review","message","messages","exhibition","unsubmitted","pending","published","rejected"],"model_revision_before":old["revision"],"model_revision_after":new["revision"],"skill_candidate":"candidate-3; all frozen copies unchanged","legacy_case":"reject_jpeg retains its ID and four original review assertions, using valid PNG in v2","new_cases":["jpeg_upload_denied","jpeg_spoof_png"]}
(root/"review/v2/change-analysis.json").write_text(json.dumps(analysis,indent=2)+"\n",encoding="utf-8")
print(json.dumps(analysis))
