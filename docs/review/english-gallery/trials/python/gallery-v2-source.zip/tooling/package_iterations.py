"""Create explicit source manifests and review exports without private runtime state."""
import hashlib
import json
from pathlib import Path,PurePosixPath
import shutil
import sys
from zipfile import ZipFile,ZIP_DEFLATED

root=Path(__file__).resolve().parents[1]
out=root/"outputs"
def load(path):return json.loads(path.read_text(encoding="utf-8"))
def excluded(name):
    path=PurePosixPath(name);parts=path.parts
    if any(p in {"node_modules",".venv",".git","__pycache__"} for p in parts):return True
    if path.suffix.lower() in {".sqlite",".sqlite3",".db",".pyc",".lock"} and path.name!="requirements.lock":return True
    if "bo_stategraph/config/" in name:return True
    if "preferences" in path.name.lower() and path.suffix==".json":return True
    return False
def source_files(read,names):
    project=load_model=json.loads(read("bo_stategraph/project.json"))["model"]
    selected=set(project["source_files"])
    selected.update(n for n in names if n.startswith(("app/","bo_stategraph/","integrations/","observer_runtime/","static/graph/","tooling/",".agents/skills/business-observer-candidate-3/",".stategraph/")))
    selected.update(n for n in names if "/" not in n and PurePosixPath(n).suffix in {".py",".json",".md",".txt",".lock"})
    selected.update({"sync.json","manifest.json","reconciliation.json","review/historical-tooling-hashes.json","review/evidence/independent-expectations-before-implementation.json"})
    selected.update(n for n in names if n.startswith("work/browser-fixtures/"))
    selected={n for n in selected if not excluded(n) and n in names}
    data={n:read(n) for n in sorted(selected)}
    # The recorded preparation/validation Python sources are needed by the
    # source-isolation hash contract. Only exact bytes from that record are added.
    historical=json.loads(read("review/historical-tooling-hashes.json"))["files"]
    for name,digest in historical.items():
        path=root/"work"/name
        raw=path.read_bytes()
        assert hashlib.sha256(raw).hexdigest()==digest,name
        data["work/"+name]=raw
    data["requirements.lock"]=(root/"requirements.lock").read_bytes()
    return data
def archive(name,data,kind):
    data=dict(data)
    data["REPRODUCE.txt"]=(f"{kind}\nPython 3.12; install with: python -m pip install -r requirements.lock\nRun: python -B run.py --port 8845 --database work/gallery-reproduced.sqlite\nTests: python -B test_app.py\nNormal gate: python -B validate.py\nThe delivered live app uses port 8842; use another free port for a separate extraction.\nSynthetic images are under work/browser-fixtures/. No runtime database, personal view, or cookie/token is included.\nOriginal validation receipts and their absolute historical root remain evidence; fresh package smoke results are in SOURCE-REPRODUCTION.md.\n").encode()
    files=[{"path":n,"bytes":len(raw),"sha256":hashlib.sha256(raw).hexdigest()} for n,raw in sorted(data.items())]
    assert not any(excluded(n) for n in data)
    with ZipFile(out/name,"w",ZIP_DEFLATED) as z:
        for n,raw in sorted(data.items()):
            assert not PurePosixPath(n).is_absolute() and ".." not in PurePosixPath(n).parts
            z.writestr(n,raw)
    result={"archive":name,"kind":kind,"files":files,"sha256":hashlib.sha256((out/name).read_bytes()).hexdigest(),"bytes":(out/name).stat().st_size}
    (out/(name+".manifest.json")).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    return result
if "--review-only" in sys.argv:
    manifests=[load(out/f"gallery-{version}-source.zip.manifest.json") for version in ["v1","v2"]]
    for manifest in manifests:
        assert hashlib.sha256((out/manifest["archive"]).read_bytes()).hexdigest()==manifest["sha256"]
else:
    with ZipFile(out/"gallery-v1-candidate3-source-and-evidence.zip") as old:
        v1=source_files(old.read,set(old.namelist()))
        manifests=[archive("gallery-v1-source.zip",v1,"Accepted business v1 with unchanged Skill candidate 3: PNG/JPEG")]
    names={p.relative_to(root).as_posix() for p in root.rglob("*") if p.is_file() and not any(x in {".venv","node_modules",".git","__pycache__"} for x in p.relative_to(root).parts)}
    v2=source_files(lambda n:(root/n).read_bytes(),names)
    manifests.append(archive("gallery-v2-source.zip",v2,"Final business v2 with unchanged Skill candidate 3: PNG-only and isolated session namespace"))
    for version,data in [("v1",v1),("v2",v2)]:
        candidate=[n for n in data if n.startswith(".agents/skills/business-observer-candidate-3/")]
        assert len(candidate)==144,(version,len(candidate))
        for item in load(root/"review/candidate-3-provenance.json")["files"]:
            assert hashlib.sha256(data[".agents/skills/business-observer-candidate-3/"+item["path"]]).hexdigest()==item["source_sha256"]
# Review evidence is separately exportable. Omit raw personal-preference files,
# configuration directories and nested historical bundles that could contain them.
review={p.relative_to(root).as_posix():p.read_bytes() for p in (root/"review").rglob("*") if p.is_file() and not excluded(p.relative_to(root).as_posix()) and p.suffix.lower()!=".zip"}
review.update({"outputs/gallery-core-v1-candidate3.zip":(out/"gallery-core-v1-candidate3.zip").read_bytes(),"outputs/gallery-core-v2-before-cookie.zip":(out/"gallery-core-v2-before-cookie.zip").read_bytes(),"outputs/gallery-core-v2-cookie-fixed-candidate3.zip":(out/"gallery-core-v2-cookie-fixed-candidate3.zip").read_bytes()})
for path in out.iterdir():
    if path.is_file() and (path.suffix==".md" or path.name.endswith("source.zip.manifest.json") or path.name in {"v1-final-assessment.json","v2-final-assessment.json"}):
        review["outputs/"+path.name]=path.read_bytes()
# Review exports do not use the runtime launch guide injected for source archives.
with ZipFile(out/"gallery-review-evidence.zip","w",ZIP_DEFLATED) as z:
    for name,raw in sorted(review.items()):z.writestr(name,raw)
review_manifest={"archive":"gallery-review-evidence.zip","files":[{"path":n,"sha256":hashlib.sha256(raw).hexdigest()} for n,raw in sorted(review.items())],"sha256":hashlib.sha256((out/"gallery-review-evidence.zip").read_bytes()).hexdigest()}
(out/"review-evidence.manifest.json").write_text(json.dumps(review_manifest,indent=2)+"\n",encoding="utf-8")
summary={"source_packages":[{k:v for k,v in m.items() if k!="files"} for m in manifests],"review_export":{"archive":review_manifest["archive"],"files":len(review),"sha256":review_manifest["sha256"]},"exclusions":["node_modules","virtualenv","Git metadata","real runtime databases","session and collector runtime token state","bo_stategraph/config including personal views","raw personal-preference payload JSON","nested old full bundles"],"retained":["synthetic image fixtures","requirements.lock","JavaScript package-lock.json","all 144 frozen candidate-3 files","original dialogue evidence","explicit per-file source hashes"]}
(out/"source-package-summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
print(json.dumps(summary))
