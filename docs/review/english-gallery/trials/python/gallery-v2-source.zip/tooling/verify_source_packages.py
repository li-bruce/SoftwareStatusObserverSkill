"""Execute both redacted source archives from isolated directories."""
import json
import hashlib
import os
from pathlib import Path
import subprocess
import sys
import uuid
from zipfile import ZipFile
root=Path(__file__).resolve().parents[1]
folder=root/"review/source-reproduction";folder.mkdir(exist_ok=True)
program='''
from pathlib import Path
from io import BytesIO
import json,sqlite3,sys
from PIL import Image
import app.service
from app.service import DomainError
from run import build_application
root=Path.cwd()
assert Path(app.service.__file__).resolve().is_relative_to(root)
app,service,adapter=build_application(root,root/"work/fresh-smoke.sqlite")
assert adapter is not None,"Observer failed to initialize from the source package"
client=app.test_client()
assert client.get("/").status_code==200 and client.get("/graph").status_code==200
jpeg=BytesIO();Image.new("RGB",(24,16),"orange").save(jpeg,format="JPEG")
if sys.argv[1]=="v1":
    ident=service.upload("uploader","photo.jpg",jpeg.getvalue())["id"]
    assert service.review("reviewer",ident,"reject")["state"]=="rejected"
else:
    try:service.upload("uploader","disguised.png",jpeg.getvalue())
    except DomainError as error:assert error.status==415
    else:raise AssertionError("JPEG accepted by v2 source package")
    with service.connect() as db:
        assert db.execute("SELECT COUNT(*) FROM images").fetchone()[0]==0
        assert db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]==0
png=BytesIO();Image.new("RGB",(24,16),"green").save(png,format="PNG")
ident=service.upload("uploader","content-not-extension.txt",png.getvalue())["id"]
assert service.exhibition()==[]
assert service.review("reviewer",ident,"approve")["state"]=="published"
assert len(service.exhibition())==1
adapter.pins.flush()
view=client.get("/api/view").get_json()
assert view["binding_status"]["status"]=="current",view["binding_status"]
adapter.bo_close()
print(json.dumps({"version":sys.argv[1],"application_and_observer_started":True,"actual_gallery_effects":True,"source_binding":"current","JPEG_policy":"accepted" if sys.argv[1]=="v1" else "rejected without image or notification","PNG_approval_public":True}))
'''
results=[]
for version in ["v1","v2"]:
    target=root/"work/.validation/source-package-smoke"/(version+"-"+uuid.uuid4().hex)
    target.mkdir(parents=True)
    archive=root/"outputs"/f"gallery-{version}-source.zip"
    with ZipFile(archive) as z:
        assert z.testzip() is None
        z.extractall(target)
    def run(label,argv):
        result=subprocess.run(argv,cwd=target,env=dict(os.environ,PYTHONPATH=""),capture_output=True,text=True,encoding="utf-8",errors="replace")
        (folder/f"{version}-{label}.stdout.log").write_text(result.stdout,encoding="utf-8")
        (folder/f"{version}-{label}.stderr.log").write_text(result.stderr,encoding="utf-8")
        metadata={"argv":argv,"cwd":str(target),"exit_code":result.returncode}
        (folder/f"{version}-{label}.json").write_text(json.dumps(metadata,indent=2),encoding="utf-8")
        return result
    smoke=run("actual-execution",[sys.executable,"-B","-c",program,version])
    assert smoke.returncode==0,smoke.stderr
    gate=run("normal-gate",[sys.executable,"-B","validate.py"])
    results.append({"version":version,"source_archive":archive.name,"archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),"actual_execution":json.loads(smoke.stdout),"normal_gate_exit_code":gate.returncode,"normal_gate_passed":gate.returncode==0})
(folder/"results.json").write_text(json.dumps(results,indent=2)+"\n",encoding="utf-8")
print(json.dumps(results))
