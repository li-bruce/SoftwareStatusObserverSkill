"""Freeze accepted business v1 and record the explicit simulated PNG-only change."""
from copy import deepcopy
import json
from pathlib import Path
import shutil

root=Path(__file__).resolve().parents[1]
checkpoint=root/"review/v1-candidate3-checkpoint"
checkpoint.mkdir(parents=True,exist_ok=False)
for name in ["intent.json","discovery.json","acceptance.json","whitebox.json","mapping.json","sync.json","manifest.json","implementation.json","reconciliation.json","ownership.json","bo_stategraph/project.json","bo_stategraph/config/views/local.json","review/final-assessment.json","review/candidate-3-upgrade.md","review/failure-retest-index.md"]:
    target=checkpoint/name;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/name,target)
shutil.copytree(root/".stategraph/candidate-3-upgrade",checkpoint/"accepted-change")
shutil.copytree(root/"review/evidence",checkpoint/"evidence")
for original,saved in [("gallery-source-and-evidence.zip","gallery-v1-candidate3-source-and-evidence.zip"),("gallery-core-candidate3.zip","gallery-core-v1-candidate3.zip"),("gallery-stategraph.json","gallery-stategraph-v1.json"),("FINAL-REPORT.md","V1-FINAL-REPORT.md"),("final-assessment.json","v1-final-assessment.json"),("package-manifest.json","v1-package-manifest.json")]:
    shutil.copy2(root/"outputs"/original,root/"outputs"/saved)
folder=root/"review/v2";folder.mkdir(exist_ok=False)
request="本轮改成只接受 PNG 图片；JPEG 与其他非 PNG 上传都拒绝且不发送审核通知。账号权限、审核规则、站内消息和展览规则全部保持此前已确认的含义。"
(folder/"request.simulated.original.txt").write_text(request+"\n",encoding="utf-8")
write=lambda path,value:(root/path).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
write("review/v2/dialogue.json",{"kind":"explicitly simulated test-role requirement; not original human product requirement","source":"authorized parent delegation in Codex conversation","source_file":"request.simulated.original.txt","confirmation":"Specific change already confirmed by simulated test role; no repeat question required","skill_candidate":"candidate-3 unchanged","business_before":"v1: decodable PNG/JPEG","business_after":"v2: decodable PNG only","unchanged":["drive","preset login roles","reviewer approval/rejection","in-app messages","public exhibition","scope exclusions"]})
intent=json.loads((root/"intent.json").read_text(encoding="utf-8"));intent["revision"]="3"
next(r for r in intent["requirements"] if r["id"]=="R_content").update(text="Verify actual decoded content; accept only PNG. Reject JPEG and every other non-PNG upload without an image item or in-app message.",source="S_simulated_03: explicit PNG-only follow-up test role; not original human requirement")
write("intent.json",intent)
doc=json.loads((root/"discovery.json").read_text(encoding="utf-8"))
doc["sources"].append({"id":"S_simulated_03","kind":"user","text":request,"locator":"review/v2/request.simulated.original.txt; simulated test role, not original human requirement","test_role":"simulated_user"})
previous=deepcopy(next(d for d in doc["decisions"] if d["id"]=="D_image"))
decision=next(d for d in doc["decisions"] if d["id"]=="D_image")
decision["resolution"]={"kind":"user_answer","text":"v2 accepts actual decodable PNG only. JPEG and every non-PNG are rejected without pending item or notification. Other business meanings are retained.","source_refs":["S_simulated_03"]}
doc.setdefault("changes",[]).append({"id":"C_png_only_v2","decision":"D_image","previous":previous,"source_refs":["S_simulated_03"],"reason":"Explicit simulated PNG-only iteration; complete earlier decision retained, including previous links."})
for net in doc["networks"]:
    net["outcome"]="v2: PNG upload creates a pending item and in-app reviewer message; approval publishes and rejection stays private."
    for node in net["nodes"]:
        if node["id"]=="image_check": node["label"]="解码实际内容：仅接受 PNG"
        if node["id"]=="invalid_file": node["label"]="拒绝 JPEG 与非 PNG：无待审项、无消息"
        if node["id"] in {"image_check","invalid_file"}: node["source_refs"]=["S_simulated_03"]
    for edge in net["edges"]:
        if edge.get("from")=="image_check":
            edge["source_refs"]=["S_simulated_03"]
            if "PNG" in edge.get("label",""): edge["label"]="实际 PNG 内容合格"
write("discovery.json",doc)
old=json.loads((root/"review/evidence/independent-expectations-before-implementation.json").read_text(encoding="utf-8"))
expected=deepcopy(old)
expected["reject_png"]=deepcopy(old["reject_jpeg"])
expected["reject_jpeg"]={"items":0,"messages":0,"public_count":0,"last_state":"","status":415}
expected["jpeg_spoof_png"]={"items":0,"messages":0,"public_count":0,"status":415}
write("review/v2/independent-expectations-before-implementation.json",expected)
acceptance=json.loads((root/"acceptance.json").read_text(encoding="utf-8"))
for check in acceptance["checks"]:
    if check["case"]=="reject_jpeg":
        check.update(requirement="R_content",equals=expected["reject_jpeg"][check["path"][0]])
for case,requirement in [("reject_jpeg","R_content"),("reject_png","R_review"),("jpeg_spoof_png","R_content")]:
    for field,value in expected[case].items():
        ident=case+"."+field
        if not any(c["id"]==ident for c in acceptance["checks"]): acceptance["checks"].append({"id":ident,"requirement":requirement,"case":case,"path":[field],"equals":value})
write("acceptance.json",acceptance)
write("review/v2/expectation-change-record.json",{"basis":"S_simulated_03, before implementation edits","previous_expectations":"../evidence/independent-expectations-before-implementation.json (unchanged)","changed_case":"reject_jpeg now rejects at upload with zero items/messages","retained_review_coverage":"reject_png has the same four original reviewer rejection assertions","extra_case":"JPEG bytes named PNG are rejected","unchanged_cases":[k for k in old if k!="reject_jpeg"],"original_checks":45,"current_checks":len(acceptance["checks"])})
print(json.dumps({"v1_preserved":True,"baseline_preserved":True,"v2_expectations_written_before_code":True,"cases":len(expected),"checks":len(acceptance["checks"])}))
