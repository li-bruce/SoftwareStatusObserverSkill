"""Replay the current HTTP probe against byte-verified pre-fix exported code."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
from zipfile import ZipFile
root=Path(__file__).resolve().parents[1]
source=root/"outputs/gallery-core-v2-before-cookie.zip"
assert hashlib.sha256(source.read_bytes()).hexdigest()=="020d48a46e031419acfde47bd4ce0c2005f990e2b1f782eaf10b25825a0b47fc"
folder=root/"work/.validation/legacy-cookie"/uuid.uuid4().hex
folder.mkdir(parents=True)
with ZipFile(source) as archive:archive.extractall(folder)
(folder/"tooling").mkdir()
shutil.copy2(root/"tooling/cookie_isolation_probe.py",folder/"tooling/cookie_isolation_probe.py")
argv=[sys.executable,"-B","tooling/cookie_isolation_probe.py","--expected-status","400","--out","probe-result.json"]
result=subprocess.run(argv,cwd=folder,env=dict(os.environ,PYTHONPATH=""),capture_output=True,text=True,encoding="utf-8")
(root/"review/v2/legacy-core-probe.stdout.log").write_text(result.stdout,encoding="utf-8")
(root/"review/v2/legacy-core-probe.stderr.log").write_text(result.stderr,encoding="utf-8")
(root/"review/v2/legacy-core-probe.command.json").write_text(json.dumps({"argv":argv,"cwd":str(folder),"exit_code":result.returncode},indent=2),encoding="utf-8")
assert result.returncode==0,result.stderr
body=json.loads((folder/"probe-result.json").read_text())
assert body["after_other_app_status"]==400 and body["same_cookie_namespace"]
shutil.copy2(folder/"probe-result.json",root/"review/v2/cookie-original-core-current-peer.json")
print(json.dumps({"original_core_sha_verified":True,"actual_HTTP_old_code_new_peer_status":400,"current_project_probe_status":200,"historical_F06_cause":"not established"}))
