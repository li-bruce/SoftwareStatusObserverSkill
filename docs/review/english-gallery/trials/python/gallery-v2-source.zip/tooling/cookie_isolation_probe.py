"""Bounded actual HTTP cookie-collision probe; never emit cookie or token values."""
import argparse
from http.cookiejar import CookieJar
import json
from pathlib import Path
import re
import sqlite3
import sys
import threading
from urllib.error import HTTPError
from urllib.parse import urlencode,urlsplit
from urllib.request import build_opener,HTTPCookieProcessor
import uuid
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from flask import Flask,session
from werkzeug.serving import make_server
from app.service import Gallery
from app.web import create_app

def run_cookie_probe(folder=None):
    folder=folder or root/"work/cookie-probes"/uuid.uuid4().hex
    folder.mkdir(parents=True,exist_ok=True)
    service=Gallery(folder/"gallery.sqlite",root/"bo_stategraph/project.json")
    app=create_app(service)
    other=Flask("other_local_app")
    other.secret_key=uuid.uuid4().hex
    # A separate WSGI test peer emits a genuinely signed session from the other
    # Flask application. It defines no gallery route or production feature.
    with other.test_request_context():
        session["other_application"]=True
        peer_response=other.make_response("Other local application session set")
        other.session_interface.save_session(other,session,peer_response)
        private_peer_headers=list(peer_response.headers)
    def other_wsgi_fixture(environ,start_response):
        start_response("200 OK",private_peer_headers)
        return [b"Other local application session set"]
    servers=[make_server("127.0.0.1",0,target,threaded=True) for target in [app,other_wsgi_fixture]]
    threads=[threading.Thread(target=s.serve_forever,kwargs={"poll_interval":0.01},daemon=True) for s in servers]
    urls=[f"http://127.0.0.1:{s.server_port}" for s in servers]
    requests=[]
    def request(client,base,path,data=None):
        try: response=client.open(base+path,data=data,timeout=10)
        except HTTPError as error: response=error
        with response:
            body=response.read()
            status=response.status
            destination=urlsplit(response.geturl()).path
        requests.append({"application":"gallery" if base==urls[0] else "other","method":"POST" if data else "GET","path":path,"final_path":destination,"status":status})
        return body,status,destination
    def attempt(interfere):
        client=build_opener(HTTPCookieProcessor(CookieJar()))
        body,status,_=request(client,urls[0],"/login")
        assert status==200
        private_form_value=re.search(rb'name="csrf" value="([^"]+)"',body).group(1).decode()
        if interfere: assert request(client,urls[1],"/seed")[1]==200
        data=urlencode({"csrf":private_form_value,"username":"uploader","password":"upload-demo-2026"}).encode()
        _,status,destination=request(client,urls[0],"/login",data)
        return status,destination
    for thread in threads: thread.start()
    try:
        control_status,control_path=attempt(False)
        collision_status,collision_path=attempt(True)
        assert control_status==200 and control_path=="/upload"
        with sqlite3.connect(folder/"gallery.sqlite") as db:
            counts={name:db.execute("SELECT COUNT(*) FROM "+name).fetchone()[0] for name in ["images","messages"]}
        assert counts=={"images":0,"messages":0}
        return {"kind":"Actual HTTP requests against two independent loopback servers on different random ports","control_status":control_status,"control_final_path":control_path,"after_other_app_status":collision_status,"after_other_app_final_path":collision_path,"same_cookie_namespace":app.config["SESSION_COOKIE_NAME"]==other.config["SESSION_COOKIE_NAME"],"independent_sql_counts":counts,"requests":requests,"secrets_emitted":False,"historical_F06_root_cause":"Not established by this bounded mechanism probe"}
    finally:
        for server in servers: server.shutdown();server.server_close()
        for thread in threads: thread.join(timeout=2)
        assert not any(t.is_alive() for t in threads)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--expected-status",type=int,required=True)
    parser.add_argument("--out",required=True)
    args=parser.parse_args()
    result=run_cookie_probe()
    (root/args.out).write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result))
    assert result["after_other_app_status"]==args.expected_status
