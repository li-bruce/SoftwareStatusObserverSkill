"""Collect actual v2 browser events and compare them with independent SQLite facts."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import sys
from urllib.request import urlopen
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root))
from bo_stategraph import bo_export_view,bo_validate_export
base="http://127.0.0.1:8842"
fetch=lambda path:json.load(urlopen(base+path,timeout=10))
def write(name,value):
    (root/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
accepted=json.loads((root/".stategraph/gallery-v2-png-only/accepted.json").read_text())
verification=json.loads((root/".stategraph/gallery-v2-png-only/verification.json").read_text())
view=fetch("/api/view")
assert view["binding_status"]["status"]=="current"
assert view["manifest"]["build_id"]==accepted["build_id"]
assert view["health"]["errors"]==view["health"]["dropped"]==0
records=[r for r in fetch("/api/recordings")["recordings"] if r["build_id"]==accepted["build_id"]]
assert len(records)==1
record=fetch("/api/recordings/"+records[0]["id"])
events=record["events"]
assert events and record["end_seq"]-record["start_seq"]==len(events)
assert record["gaps"]==[]
decoded=[e for e in events if e["node"]=="image_check"]
assert [(e["outputs"]["format"],e["outputs"]["valid"]) for e in decoded]==[("JPEG",False),("PNG",True)]
denied=[e for e in events if e["node"]=="invalid_file"]
assert len(denied)==1 and denied[0]["outputs"]=={"created":False,"status":415}
assert denied[0]["inputs"]["format"]=="JPEG"
http_errors=[(e["node"],e["outputs"]["status"]) for e in events if "status" in e["outputs"] and e["outputs"]["status"]>=400 and e["node"].startswith("http_")]
assert http_errors==[("http_upload",415)],http_errors
commits=[e for e in events if e["phase"]=="commit"]
assert [e["node"] for e in commits]==["upload","message","review"]
assert len([e for e in events if e["node"]=="messages" and e["outputs"]["count"]==0])==1
frames=record["runtime_frames"]["frames"]
assert len(frames)==2
assert [f["machine"]["current"] for f in frames]==["pending","published"]
assert [f["revision"] for f in frames]==[1,2]
assert all(f["machine"]["current"]==f["machine"]["configurations"][0]["phase"] for f in frames)
assert all(f["event_id"] in {e["id"] for e in events} for f in frames)
assert all(f["machine"]["configurations"][0]["context"]["format"]=="PNG" for f in frames)
raw=json.dumps(events)
assert "upload-demo-2026" not in raw and "review-demo-2026" not in raw
with sqlite3.connect(root/"work/gallery-v2-candidate3.sqlite") as db:
    db.row_factory=sqlite3.Row
    rows=[dict(r) for r in db.execute("SELECT id,state,format,revision,build_id,sha256 FROM images")]
    messages=[dict(r) for r in db.execute("SELECT image_id,recipient FROM messages")]
    journal=[dict(r) for r in db.execute("SELECT image_id,event,previous,state,revision FROM journal ORDER BY seq")]
assert len(rows)==1 and rows[0]["format"]=="PNG" and rows[0]["state"]=="published" and rows[0]["revision"]==2
assert rows[0]["build_id"]==accepted["build_id"]
assert rows[0]["sha256"]==hashlib.sha256((root/"work/browser-fixtures/test-exhibition.png").read_bytes()).hexdigest()
assert messages==[{"image_id":rows[0]["id"],"recipient":"reviewer"}]
assert [r["state"] for r in journal]==["pending","published"]
for path in ["/api/design","/api/source?path=app/service.py","/api/recordings","/api/stategraph/export"]:fetch(path)
assert fetch("/api/view")["events"]==view["events"]
complete=bo_export_view(view,mode="drive");bo_validate_export(complete)
assert complete["runtime"]["runtime_frames"]["frames"]==view["runtime_frames"]["frames"]
write("review/v2/browser-recording.raw.json",record)
write("review/v2/live-view.raw.json",view)
write("review/v2/independent-sql-final.json",{"images":rows,"messages":messages,"journal":journal})
write("outputs/gallery-stategraph-v2.json",complete)
tests=json.loads((root/".stategraph/gallery-v2-png-only/checks/test-0.json").read_text())
assessment={"timestamp_utc":datetime.now(timezone.utc).isoformat(),"business_version":"v2 PNG-only","skill_candidate":"candidate-3 unchanged","simulated_requirement":True,"human_usability_evidence":False,"candidate_id":accepted["candidate_id"],"build_id":accepted["build_id"],"reports":verification["reports"],"project_tests":int(re.search(r"Ran (\d+) tests",tests["stderr"]).group(1)),"browser":{"record_id":record["id"],"events":len(events),"frames":len(frames),"gaps":record["gaps"],"format_decisions":[e["outputs"] for e in decoded],"expected_http_rejection":http_errors,"JPEG_images_messages_journal_before_PNG":[0,0,0],"PNG_final":{"state":"published","format":"PNG","messages":1,"revision":2},"observer_control_event_delta":0},"urls":{"application":base+"/","graph":base+"/graph"},"remaining":"Finite project evidence, not the full Skill repository suite or human usability study. Earlier v1 token failure cause unresolved; final v2 flow has no unexpected HTTP error.","pending_approval":None,"github_published":False}
write("review/v2/assessment.json",assessment);write("outputs/v2-assessment.json",assessment)
print(json.dumps({"build_id":accepted["build_id"],"events":len(events),"frames":len(frames),"gaps":record["gaps"],"tests":assessment["project_tests"],"reports":{k:v["status"] for k,v in verification["reports"].items()}}))
