"""Check the independent PNG-only requirement before and after implementation."""
from pathlib import Path
import sys
import json
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from bo_observe import execute_case
root=Path(__file__).resolve().parents[1]
run,_,_=execute_case("jpeg_upload_denied","on")
expected=json.loads((root/"review/v2/independent-expectations-before-implementation.json").read_text())["jpeg_upload_denied"]
for field,value in expected.items():
    assert run["observations"][field]==value, f"PNG-only requirement: {field} expected {value!r}, actual {run['observations'][field]!r}"
assert not any(e["node"] in {"upload","message"} and e["phase"]=="commit" for e in run["events"])
print(json.dumps({"JPEG_rejected":True,"no_image_or_notification":True,"observations":run["observations"]}))
