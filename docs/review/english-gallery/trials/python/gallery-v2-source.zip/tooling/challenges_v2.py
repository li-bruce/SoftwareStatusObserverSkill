"""Check real source drift and independently detect a business mutation."""
import difflib
import json
from pathlib import Path
import subprocess
import sys
import uuid
from zipfile import ZipFile

root=Path(__file__).resolve().parents[1]
folder=root/"review/v2/challenges"
folder.mkdir(parents=True,exist_ok=True)
def run(name,argv,cwd):
    result=subprocess.run(argv,cwd=cwd,capture_output=True)
    (folder/(name+".stdout.log")).write_bytes(result.stdout)
    (folder/(name+".stderr.log")).write_bytes(result.stderr)
    (folder/(name+".json")).write_text(json.dumps({"argv":argv,"cwd":str(cwd),"exit_code":result.returncode},indent=2),encoding="utf-8")
    return result

source=root/"app/service.py"
before=source.read_bytes()
after=before.replace(b"WHERE state='published'",b"WHERE state IN ('pending','published')")
assert after!=before
try:
    source.write_bytes(after)
    result=run("unsynchronized-domain-source",[sys.executable,"-B",str(root/"validate.py")],root)
    assert result.returncode!=0,"Normal project gate accepted unsynchronized business source"
finally:
    source.write_bytes(before)
restored=run("restored-normal-gate",[sys.executable,"-B",str(root/"validate.py")],root)
assert restored.returncode==0

package=root/"outputs/gallery-core-v2-candidate3.zip"
clean=root/"work/.validation/core-smoke"/uuid.uuid4().hex
clean.mkdir(parents=True)
with ZipFile(package) as archive:
    names=archive.namelist()
    assert not any(name.startswith(("observer_runtime/","integrations/","static/graph/")) for name in names)
    archive.extractall(clean)
program='''
from io import BytesIO
from PIL import Image
from app.service import Gallery,DomainError
from app.web import create_app
import importlib.util,json
assert importlib.util.find_spec("observer_runtime") is None
assert importlib.util.find_spec("integrations") is None
data=BytesIO();Image.new("RGB",(16,16),"green").save(data,format="PNG")
service=Gallery("clean-core.sqlite","bo_stategraph/project.json")
client=create_app(service).test_client()
jpeg=BytesIO();Image.new("RGB",(16,16),"orange").save(jpeg,format="JPEG")
try: service.upload("uploader","disguised.png",jpeg.getvalue())
except DomainError as error: assert error.status==415
else: raise AssertionError("JPEG accepted by PNG-only exported core")
with service.connect() as db:
    assert db.execute("SELECT COUNT(*) FROM images").fetchone()[0]==0
    assert db.execute("SELECT COUNT(*) FROM messages").fetchone()[0]==0
ident=service.upload("uploader","core.png",data.getvalue())["id"]
assert client.get("/").data.count(b"<figure>")==0,"Pending image leaked to public gallery"
assert b"data-bo-entry" not in client.get("/").data
assert client.get("/graph").status_code==404
assert service.review("reviewer",ident,"approve")["state"]=="published"
assert client.get("/").data.count(b"<figure>")==1
try: service.upload("uploader","fake.png",b"not an image")
except DomainError as error: assert error.status==415
else: raise AssertionError("Non-image accepted by exported core")
print(json.dumps({"observer_absent":True,"drive_core_executed":True,"pending_hidden":True,"approved_public":True,"invalid_rejected":True}))
'''
result=run("exported-core-execution",[sys.executable,"-B","-c",program],clean)
assert result.returncode==0,result.stderr.decode(errors="replace")

mutant=root/"work/.validation/business-mutation"/uuid.uuid4().hex
mutant.mkdir(parents=True)
with ZipFile(package) as archive: archive.extractall(mutant)
target=mutant/"app/service.py"
original=target.read_text(encoding="utf-8")
changed=original.replace("WHERE state='published'","WHERE state IN ('pending','published')")
target.write_text(changed,encoding="utf-8")
(folder/"business-mutation.patch").write_text("".join(difflib.unified_diff(original.splitlines(True),changed.splitlines(True),fromfile="app/service.py",tofile="mutant/app/service.py")),encoding="utf-8")
result=run("business-mutation-detected",[sys.executable,"-B","-c",program],mutant)
assert result.returncode!=0
assert b"Pending image leaked to public gallery" in result.stderr,"Mutation failed for a non-business reason"
assert source.read_bytes()==before
print(json.dumps({"unsynchronized_source_rejected":True,"restored_gate_passed":True,"exported_core_ran":True,"mutation_failed_for_business_reason":True,"core_directory":str(clean)}))



