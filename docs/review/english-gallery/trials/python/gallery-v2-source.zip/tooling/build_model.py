"""Generate one project envelope from confirmed intent and source-first inventory."""
import ast
import hashlib
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from observer_runtime.code_structure import scan, enrich
from observer_runtime.behavior_model import validate
from observer_runtime.bo_observer.protocol import validate_project
from observer_runtime.observation_scope import endpoint_paths

ROOT = Path(__file__).resolve().parents[1]
def write(name, value):
    (ROOT / name).parent.mkdir(parents=True, exist_ok=True)
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def generate():
    files = sorted([p.relative_to(ROOT).as_posix() for folder in ("app", "integrations") for p in (ROOT/folder).rglob("*.py")] + ["bo_stategraph/workflow.py", "run.py"])
    index = scan(ROOT, files)
    features, nodes = [], []
    definitions = [
        ("login", "预置账号登录", "action", "app/service.py::Gallery.login", {"username":"string", "password_present":"boolean"}, {"authenticated":"boolean", "role":"string"}, [("approve_png","return"),("bad_login","return")], {"username":("username","value"),"password":("password_present","derived")}),
        ("authorize", "按实际账号角色检查权限", "decision", "app/service.py::Gallery.authorize", {"actor":"string","required":"string"}, {"role":"string","allowed":"boolean"}, [("approve_png","return"),("uploader_review_denied","return")], {"actor":("actor","value"),"required":("required","value")}),
        ("image_check", "解码实际内容：仅接受 PNG", "decision", "app/service.py::Gallery.inspect_image", {"byte_count":"number"}, {"valid":"boolean","format":"string","width":"number","height":"number"}, [("approve_png","return"),("non_image","return"),("unsupported_gif","return"),("jpeg_upload_denied","return"),("jpeg_spoof_png","return")], {"data":("byte_count","derived")}),
        ("upload", "上传并保存待审核图片", "action", "app/service.py::Gallery.upload", {"actor":"string","filename":"string","byte_count":"number"}, {"id":"string","state":"string","revision":"number","sha256":"string"}, [("approve_png","commit")], {"actor":("actor","value"),"filename":("filename","value"),"data":("byte_count","derived")}),
        ("message", "事务提交后：审核者站内消息", "effect", "app/service.py::Gallery.notify", {"image_id":"string"}, {"recipient":"string","message_id":"string"}, [("approve_png","commit")], {"db":(None,"context"),"image_id":("image_id","value")}),
        ("review", "声明驱动：通过 / 驳回", "action", "app/service.py::Gallery.review", {"actor":"string","image_id":"string","decision":"string"}, {"before":"string","state":"string","revision":"number","reviewer_guard":"boolean"}, [("approve_png","commit"),("reject_jpeg","commit")], {"actor":("actor","value"),"image_id":("image_id","value"),"decision":("decision","value")}),
        ("messages", "读取审核者消息列表", "action", "app/service.py::Gallery.messages", {"actor":"string"}, {"count":"number"}, [("approve_png","return")], {"actor":("actor","value")}),
        ("exhibition", "公开画展：仅已通过图片", "action", "app/service.py::Gallery.exhibition", {}, {"count":"number"}, [("approve_png","return")], {}),
        ("image", "读取公开图片 / 审核预览", "action", "app/service.py::Gallery.image", {"image_id":"string","actor":"string"}, {"format":"string","byte_count":"number"}, [("approve_png","return")], {"image_id":("image_id","value"),"actor":("actor","value")})]
    http = {"exhibition_page":("http_exhibition","公开画展页面", "approve_png"), "login_page":("http_login_page","登录页面","approve_png"),
        "login_action":("http_login","提交登录表单","approve_png"), "logout_action":("http_logout","退出账号","approve_png"),
        "upload_page":("http_upload_page","上传页面","approve_png"), "upload_action":("http_upload","提交上传表单","approve_png"),
        "messages_page":("http_messages","消息审核页面","approve_png"), "review_action":("http_review","提交审核表单","approve_png"),
        "image_content":("http_image","图片内容请求","approve_png")}
    for symbol,(ident,label,case) in http.items():
        incoming = {"image_id":"string"} if symbol in {"review_action","image_content"} else {}
        params = {key:(key,"value") for key in incoming}
        definitions.append((ident,label,"action","app/web.py::"+symbol,incoming,{"status":"number"},[(case,"response")],params))
    for ident,label,kind,sid,inputs,outputs,cases,params in definitions:
        path,symbol = sid.split("::")
        parent = {"authorize":"login","messages":"message","image":"exhibition"}.get(ident)
        if ident.startswith("http_"):
            parent = {"http_exhibition":"exhibition", "http_login_page":"login", "http_login":"login", "http_logout":"login", "http_upload_page":"upload", "http_upload":"upload", "http_messages":"message", "http_review":"review", "http_image":"image"}[ident]
        node = {"id":ident,"label":label,"kind":kind,"layer":"business" if not parent else "program",
            "summary":"Confirmed simulated-role scope; actual values come only from the executed function or HTTP response.",
            "source":{"path":path,"symbol":symbol},"capture":{"in":inputs,"out":outputs},"requirements":["R_review"]}
        if ident == "image_check": node["requirements"] = ["R_content"]
        if parent: node["parent"] = parent
        nodes.append(node)
        disposition = []
        for name,(field,policy) in params.items():
            item = {"source":sid,"name":name,"policy":policy}
            if policy == "context": item["reason"] = "Transaction context, not captured."
            else:
                item.update(node=ident,direction="in",field=field)
                if policy == "derived": item["reason"] = "Capture only byte count or credential presence; never file bytes or credentials."
            disposition.append(item)
        features.append({"id":ident,"label":label,"business_node":parent or ident,"nodes":[ident],"sources":[sid],"parameters":disposition,
            "cases":[{"case":case,"node":ident,"phase":phase} for case,phase in cases]})
    nodes.append({"id":"invalid_file","kind":"effect","parent":"upload","layer":"program","label":"拒绝内容：不保存、不通知","summary":"Invalid content has no image row and no message row.","source":{"path":"app/service.py","symbol":"Gallery.upload"},"capture":{"in":{"format":"string"},"out":{"status":"number","created":"boolean"}}})
    upload = next(f for f in features if f["id"] == "upload")
    upload["nodes"].append("invalid_file")
    upload["cases"].append({"case":"non_image","node":"invalid_file","phase":"reject"})
    upload["cases"].append({"case":"jpeg_upload_denied","node":"invalid_file","phase":"reject"})
    nodes[-1]["requirements"] = ["R_content"]
    states = ["unsubmitted","pending","published","rejected"]
    for state in states:
        nodes.append({"id":state,"kind":"state","layer":"state","value":state,"label":{"unsubmitted":"尚未提交","pending":"待审核","published":"通过并公开","rejected":"驳回不展示"}[state],"summary":"Persisted or initial state defined by the common executable declaration."})
    edges = [{"id":a+"_"+b,"from":a,"to":b,"type":kind,"label":label,"evidence":"Explicit simulated-role answer S_simulated_02; not runtime evidence"} for a,b,kind,label in [
        ("login","upload","guard","上传者"),("login","review","guard","审核者"),("upload","image_check","flow","实际内容"),
        ("image_check","invalid_file","flow","JPEG / 非 PNG 拒绝"),("image_check","pending","flow","仅 PNG 合格"),("upload","message","flow","同一事务"),
        ("message","messages","flow","审核者读取"),("messages","review","flow","待审图片"),("review","published","flow","通过"),
        ("review","rejected","flow","驳回"),("published","exhibition","guard","仅通过项可公开")]]
    for node in nodes:
        if node.get("parent"): edges.append({"id":"contains."+node["id"],"from":node["parent"],"to":node["id"],"type":"contains","evidence":"Authored implementation ownership","label":"实现"})
    for edge in edges:
        if edge["from"] == "image_check": edge["evidence"] = "Explicit simulated PNG-only iteration S_simulated_03; not runtime evidence"
    classified = {sid for f in features for sid in f["sources"]}
    support, excluded = {}, {}
    for sid, symbol in index["symbols"].items():
        if symbol["kind"] != "function" or sid in classified: continue
        name = symbol["symbol"].split(".")[-1]
        if symbol["path"].startswith("integrations/") or symbol["path"] == "app/ports.py":
            excluded[sid] = {"category":"observer","reason":"Exact observer-only integration or neutral failure-isolated port; no domain decision."}
            if symbol.get("entrypoints"): excluded[sid]["routes"] = endpoint_paths(symbol)
        elif name == "__init__":
            excluded[sid] = {"category":"construction","reason":"Object construction; domain initialization is separately inventoried."}
        else:
            owner = "review" if symbol["path"] == "bo_stategraph/workflow.py" else "login" if symbol["path"] == "app/web.py" else "upload"
            support[sid] = {"node":owner,"reason":"Source-inventoried support implementation; no runtime success inferred from this classification."}
    implementation = {"schema":"bo-implementation/v1","features":features,"support":support,"excluded":excluded}
    write("implementation.json", implementation)
    machine = {"engine":"bo.fsm","version":"1","states":states,"values":states,"initial":"unsubmitted","state_type":"enum",
        "labels":{"unsubmitted":"尚未提交","pending":"待审核","published":"通过并公开","rejected":"驳回不展示"},
        "context":{"format":{"type":"string"},"uploader":{"type":"string"}},
        "events":{event:{"payload":{"role":{"type":"string"}}} for event in ("submit","approve","reject")},
        "guards":{"uploader":{"node":"authorize"},"reviewer":{"node":"authorize"},"content":{"node":"image_check"}},
        "transitions":[{"source":"unsubmitted","dest":"pending","trigger":"submit","conditions":["uploader","content"]},
            {"source":"pending","dest":"published","trigger":"approve","conditions":["reviewer"]},
            {"source":"pending","dest":"rejected","trigger":"reject","conditions":["reviewer"]}]}
    resources = sorted(p.relative_to(ROOT).as_posix() for p in (ROOT/"app").rglob("*") if p.is_file() and p.suffix in {".html",".css"})
    watched = ["intent.json","discovery.json","implementation.json","requirements.txt","tooling/build_model.py","bo_observe.py","test_app.py","validate.py","bo_stategraph/__init__.py","bo_stategraph/bo_contracts.py","bo_stategraph/execution_contract.py","bo_stategraph/runtime-version.json","observer_runtime/architecture_guard.py","ownership.json","mapping.json","whitebox.json"]
    watched.extend(["requirements.lock","tooling/cookie_isolation_probe.py","review/v2/independent-expectations-before-implementation.json","review/v2/request.simulated.original.txt"])
    source_files = sorted(set(files+resources+watched))
    model = {"schema_version":3,"revision":"gallery-v2-png-only","project_id":"gallery-python-trial","title":"画展上传与审核","intent":"intent.json",
        "source_files":source_files,"nodes":nodes,"edges":edges,"overview":[{"node":n["id"]} for n in nodes if not n.get("parent") and n["kind"] != "state"],
        "graph_roots":["login","upload","image_check","message","review","exhibition"],"scope":{"unknowns":["Finite local trial cases; arbitrary dynamic calls and all concurrent schedules are not proven."]},
        "machine":machine,"implementation":implementation,"presentation":{"subject":"画展上传与审核","recording":{"parameters":["format","uploader"]}}}
    model = enrich(model,index,1)
    choice = "选择 drive，基于声明的状态机开发。"
    project = {"protocol":"bo-project/v1","project_id":"gallery-python-trial","selection":{"mode":"drive","source":"user","answer":choice,"locator":"review/answer-02.simulated.original.txt; explicitly simulated test role, not original human requirement"},"model":model}
    write("bo_stategraph/project.json",project)
    cases = sorted({c["case"] for c in json.loads((ROOT/"acceptance.json").read_text(encoding="utf-8"))["checks"]})
    mapping = {"schema":"bo-mapping/v1","cases":cases,"modes":["on","off","fault"],"source":"bo_observe.py independent SQL reads of images table",
        "actual_collection":["authority_rows"],"actual_id":["id"],"fields":[
            {"id":"state","node":"review","actual":["state"],"mapped":["state"]},
            {"id":"revision","node":"review","actual":["revision"],"mapped":["revision"]},
            {"id":"build","node":"upload","actual":["build_id"],"mapped":["build_id"]},
            {"id":"format","node":"image_check","actual":["format"],"mapped":["context","format"]},
            {"id":"uploader","node":"upload","actual":["uploader"],"mapped":["context","uploader"]}],"export":{"case":"approve_png","mode":"on"}}
    write("mapping.json",mapping)
    whitebox = {"schema_version":1,"rules":[{"id":"content-rule","requirement":"R_content","claim":"Actual decodable PNG is accepted; JPEG and all other content are rejected without effects","basis":"S_simulated_03 (explicit simulated PNG-only iteration)","category":"decision","node":"image_check","source":{"path":"app/service.py","symbol":"Gallery.inspect_image"}}],
        "checks":[{"id":"valid-png","rule":"content-rule","case":"approve_png","phase":"return","count":{"min":1},"fields":[{"path":["outputs","valid"],"equals":True},{"path":["outputs","format"],"equals":"PNG"}]},
            {"id":"invalid-content","rule":"content-rule","case":"non_image","phase":"return","count":{"min":1},"fields":[{"path":["outputs","valid"],"equals":False}]},
            {"id":"jpeg-rejected","rule":"content-rule","case":"jpeg_upload_denied","phase":"return","count":{"min":1},"fields":[{"path":["outputs","valid"],"equals":False},{"path":["outputs","format"],"equals":"JPEG"}]},
            {"id":"jpeg-disguised-as-png-rejected","rule":"content-rule","case":"jpeg_spoof_png","phase":"return","count":{"min":1},"fields":[{"path":["outputs","valid"],"equals":False},{"path":["outputs","format"],"equals":"JPEG"}]}]}
    write("whitebox.json", whitebox)
    frozen = {p.relative_to(ROOT/"work").as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (ROOT/"work").rglob("*.py")}
    write("review/historical-tooling-hashes.json",{"files":frozen})
    cfg = {"model":"bo_stategraph/project.json","manifest":"manifest.json","code_files":files,"watch_files":source_files,"discovery":"discovery.json","acceptance":"acceptance.json","whitebox":"whitebox.json","mapping_contract":"mapping.json","require_mapping_witnesses":True,
        "stategraph":{"module":"bo_stategraph/__init__.py","development_mode":"drive","execution_mode":"drive","decision_source":"user","decision":choice},
        "source_scope":{"roots":["."],"require_symbol_classification":True,"exclude":{"observer_runtime/**":"Frozen managed observer runtime; tool fingerprints and managed hashes preserve it.","static/graph/**":"Unmodified frozen viewer assets, managed by bo_upgrade.","tooling/**":"Trial build and command tooling, watched explicitly.","work/**":"Historical preparation scripts and generated runtime files; hashed historical Python sources.","review/**":"Historical evidence, not application implementation.","outputs/**":"Deliverables and verified exports.","bo_stategraph/__init__.py":"Managed public graph module.","bo_stategraph/bo_contracts.py":"Managed public declaration validation.","bo_stategraph/execution_contract.py":"Managed public activity validation.","bo_observe.py":"Independent evidence runner, explicitly watched.","test_app.py":"Independent project checks, explicitly watched.","validate.py":"Project verification entrypoint, explicitly watched."},"frozen_sources":{"work":"review/historical-tooling-hashes.json"}},
        "slice_depth":1,"probe_callees":["self.bo.record"],"required_probes":[{"symbol":"app/service.py::Gallery.upload","node":"upload","phase":"commit"},{"symbol":"app/service.py::Gallery.review","node":"review","phase":"commit"},{"symbol":"app/service.py::Gallery.login","node":"login","phase":"return"}],
        "required_runtime_probes":[{"case":"approve_png","node":"upload","phase":"commit"},{"case":"approve_png","node":"review","phase":"commit"},{"case":"non_image","node":"invalid_file","phase":"reject"}],"probe_modes":["on","off","fault"],"observations_command":["{python}","-B","bo_observe.py"],"test_commands":[["{python}","-B","test_app.py"],["{python}","-B","observer_runtime/architecture_guard.py","check","--root",str(ROOT)]],"timeout_seconds":180}
    write("sync.json",cfg)
    discovery = json.loads((ROOT/"discovery.json").read_text(encoding="utf-8"))
    for net in discovery["networks"]:
        for node in net["nodes"]: node["model_nodes"] = [node["id"]]
    for decision in discovery["decisions"]:
        req = {"D_mode":"R_mode","D_identity":"R_identity","D_image":"R_content"}[decision["id"]]
        accepted = json.loads((ROOT/"acceptance.json").read_text(encoding="utf-8"))
        checks = [c["id"] for c in accepted["checks"] + accepted.get("model_checks",[]) if c["requirement"] == req]
        if not checks and req == "R_mode":
            acceptance = json.loads((ROOT/"acceptance.json").read_text(encoding="utf-8"))
            acceptance["model_checks"].append({"id":"mode-engine","requirement":"R_mode","path":["machine","engine"],"equals":"bo.fsm"})
            write("acceptance.json",acceptance)
            checks=["mode-engine"]
        decision["links"]={"requirements":[req],"model_nodes":[n for n in decision["affects"] if n in {x["id"] for x in model["nodes"]}],"checks":checks}
    write("discovery.json",discovery)
    validate(ROOT,model)
    validate_project(project)
    print(json.dumps({"nodes":len(model["nodes"]),"features":len(features),"source_files":len(files),"source_symbols":len(index["symbols"])}))

if __name__ == "__main__": generate()
