"""Build versioned review entrypoints from actual retained trial artifacts."""
import json
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1]
out=root/"outputs"
def copy(source,dest):
    target=out/dest;target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(root/source,target)
def write(name,text):
    (out/name).write_text(text,encoding="utf-8")
v2=json.loads((out/"v2-final-assessment.json").read_text(encoding="utf-8"))
build=v2["build_id"]
copy("review/v1-candidate3-checkpoint/review/candidate-3-upgrade.md","V1-REVIEW.md")
copy("review/v2/final-review.md","V2-BEFORE-COOKIE-REVIEW.md")
body=(root/"review/v2/final-review.md").read_text(encoding="utf-8")
body=body.replace("29f4a5735a3b9a73c094925c0fe02bbb265dbe118c8c444fa693c488c3084d2f",build).replace("c8bb9170ac369192d35290ce0b4e46ff8c2444a0b9c58946ce9db0892aa567c0",v2["candidate_id"]).replace("12 tests + architecture","13 tests + architecture").replace("4fa667385710475d9510543ea39a6186",v2["browser"]["record_id"])
body+="\n\n"+(root/"review/v2-final/cookie-isolation-review.md").read_text(encoding="utf-8")
body+="\nThe pre-cookie passing v2 build and 12-test report remain separately available as V2-BEFORE-COOKIE-REVIEW.md. The final v2 build has 13 tests. See SOURCE-REPRODUCTION.md for actual execution of both redacted source archives.\n"
write("V2-REVIEW.md",body)
write("FAILURE-RETEST-INDEX.md",(root/"review/failure-retest-index.md").read_text(encoding="utf-8")+"\n\n"+(root/"review/v2/failures-repairs-retests.md").read_text(encoding="utf-8")+"\n\n"+(root/"review/v2-final/cookie-isolation-review.md").read_text(encoding="utf-8"))
dialogue=[("review/request.original.txt","original-delegated-requirement.txt"),("review/questions.zh-CN.txt","original-questions.zh-CN.txt"),("review/answer-02.simulated.original.txt","original-simulated-answer.txt"),("review/upgrade-request.original.txt","original-candidate2-request.txt"),("review/candidate-3-request.actual-tool.txt","actual-candidate3-request.txt"),("review/actual-parent-delegations.final.tool-export.json","actual-parent-delegations.json"),("review/actual-agent-messages.final.tool-export.json","actual-agent-messages.json"),("review/v2/delegation.original.txt","actual-v2-delegation.txt"),("review/v2/cookie-request.original.txt","actual-cookie-probe-request.txt"),("review/v2/discussion-diagram.original.mmd","actual-v2-diagram.mmd")]
for source,name in dialogue:copy(source,"dialogue/"+name)
write("ACTUAL-DIALOGUE-INDEX.md","""# Actual dialogue records and provenance

These files are original recorded text or direct tool exports. They are not a
recreated dialogue. Chinese text is preserved without rewriting.

| Record | Source and boundary |
| --- | --- |
| [Initial requirement](dialogue/original-delegated-requirement.txt) | Original gallery requirement quoted by the authorized parent delegation |
| [Original questions](dialogue/original-questions.zh-CN.txt) | The actual mode, content, and identity clarification questions |
| [Simulated answer](dialogue/original-simulated-answer.txt) | Explicit test-role answer selecting drive and PNG/JPEG v1; not original human requirements |
| [Actual parent delegations](dialogue/actual-parent-delegations.json) | Eight exact send_message_to_thread prompts sent to this Python trial, including candidate upgrades, PNG-only iteration, material request, and cookie probe |
| [Actual assistant messages](dialogue/actual-agent-messages.json) | User-facing agentMessage text directly returned by read_thread, with message/turn IDs and phase |
| [Candidate-3 request](dialogue/actual-candidate3-request.txt) | Exact recovered parent tool argument, separately labeled; not the later upgrade summary |
| [v2 delegation](dialogue/actual-v2-delegation.txt) | Actual explicitly simulated PNG-only instruction and material request |
| [Displayed v2 diagram](dialogue/actual-v2-diagram.mmd) | Same Chinese diagram actually displayed in the coding conversation |
| [Cookie probe request](dialogue/actual-cookie-probe-request.txt) | Actual bounded mechanism request; explicitly prohibits historical over-attribution |

Tool exports omit private reasoning and unrelated chats. The child read_thread
items do not include user-message items; the exact original files and targeted
parent prompt export provide those records separately. The parent export covers
the latest three tool-returned turns and exposes its pagination metadata. The
initial child thread preview is explicitly labeled as a preview. This is not
claimed to be a complete byte-for-byte transport transcript of every tool output.

V1/V2 review reports, change summaries, and failure indices are retrospective
analysis. They must not be substituted for these primary records. The evidence
ZIP separately retains actual command metadata, raw command logs, decisions,
runtime records, independent SQL reads and screenshots. Simulated clarification
is not human usability evidence.
""")
evidence=[("review/v1-candidate3-checkpoint/evidence/final-browser-recording.json","v1-browser-recording.json"),("review/v1-candidate3-checkpoint/accepted-change/verification.json","v1-four-reports.json"),("review/v2-pre-cookie-checkpoint/accepted-change/verification.json","v2-before-cookie-four-reports.json"),(".stategraph/gallery-v2-cookie-isolation/verification.json","v2-final-four-reports.json"),("review/v2/browser-recording.raw.json","v2-before-cookie-browser-recording.json"),("review/v2-final/browser-recording.raw.json","v2-final-browser-recording.json"),("review/v2-final/independent-sql-final.json","v2-final-independent-sql.json"),("review/v2/cookie-mechanism-before.json","cookie-before.json"),("review/v2/cookie-mechanism-after-WSGI-fixture.json","cookie-after.json"),("review/v2/cookie-original-core-current-peer.json","cookie-original-core.json"),("review/source-reproduction/results.json","source-reproduction-results.json"),("review/v2/change-analysis.json","stable-id-and-source-analysis.json")]
for source,name in evidence:copy(source,"evidence/"+name)
for name in ["phase-01-design.png","candidate3-pending-en.png","candidate3-retained-note-zh.png","candidate3-optional-labels-fixture.png","v2-final-JPEG-rejected.png","v2-final-no-JPEG-message.png","v2-final-PNG-review.png","v2-final-public.png","v2-final-replay-completed.png"]:
    copy("review/screenshots/"+name,"screenshots/"+name)
copy("review/screenshots/v2-final-JPEG-rejected.png","v2-JPEG-rejected.png")
results=json.loads((root/"review/source-reproduction/results.json").read_text())
assert all(r["normal_gate_passed"] and r["actual_execution"]["application_and_observer_started"] for r in results)
write("SOURCE-REPRODUCTION.md",r"""# Redacted source reproduction

| Package | Actual isolated execution | Normal gate |
| --- | --- | --- |
| [v1 source](gallery-v1-source.zip) | App and observer initialize; current source binding; JPEG accepted; PNG approval becomes public | Exit 0 |
| [v2 source](gallery-v2-source.zip) | App and observer initialize; current source binding; JPEG rejected with zero rows/messages; PNG approval becomes public | Exit 0 |

Each archive was extracted into a separate work/.validation directory and executed
using the installed local Python 3.12 environment. Both CLI normal gates and actual
application effects were checked. This is actual fresh-source execution, not a
fresh network dependency installation. The complete original v1/v2 validation
reports retain their original root and scope. Raw reproduction argv, paths, exit
codes, stdout and stderr are in review/source-reproduction in the evidence ZIP.

Exact files, sizes and SHA256:
[v1 manifest](gallery-v1-source.zip.manifest.json),
[v2 manifest](gallery-v2-source.zip.manifest.json).
Both contain the same 144 byte-verified candidate-3 Skill files and locked
dependencies. Requirements lock is the actual installed environment snapshot;
JavaScript adapter package-lock.json files are retained. Synthetic PNG/JPEG
images are under work/browser-fixtures. No node_modules, virtual environment,
Git data, runtime database, runtime session/collector token state, personal view
configuration or raw personal-preference payload is included. No frozen Skill
file is changed to redact a runtime secret; runtime private state is excluded.

From a separate extracted directory on Windows:

```powershell
New-Item -ItemType Directory -Force work/tmp | Out-Null
$env:TMP = (Resolve-Path work/tmp).Path
$env:TEMP = $env:TMP
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.lock
.\.venv\Scripts\python.exe -B run.py --port 8845 --database work/reproduced.sqlite
```

The launcher prints both actual URLs. Use another free port if needed; the
delivered instance already uses 8842. Demo accounts are documented in README.md.
The extracted source starts with fresh local runtime data. Existing personal
configuration is not required. `test_app.py` runs project tests;
`validate.py` executes the ordinary synchronization gate.

To repeat the old cookie collision independently, the evidence ZIP contains the
byte-verified gallery-core-v2-before-cookie.zip and current probe source/argv.
The bounded before/after records contain statuses and paths, never cookie values.
Historical F06 remains unproven as a specific occurrence of this mechanism.
""")
write("REVIEW-INDEX.md",f"""# Gallery trial review: business v1, business v2, Skill candidate 3

The PNG-only iteration and bounded session-isolation repair are complete within
the declared trial scope. Original Chinese dialogue, failures and screenshots
are retained. Simulated test-role clarification is not human usability evidence.

| Result | Business v1 | Final business v2 |
| --- | --- | --- |
| Accepted formats | Actual PNG / JPEG | Actual PNG only; JPEG and other non-PNG rejected without notification |
| Implementation mapping | Passed; 38 witnesses, 126 projections, 18 features | Passed; 44 witnesses, 132 projections, 18 features |
| State constraints | Passed | Passed |
| Business rules | 135/135 on/off/fault assertions | 162/162 on/off/fault assertions |
| Project checks | 11 tests and architecture passed | 13 tests and architecture passed |
| Browser | Actual operation, 37 events, 2 frames, no gaps; locale and note/layout checks | JPEG rejection + empty reviewer inbox + PNG review/publication; 58 events, 2 frames, no gaps; actual replay reaches 4/4 |

All 45 original assertions, 60 node IDs, state IDs and capture schemas are retained.
Nine assertions are added for the explicitly confirmed PNG-only change. The legacy
reviewer-rejection case ID is documented; its v2 upload fixture is PNG. Skill
candidate 3 is the observer distribution used for both business versions, not a
business version. Its 144 frozen files remain unchanged.

## Review entrypoints

- [V1 accepted review](V1-REVIEW.md)
- [V2 final review and cookie-isolation evidence](V2-REVIEW.md)
- [V2 pre-cookie passing checkpoint](V2-BEFORE-COOKIE-REVIEW.md)
- [Actual dialogue and provenance](ACTUAL-DIALOGUE-INDEX.md)
- [Failure / repair / retest index](FAILURE-RETEST-INDEX.md)
- [Source reproduction results and instructions](SOURCE-REPRODUCTION.md)

## Download and inspect

- [V1 reproducible source](gallery-v1-source.zip) and [exact file manifest](gallery-v1-source.zip.manifest.json)
- [V2 reproducible source](gallery-v2-source.zip) and [exact file manifest](gallery-v2-source.zip.manifest.json)
- [Redacted review evidence ZIP](gallery-review-evidence.zip) and [evidence manifest](review-evidence.manifest.json)
- [V1 four reports](evidence/v1-four-reports.json), [V2 final four reports](evidence/v2-final-four-reports.json)
- [Actual final recording](evidence/v2-final-browser-recording.json), [independent final SQL](evidence/v2-final-independent-sql.json)
- [Stable IDs / parameters / source analysis](evidence/stable-id-and-source-analysis.json)
- [Complete v1 graph export](gallery-stategraph-v1.json), [complete final v2 graph export](gallery-stategraph-v2-final.json)

Both source archives were actually extracted and executed, with application and
observer available, correct format-specific effects and normal gate exit 0.
They exclude runtime databases, token state, personal configuration and node_modules;
they retain synthetic images and dependency locks. Raw preference configurations
remain local; bounded layout/note results and screenshots remain reviewable.

## Live final build

[Application](http://127.0.0.1:8842/) · [Developer graph](http://127.0.0.1:8842/graph)

Build: `{build}`.
Candidate: `{v2['candidate_id']}`.
Project: `C:/Users/Lvi_P/Documents/Codex/2026-10-23/business-observer-gallery-python`.
The launcher is `python -B run.py --port 8842 --database work/gallery-v2-final-candidate3.sqlite`.
It prints both URLs and owns only its own server/observer threads.

## Key visual evidence

- [Initial design pending clarification](screenshots/phase-01-design.png)
- [V1 business label versus raw parameter](screenshots/candidate3-pending-en.png)
- [V1 retained Chinese note](screenshots/candidate3-retained-note-zh.png)
- [Optional-label fallback, explicitly derived display fixture](screenshots/candidate3-optional-labels-fixture.png)
- [Final JPEG rejection](screenshots/v2-final-JPEG-rejected.png)
- [Final no-JPEG-message inbox](screenshots/v2-final-no-JPEG-message.png)
- [Final PNG awaiting review](screenshots/v2-final-PNG-review.png)
- [Final public PNG](screenshots/v2-final-public.png)
- [Final actual replay completed](screenshots/v2-final-replay-completed.png)

## Skill origin and limits

Frozen source is the supplied SoftwareStatusObserverSkill/.validation/gallery-trials/
candidate-3/business-observer; project copy .agents/skills/business-observer-candidate-3.
Sibling manifest SHA256:
`fd022e1377b17e2679a8e1e8e0b9cbba51d1bb41c2f4af017383cc7dab1ccb8c`.
All 144 file hashes match. Candidate 3 fixes contextual business/activity/raw
labels, optional-label fallback, and partial-frame documentation; it was not
patched during this business iteration. Earlier candidate 1/2 failures remain
historical evidence, not rewritten passes.

The same-host cookie-collision mechanism is reproduced before repair and passes
after the project-specific session namespace. Historical F06's particular cause
cannot be traced from its retained data. No known blocker remains within this
finite gallery trial. The full Skill repository suite and human usability study
were not run. No approval is pending. Nothing is published to GitHub.
""")
copy("outputs/REVIEW-INDEX.md","FINAL-REPORT.md")
summary={"v1":json.loads((out/"v1-final-assessment.json").read_text(encoding="utf-8")),"v2_final":v2,"cookie_mechanism":{"before_status":400,"after_status":200,"historical_F06_root_cause":"not established"},"source_reproduction":results,"entrypoint":"REVIEW-INDEX.md","no_pending_approval":True,"no_github_publication":True}
write("final-assessment.json",json.dumps(summary,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"review_entry":"outputs/REVIEW-INDEX.md","v2_build":build,"v2_tests":v2["project_tests"],"source_reproduction":"both passed"}))
