"""Authoritative gallery behavior and transactional SQLite storage."""
import hashlib
from io import BytesIO
import sqlite3
import uuid
from PIL import Image, UnidentifiedImageError
from werkzeug.security import check_password_hash, generate_password_hash
from bo_stategraph.workflow import GalleryMachine
from .ports import BOPort

class DomainError(Exception):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status

class Gallery:
    def __init__(self, database, project, bo=None, build_id="core"):
        self.database = str(database)
        self.machine = GalleryMachine(project)
        self.bo = bo or BOPort()
        self.build_id = build_id
        self.initialize()

    def connect(self):
        db = sqlite3.connect(self.database, timeout=10)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def initialize(self):
        with self.connect() as db:
            db.executescript("""
            CREATE TABLE IF NOT EXISTS accounts(username TEXT PRIMARY KEY, role TEXT NOT NULL, password_hash TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS images(id TEXT PRIMARY KEY, uploader TEXT NOT NULL, filename TEXT NOT NULL,
                format TEXT NOT NULL, width INTEGER NOT NULL, height INTEGER NOT NULL, sha256 TEXT NOT NULL,
                body BLOB NOT NULL, state TEXT NOT NULL, revision INTEGER NOT NULL, build_id TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY, recipient TEXT NOT NULL, image_id TEXT NOT NULL UNIQUE REFERENCES images(id));
            CREATE TABLE IF NOT EXISTS journal(seq INTEGER PRIMARY KEY AUTOINCREMENT, image_id TEXT NOT NULL,
                event TEXT NOT NULL, previous TEXT NOT NULL, state TEXT NOT NULL, revision INTEGER NOT NULL);
            """)
            for username, role, password in [("uploader", "uploader", "upload-demo-2026"), ("reviewer", "reviewer", "review-demo-2026")]:
                if not db.execute("SELECT 1 FROM accounts WHERE username=?", (username,)).fetchone():
                    db.execute("INSERT INTO accounts VALUES(?,?,?)", (username, role, generate_password_hash(password)))

    def login(self, username: str, password: str) -> dict:
        with self.connect() as db:
            row = db.execute("SELECT * FROM accounts WHERE username=?", (username,)).fetchone()
        allowed = bool(row and check_password_hash(row["password_hash"], password))
        result = {"authenticated": allowed, "role": row["role"] if allowed else ""}
        self.bo.record("login", "return", {"username": username[:100], "password_present": bool(password)}, result)
        if not allowed: raise DomainError(401, "Invalid credentials")
        return {"username": username, "role": row["role"]}

    def authorize(self, actor: str, required: str) -> str:
        with self.connect() as db:
            row = db.execute("SELECT role FROM accounts WHERE username=?", (actor or "",)).fetchone()
        role = row["role"] if row else ""
        allowed = role == required
        self.bo.record("authorize", "return", {"actor": actor or "", "required": required}, {"role": role, "allowed": allowed})
        if not allowed: raise DomainError(403 if row else 401, "Role does not permit this action")
        return role

    def inspect_image(self, data: bytes) -> dict:
        result = {"valid": False, "format": "", "width": 0, "height": 0}
        try:
            with Image.open(BytesIO(data)) as image:
                detected = image.format or ""
                image.verify()
            with Image.open(BytesIO(data)) as image:
                image.load()
                width, height = image.size
            result = {"valid": detected == "PNG", "format": detected, "width": width, "height": height}
        except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError):
            pass
        self.bo.record("image_check", "return", {"byte_count": len(data)}, result)
        return result

    def notify(self, db, image_id: str) -> str:
        message_id = uuid.uuid4().hex
        db.execute("INSERT INTO messages VALUES(?,?,?)", (message_id, "reviewer", image_id))
        return message_id

    def upload(self, actor: str, filename: str, data: bytes) -> dict:
        role = self.authorize(actor, "uploader")
        checked = self.inspect_image(data)
        if not checked["valid"]:
            self.bo.record("invalid_file", "reject", {"format": checked["format"]}, {"status": 415, "created": False})
            raise DomainError(415, "Only actual PNG images are accepted")
        ident = uuid.uuid4().hex
        context = {"format": checked["format"], "uploader": actor}
        change = self.machine.transition(self.machine.definition["initial"], "submit", context, {"role": role})
        digest = hashlib.sha256(data).hexdigest()
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT INTO images VALUES(?,?,?,?,?,?,?,?,?,?,?)", (ident, actor, filename[:180], checked["format"], checked["width"], checked["height"], digest, data, change["state"], 1, self.build_id))
            message_id = self.notify(db, ident)
            db.execute("INSERT INTO journal(image_id,event,previous,state,revision) VALUES(?,?,?,?,?)", (ident, "submit", change["before"], change["state"], 1))
        event_id = self.bo.record("upload", "commit", {"actor": actor, "filename": filename[:180], "byte_count": len(data)}, {"id": ident, "state": change["state"], "revision": 1, "sha256": digest}, ident)
        self.bo.record("message", "commit", {"image_id": ident}, {"recipient": "reviewer", "message_id": message_id}, ident, ((event_id, "flow"),))
        return {"id": ident, "state": change["state"]}

    def review(self, actor: str, image_id: str, decision: str) -> dict:
        role = self.authorize(actor, "reviewer")
        if decision not in {"approve", "reject"}: raise DomainError(400, "Unknown review decision")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT * FROM images WHERE id=?", (image_id,)).fetchone()
            if row is None: raise DomainError(404, "Image not found")
            try:
                change = self.machine.transition(row["state"], decision, {"format": row["format"], "uploader": row["uploader"]}, {"role": role})
            except ValueError as exc:
                raise DomainError(409, "Image is no longer pending") from exc
            revision = row["revision"] + 1
            db.execute("UPDATE images SET state=?,revision=?,build_id=? WHERE id=?", (change["state"], revision, self.build_id, image_id))
            db.execute("INSERT INTO journal(image_id,event,previous,state,revision) VALUES(?,?,?,?,?)", (image_id, decision, row["state"], change["state"], revision))
        self.bo.record("review", "commit", {"actor": actor, "image_id": image_id, "decision": decision}, {"before": row["state"], "state": change["state"], "revision": revision, "reviewer_guard": change["guards"]["reviewer"]}, image_id)
        return {"id": image_id, "state": change["state"]}

    def messages(self, actor: str) -> list:
        self.authorize(actor, "reviewer")
        with self.connect() as db:
            result = [dict(row) for row in db.execute("SELECT m.id AS message_id,m.recipient,i.id,i.filename,i.format,i.state FROM messages m JOIN images i ON i.id=m.image_id WHERE m.recipient=? ORDER BY m.rowid DESC", (actor,))]
        self.bo.record("messages", "return", {"actor": actor}, {"count": len(result)})
        return result

    def exhibition(self) -> list:
        with self.connect() as db:
            result = [dict(row) for row in db.execute("SELECT id,filename,format,width,height FROM images WHERE state IN ('pending','published') ORDER BY rowid DESC")]
        self.bo.record("exhibition", "return", {}, {"count": len(result)})
        return result

    def image(self, image_id: str, actor: str) -> tuple:
        with self.connect() as db:
            row = db.execute("SELECT body,format,state FROM images WHERE id=?", (image_id,)).fetchone()
        if row is None: raise DomainError(404, "Image not found")
        if row["state"] != "published":
            try: self.authorize(actor, "reviewer")
            except DomainError as exc: raise DomainError(404, "Image not found") from exc
        self.bo.record("image", "return", {"image_id": image_id, "actor": actor or ""}, {"format": row["format"], "byte_count": len(row["body"])}, image_id)
        return row["body"], "image/png" if row["format"] == "PNG" else "image/jpeg"
