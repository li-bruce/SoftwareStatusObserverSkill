"""Independent application, state, observer isolation, and architecture checks."""
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import sqlite3
import threading
import unittest
import uuid
from app.service import Gallery,DomainError
from app.web import create_app
from app.ports import BOPort
from bo_observe import image_bytes,execute_case,sql_snapshot,login,upload,session_csrf
from integrations.bo_adapter import BOAdapter
from integrations.bo_web import bo_attach

ROOT=Path(__file__).resolve().parent

class GalleryChecks(unittest.TestCase):
    def setUp(self):
        self.folder=ROOT/"work/tests"/uuid.uuid4().hex
        self.folder.mkdir(parents=True)
        self.database=self.folder/"gallery.sqlite"

    def test_confirmed_effects_and_observer_failure_isolation(self):
        expected=json.loads((ROOT/"review/v2/independent-expectations-before-implementation.json").read_text(encoding="utf-8"))
        for case,fields in expected.items():
            for mode in ["on","off","fault"]:
                with self.subTest(case=case,mode=mode):
                    run,_,_=execute_case(case,mode,self.folder)
                    for key,value in fields.items(): self.assertEqual(run["observations"][key],value)
                    if mode in {"off","fault"}: self.assertEqual(run["events"],[])
                    if mode=="fault": self.assertGreater(run["port_errors"],0)

    def test_real_concurrent_review_serializes_one_decision(self):
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json")
        ident=service.upload("uploader","test.png",image_bytes())["id"]
        barrier=threading.Barrier(2)
        def review(decision):
            barrier.wait()
            try: return service.review("reviewer",ident,decision)["state"]
            except DomainError as exc: return exc.status
        with ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(review,["approve","reject"]))
        self.assertEqual(sum(x==409 for x in results),1)
        self.assertEqual(sql_snapshot(self.database)[0][0]["revision"],2)
        with sqlite3.connect(self.database) as db: self.assertEqual(db.execute("SELECT COUNT(*) FROM journal").fetchone()[0],2)

    def test_png_only_rejects_jpeg_before_effects_and_at_drive_guard(self):
        adapter=BOAdapter(ROOT,self.database,recording_dir=self.folder/"recordings")
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json",adapter.port,adapter.build_id)
        try:
            before=sql_snapshot(self.database)
            for filename in ["photo.jpg","pretend.png"]:
                with self.assertRaises(DomainError) as rejected:
                    service.upload("uploader",filename,image_bytes("JPEG"))
                self.assertEqual(rejected.exception.status,415)
                self.assertEqual(sql_snapshot(self.database),before)
            with self.assertRaisesRegex(ValueError,"No enabled transition"):
                service.machine.transition("unsubmitted","submit",{"format":"JPEG","uploader":"uploader"},{"role":"uploader"})
            adapter.pins.flush()
            events=adapter.history.snapshot()
            decoded=[e for e in events if e["node"]=="image_check"]
            self.assertEqual(len(decoded),2)
            self.assertTrue(all(e["outputs"]["format"]=="JPEG" and e["outputs"]["valid"] is False for e in decoded))
            self.assertFalse(any(e["node"] in {"upload","message"} and e["phase"]=="commit" for e in events))
        finally: adapter.bo_close()

    def test_other_local_app_session_does_not_invalidate_gallery_form(self):
        from tooling.cookie_isolation_probe import run_cookie_probe
        result=run_cookie_probe(self.folder/"actual-http")
        self.assertEqual(result["control_status"],200)
        self.assertEqual(result["after_other_app_status"],200)
        self.assertEqual(result["after_other_app_final_path"],"/upload")
        self.assertFalse(result["same_cookie_namespace"])
        self.assertEqual(result["independent_sql_counts"],{"images":0,"messages":0})

    def test_content_does_not_follow_filename_and_truncation_rejects(self):
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json")
        service.upload("uploader","notes.txt",image_bytes())
        before=sql_snapshot(self.database)
        with self.assertRaises(DomainError) as rejected: service.upload("uploader","broken.png",image_bytes()[:24])
        self.assertEqual(rejected.exception.status,415)
        self.assertEqual(sql_snapshot(self.database),before)

    def test_observer_controls_do_not_emit_business_events(self):
        adapter=BOAdapter(ROOT,self.database,recording_dir=self.folder/"recordings")
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json",adapter.port,adapter.build_id)
        app=create_app(service);bo_attach(app,adapter,ROOT);client=app.test_client()
        try:
            login(client,"uploader");upload(client)
            adapter.pins.flush();before=len(adapter.history.snapshot())
            configuration=client.get("/api/view").get_json()["machine"]["configurations"][0]
            self.assertIsInstance(configuration["journal"],list)
            self.assertEqual(configuration["param_version"],1)
            view=client.get("/api/view").get_json()
            self.assertTrue(set(view["model"]["machine"]["values"]) <= set(view["model"]["machine"]["labels"]))
            for path in ["/graph","/api/view","/api/design","/api/source?path=app/service.py","/api/preferences","/api/stategraph/export"]:
                self.assertEqual(client.get(path).status_code,200)
            prefs=client.get("/api/preferences").get_json()
            self.assertEqual(client.post("/api/preferences",json=prefs).status_code,200)
            response=client.post("/api/recordings/start",json={})
            self.assertEqual(response.status_code,200)
            record_id=response.get_json()["id"]
            self.assertEqual(client.post("/api/recordings/stop",json={}).status_code,200)
            saved=client.get("/api/recordings/"+record_id).get_json()
            self.assertEqual(saved["events"],[])
            adapter.pins.flush();self.assertEqual(len(adapter.history.snapshot()),before)
            adapter.recordings.start("actual commit")
            ident=service.upload("uploader","second.png",image_bytes())["id"]
            service.review("reviewer",ident,"approve")
            adapter.pins.flush();summary=adapter.recordings.stop();record=adapter.recordings.get(summary["id"])
            self.assertTrue(record["runtime_frames"]["frames"])
            phases=[f["machine"]["configurations"][0]["phase"] for f in record["runtime_frames"]["frames"]]
            self.assertIn("pending",phases);self.assertIn("published",phases)
            self.assertEqual([f["machine"]["current"] for f in record["runtime_frames"]["frames"]],phases)
            self.assertEqual(record["gaps"],[],"Ordinary calls do not require state snapshots")
            from copy import deepcopy
            from observer_runtime.recording_session import Recordings
            negative=deepcopy(record)
            negative.update(id=uuid.uuid4().hex,label="Negative checker fixture: intentionally omitted actual state frame")
            negative["runtime_frames"]["frames"]=negative["runtime_frames"]["frames"][:-1]
            checker=Recordings(self.folder/"negative-recordings",adapter.bo_view,{})
            try:
                checker._save(negative)
                self.assertTrue(any("runtime snapshot" in gap for gap in negative["gaps"]))
            finally: checker.close()
        finally: adapter.bo_close()

    def test_web_hidden_disabled_and_business_survives(self):
        adapter=BOAdapter(ROOT,self.database,recording_dir=self.folder/"recordings")
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json",adapter.port,adapter.build_id)
        app=create_app(service);bo_attach(app,adapter,ROOT);client=app.test_client()
        web=app.config["BO_WEB"]
        try:
            web.set_mode("hidden")
            self.assertIn(b"data-bo-entry hidden",client.get("/").data)
            self.assertEqual(client.get("/graph").status_code,200)
            web.set_mode("disabled")
            for path in ["/graph","/api/view","/api/source","/api/preferences","/api/recordings","/api/stategraph/export"]: self.assertEqual(client.get(path).status_code,404)
            self.assertEqual(service.upload("uploader","alive.png",image_bytes())["state"],"pending")
        finally: web.set_mode("visible");adapter.bo_close()

    def test_bounded_queue_and_payload_builder_failure_leave_business_unchanged(self):
        gate=threading.Event()
        adapter=BOAdapter(ROOT,self.database,capacity=1,recording_dir=self.folder/"recordings")
        original=adapter.pins.sink
        def slow_sink(text): gate.wait(2);original(text)
        adapter.pins.sink=slow_sink
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json",adapter.port,adapter.build_id)
        try:
            service.upload("uploader","queue.png",image_bytes())
            self.assertEqual(len(sql_snapshot(self.database)[0]),1)
            self.assertGreater(adapter.pins.health()["dropped"],0)
            service.bo=BOPort(lambda *args: (_ for _ in ()).throw(ValueError("Injected capture construction failure")))
            self.assertEqual(service.upload("uploader","builder.png",image_bytes())["state"],"pending")
            self.assertGreater(service.bo.errors,0)
        finally: gate.set();adapter.bo_close()

    def test_invalid_declaration_and_invalid_actual_state_are_not_normalized(self):
        from bo_stategraph import BOStateGraph
        from bo_stategraph.workflow import GalleryMachine
        doc=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))
        doc["model"]["machine"]["transitions"][0]["before"]="unsupported callback"
        invalid=self.folder/"invalid.json";invalid.write_text(json.dumps(doc),encoding="utf-8")
        with self.assertRaises(ValueError): GalleryMachine(invalid)
        original=json.loads((ROOT/"bo_stategraph/project.json").read_text(encoding="utf-8"))["model"]
        graph=BOStateGraph(original,build_id="test",mode="drive")
        items=graph.bo_instances({"configurations":[{"attempt":"bad","phase":"made_up","state_revision":1,"run_build_id":"test","context":{"format":"PNG","uploader":"uploader"}}]})
        self.assertEqual(items[0]["observed"]["state"],"made_up")
        self.assertEqual(items[0]["status"],"mismatch")

    def test_actual_callback_and_guard_bindings(self):
        import app.web as web
        from bo_stategraph.workflow import GalleryMachine
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json")
        app=create_app(service)
        with app.app_context(): self.assertIs(web.gallery_service(),service)
        for name in ["login_action","upload_action","review_action","messages_page","image_content","exhibition_page"]:
            self.assertIs(app.view_functions["business."+name],getattr(web,name))
        self.assertIs(service.machine.guards["reviewer"].__func__,GalleryMachine.is_reviewer)
        self.assertIs(service.machine.guards["uploader"].__func__,GalleryMachine.is_uploader)
        self.assertIs(service.machine.guards["content"].__func__,GalleryMachine.valid_content)

    def test_core_application_has_no_debug_entry(self):
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json")
        client=create_app(service).test_client()
        self.assertNotIn(b"data-bo-entry",client.get("/").data)
        self.assertEqual(client.get("/graph").status_code,404)
        self.assertEqual(service.upload("uploader","core.png",image_bytes())["state"],"pending")

    def test_observer_startup_failure_keeps_business_available(self):
        from unittest.mock import patch
        from run import build_application
        with patch("integrations.bo_adapter.BOAdapter",side_effect=OSError("Injected observer startup failure")):
            app,service,adapter=build_application(ROOT,self.database)
        self.assertIsNone(adapter)
        self.assertEqual(app.test_client().get("/").status_code,200)
        self.assertEqual(service.upload("uploader","fallback.png",image_bytes())["state"],"pending")

    def test_broken_observer_web_config_preserves_business_response(self):
        adapter=BOAdapter(ROOT,self.database,recording_dir=self.folder/"recordings")
        service=Gallery(self.database,ROOT/"bo_stategraph/project.json",adapter.port,adapter.build_id)
        app=create_app(service);bo_attach(app,adapter,ROOT)
        app.config["BO_WEB"].config=self.folder/"broken-web.json"
        app.config["BO_WEB"].config.write_text('{"mode":"broken"}',encoding="utf-8")
        try:
            self.assertEqual(app.test_client().get("/").status_code,200)
            self.assertEqual(app.test_client().get("/graph").status_code,503)
            self.assertEqual(service.upload("uploader","alive.png",image_bytes())["state"],"pending")
        finally: adapter.bo_close()

if __name__=="__main__": unittest.main(verbosity=2)
