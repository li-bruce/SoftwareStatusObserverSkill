# 独立画展试用

[English](README.md)

项目路径：`C:\Users\Lvi_P\Documents\Codex\2026-10-23\business-observer-gallery-python`。

在项目目录运行下面一个命令，同时启动业务页面和运行图，并打印实际地址：

```powershell
.\.venv\Scripts\python.exe -B run.py --port 8842 --database work/gallery-v2-candidate3.sqlite
```

已有服务运行时直接访问其地址。Ctrl+C 只关闭本命令自己的服务和观测线程。
观测初始化失败时，业务仍会启动，并明确提示图不可用；`--core` 可单独运行业务。

上传者：`uploader / upload-demo-2026`；审核者：`reviewer / review-demo-2026`。
画展公开访问。程序按实际内容检查 PNG；不符合的文件不保存、不通知。
合格上传进入待审核并生成站内消息，审核通过后才公开展示，驳回不展示。
本轮没有注册、找回密码、邮件、修改、删除或重新提交；HTTP 上传上限为 16 MiB。

图中的语言切换仅改变界面文案；节点 ID、业务状态、用户批注和历史证据保持原样。
正常开发验收入口为 `.\.venv\Scripts\python.exe -B validate.py`。
原始需求、明确标记的模拟回答、各项检查和浏览器证据均保存在 `review/`。
本试用不是人类易用性测试。

