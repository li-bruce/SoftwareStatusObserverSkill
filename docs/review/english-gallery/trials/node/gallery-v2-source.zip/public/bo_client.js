// Forward only selected, actually observed frontend inputs and results.
export function bo_ui(node,inputs,outputs) {
  fetch('/api/bo/ui',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({node,inputs,outputs})}).catch(()=>{});
}
