"""Launch both services and clean up exactly the children created by this run."""
import json,os,signal,socket,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    os.chdir(ROOT)
    if '--stop' in sys.argv:
        info=json.loads((ROOT/'.stategraph/dev.json').read_text(encoding='utf-8'))
        if info['status']=='running':(ROOT/f".stategraph/stop-{info['pids']['launcher']}").write_text('stop',encoding='utf-8')
        return
    subprocess.run([sys.executable,'tooling/build_model.py'],check=True)
    env={**os.environ,'PYTHONIOENCODING':'utf-8','PYTHONUTF8':'1','PYTHONPATH':str(ROOT/'work/python-packages')}
    with socket.socket() as reservation:reservation.bind(('127.0.0.1',0));app_port=reservation.getsockname()[1]
    env['APP_ORIGIN']=f'http://127.0.0.1:{app_port}'
    processes=[]
    logs=ROOT/'review/live';logs.mkdir(parents=True,exist_ok=True)
    try:
        observer_log=(logs/'observer.stderr.log').open('w',encoding='utf-8')
        observer=subprocess.Popen([sys.executable,'-u','integrations/bo_service.py'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=observer_log,text=True,encoding='utf-8');processes.append(observer)
        line=observer.stdout.readline()
        if line:
            settings=json.loads(line);collector=json.loads((ROOT/'.stategraph/collector.json').read_text(encoding='utf-8'))
        else:
            print('Observer failed to start; continuing native application.',flush=True)
            collector={'endpoint':'http://127.0.0.1:1','token':'','build_id':json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))['build_id']}
            settings={'url':collector['endpoint']}
        appenv={**env,'BO_ENDPOINT':collector['endpoint'],'BO_TOKEN':collector['token'],'BO_BUILD':collector['build_id'],'GALLERY_GRAPH':collector['endpoint']+'/graph' if line else '', 'PORT':str(app_port)}
        app_log=(logs/'app.stderr.log').open('w',encoding='utf-8')
        app=subprocess.Popen(['node','app/server.mjs'],cwd=ROOT,env=appenv,stdout=subprocess.PIPE,stderr=app_log,text=True,encoding='utf-8');processes.append(app)
        ready=json.loads(app.stdout.readline())
        info={'application':ready['url'],'graph':settings['url']+'/graph','build_id':collector['build_id'],'pids':{'launcher':os.getpid(),'application':app.pid,'observer':observer.pid},'status':'running'}
        (ROOT/'.stategraph/dev.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
        print('Application: '+info['application'],flush=True);print('Observer: '+info['graph'],flush=True)
        print('Press Ctrl+C to stop both services. Observer failure leaves the application running.',flush=True)
        def stop(*_):raise KeyboardInterrupt
        signal.signal(signal.SIGTERM,stop)
        while app.poll() is None:
            if (ROOT/f'.stategraph/stop-{os.getpid()}').exists():raise KeyboardInterrupt
            if observer.poll() is not None and info.get('observer_exit') is None:
                info['observer_exit']=observer.returncode;print('Observer unavailable; application remains running.',flush=True)
            time.sleep(.2)
    except KeyboardInterrupt:pass
    finally:
        for process in reversed(processes):
            if process.poll() is None:process.terminate()
        for process in processes:
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill();process.wait()
        if (ROOT/'.stategraph/dev.json').exists():
            info=json.loads((ROOT/'.stategraph/dev.json').read_text(encoding='utf-8'));info.update(status='stopped',exit_codes={str(p.pid):p.returncode for p in processes});(ROOT/'.stategraph/dev.json').write_text(json.dumps(info,indent=2),encoding='utf-8')

if __name__=='__main__':main()
