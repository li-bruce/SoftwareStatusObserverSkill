"""Create a secret-free source package and evidence review entrypoints."""
import hashlib,json,shutil,zipfile
from pathlib import Path
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'outputs'
def read(path):return json.loads((ROOT/path).read_text(encoding='utf-8'))
def write(path,value):(ROOT/path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def get(url):
    with urlopen(url,timeout=8) as response:return json.load(response)
dev=read('.stategraph/dev.json');base=dev['graph'].removesuffix('/graph');view=get(base+'/api/view')
accepted=read('review/changes/png-only-v2/accepted.json');verification=read('review/changes/png-only-v2/verification.json');audit=read('review/v2/browser-audit.json')
assert view['binding_status']['status']=='current' and dev['build_id']==view['manifest']['build_id']==accepted['build_id']
assert len(view['events'])==audit['event_count_before_controls']
record=read('review/v2/browser-recording.json');raw=read('data/store.json')
jpeg_event=next(e for e in record['events'] if e['node']=='image_check' and e['outputs']['original_format']=='jpeg')
jpeg=next(i for i in raw['images'] if i['id']==jpeg_event['entity'])
assert jpeg['readable'] and not jpeg['accepted'] and jpeg['state']=='invalid_file'
assert not any(m['image_id']==jpeg['id'] for m in raw['messages'])
assert not (ROOT/'data/images'/(jpeg['id']+'.png')).exists()
write('review/v2/final-live-check.json',{'build_matches_accepted':True,'build_id':dev['build_id'],'binding':'current','viewer_events_before':audit['event_count_before_controls'],'viewer_events_after':len(view['events']),'viewer_events_added':0,'actual_gui_jpeg_no_notification':True,'actual_gui_jpeg_no_saved_image':True,'health':view['health'],'urls':{'application':dev['application'],'graph':dev['graph']}})
for name in ['accepted.json','verification.json','review.json','baseline.json']:
    shutil.copyfile(ROOT/'review/changes/png-only-v2'/name,ROOT/'review/v2'/name)
for name in ['intent.json','discovery.json','manifest.json','acceptance.json','mapping.json','whitebox.json']:
    shutil.copyfile(ROOT/name,ROOT/'review/v2'/name)
write('outputs/check-results.json',{'skill':'candidate-3','application_v1':read('review/v1/c3-verification.json')['reports'],'application_v2':verification['reports'],'v1_browser':read('review/v1/browser-audit.json'),'v2_browser':audit,'v2_live':read('review/v2/final-live-check.json')})
shutil.copyfile(ROOT/'review/coordinator-messages-verbatim.json',OUT/'coordinator-messages-verbatim.json')
# Exact current source; no dependency trees, runtime stores, sessions or personal view settings.
files=set()
for directory in ['app','bo_stategraph','integrations','public','observer_runtime','observer_generated','tooling','scripts','fixtures','vendor/business-observer-candidate-3']:
    for path in (ROOT/directory).rglob('*'):
        if path.is_file() and not set(path.relative_to(ROOT).parts)&{'node_modules','__pycache__','config'} and path.suffix not in {'.pyc','.db','.sqlite','.sqlite3','.log'}:files.add(path)
for name in ['package.json','package-lock.json','sync.json','intent.json','discovery.json','acceptance.json','mapping.json','implementation.json','reconciliation.json','whitebox.json','ownership.json','manifest.json','AGENTS.md','README.md','.stategraph/active.json']:
    files.add(ROOT/name)
files.update((ROOT/'review').glob('frozen-*.json'))
files.add(ROOT/'review/scenarios-source-hashes.json')
for change in ['initial-implementation','causal-capture-iteration','png-only-v2']:
    for name in ['baseline.json','review.json','verification.json','accepted.json']:
        path=ROOT/'review/changes'/change/name
        if path.exists():files.add(path)
rows=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(files)]
assert not any('/node_modules/' in x['path'] or x['path'].startswith('data/') or x['path'].endswith('collector.json') or '/config/views/' in x['path'] for x in rows)
write('outputs/source-files.json',{'application':'v2','candidate_id':accepted['candidate_id'],'build_id':accepted['build_id'],'excluded':['node_modules','runtime databases and store.json','session state','collector token','personal views/config','old test data directories'],'files':rows})
archive=OUT/'gallery-v2-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as package:
    for path in sorted(files):package.write(path,path.relative_to(ROOT).as_posix())
write('outputs/source-package-sha256.json',{'file':archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(rows)})
print(json.dumps({'source_package':str(archive),'files':len(rows),'build':accepted['build_id'],'all_four_categories':{k:v['status'] for k,v in verification['reports'].items()},'gui_jpeg_no_notification':True,'viewer_controls_added':0}))
