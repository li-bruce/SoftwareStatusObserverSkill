"""Bind the explicit implementation review to the current active candidate."""
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'observer_runtime'),str(ROOT/'work/python-packages')]
from bo_observer.workflow.sync_config import config,snapshot
cfg=config(ROOT,'sync.json');current=snapshot(ROOT,cfg)
plan=current['model']['implementation']
review={'candidate_id':current['id'],'decisions':{
    'business':{'action':'unchanged','reason':'Preserve confirmed drive, mutual account review, real decoding, no invalid-file notification and public approved exhibition.'},
    'state_machine':{'action':'updated','reason':'Flat native declaration is consumed by the actual Node.js BOExecutor; exact guards are source-bound.'},
    'abstraction':{'action':'updated','reason':'Source-first inventory maps every application and frontend feature; helper functions remain inspectable.'},
    'probes':{'action':'updated','reason':'Selected native inputs/results, actual committed state revisions and snapshots; frontend event values use an excluded transport.'}},
    'excluded_symbols':{sid:'Neutral optional observation infrastructure; category observer in implementation plan; never a business event.' for sid in plan['excluded']},
    'requirement_changes':{},
    'baseline_timing_note':'Initial begin failed twice due scaffold omissions. The first code batch predates the first successful begin; its tool outputs and source snapshots are retained. No active baseline was replaced.',
    'candidate_upgrade':'Candidate-1 remains frozen; candidate-2 was copied separately at explicit coordinator direction. Original business answers and tests retained.'}
change=json.loads((ROOT/'.stategraph/active.json').read_text(encoding='utf-8'))['change']
if change.endswith('png-only-v2'):
    review['decisions']['business']={'action':'updated','reason':'Only R2 changes under the explicitly simulated PNG-only request U_v2_simulated; real account mutual-review answers are preserved.'}
    review['requirement_changes']={'R2':'Explicit simulated format-only change; original checks retained and JPEG/content/no-notification counterexamples added. See review/coordinator-messages-verbatim.json, exec-98d9f3c8-5e53-459d-b754-94e83fdefdd1.'}
    review['candidate_upgrade']='Application v2 uses the unchanged frozen Skill candidate-3 public installation. Skill candidate-1/2 originals remain archived.'
    review['excluded_symbols'].update({sid:'Existing source-inventoried support symbol; exact implementation plan disposition retained; no feature or capture removed.' for sid in plan['support']})
(ROOT/change/'review.json').write_text(json.dumps(review,indent=2),encoding='utf-8')
print(json.dumps({'candidate_id':current['id'],'observer_symbols':len(plan['excluded'])}))
