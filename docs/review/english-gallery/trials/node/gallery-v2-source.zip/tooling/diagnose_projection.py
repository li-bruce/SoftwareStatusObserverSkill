"""Retain exact differences when source enrichment is not a fixed point."""
import json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(root/'observer_runtime'),str(root/'work/python-packages')]
from code_structure import scan,enrich
from behavior_model import digest
model=json.loads((root/'bo_stategraph/project.json').read_text(encoding='utf-8'))['model']
cfg=json.loads((root/'sync.json').read_text(encoding='utf-8'))
change=json.loads((root/'.stategraph/active.json').read_text(encoding='utf-8'))['change']
prior=json.loads((root/change/'baseline.json').read_text(encoding='utf-8'))['structure']
projected=enrich(model,scan(root,cfg['code_files'],prior),1)
differences=[]
for key in ('nodes','edges'):
    old={i['id']:i for i in model[key]};new={i['id']:i for i in projected[key]}
    differences.extend({'kind':key,'id':ident,'old':old.get(ident),'new':new.get(ident)} for ident in old.keys()|new.keys() if old.get(ident)!=new.get(ident))
(root/'review/projection-enrichment-differences.json').write_text(json.dumps(differences,indent=2),encoding='utf-8')
print(json.dumps({'equal':digest(model)==digest(projected),'count':len(differences),'differences':differences[:2]},ensure_ascii=False,indent=2))
