"""Switch project integration to candidate-2 while preserving candidate-1 intact."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
paths=[*root.glob('app/*.mjs'),*root.glob('integrations/*.mjs'),*root.glob('integrations/*.py'),*root.glob('tooling/*.py'),root/'bo_stategraph/native.mjs',root/'AGENTS.md']
for path in paths:
    if path.name=='upgrade_candidate.py':continue
    raw=path.read_text(encoding='utf-8')
    path.write_text(raw.replace('vendor/business-observer/', 'vendor/business-observer-candidate-2/').replace("'vendor/business-observer'","'vendor/business-observer-candidate-2'"),encoding='utf-8')
cfg=json.loads((root/'sync.json').read_text(encoding='utf-8'))
for base in ['vendor/business-observer','vendor/business-observer-candidate-2']:
    name='review/frozen-'+base.split('/')[-1]+'.json'
    files={p.relative_to(root/base).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'node_modules' not in p.parts}
    (root/name).write_text(json.dumps({'files':files},indent=2),encoding='utf-8');cfg['source_scope']['frozen_sources'][base]=name
(root/'sync.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
print('Project code now uses candidate-2. Both frozen candidates remain intact; no change baseline replaced.')
