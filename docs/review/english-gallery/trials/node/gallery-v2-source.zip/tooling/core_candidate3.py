"""Repeat core-only and deliberate business-negative tests for final candidate-3."""
import hashlib,json,shutil,subprocess,sys,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tooling'))
from extra_checks import execute_core
archive=ROOT/'outputs/gallery-core-candidate-3.zip'
result=subprocess.run([sys.executable,'observer_runtime/architecture_guard.py','package','--root',str(ROOT),'--out','outputs/gallery-core-candidate-3.zip'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
(ROOT/'review/candidate3-core-package-command.json').write_text(json.dumps({'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}),encoding='utf-8')
assert result.returncode==0,result.stdout
core=ROOT/'review/scenarios/core-candidate3';core.mkdir(exist_ok=False)
with zipfile.ZipFile(archive) as package:package.extractall(core)
clean=execute_core(core)
mutated=ROOT/'review/scenarios/business-mutation-candidate3';shutil.copytree(core,mutated,ignore=shutil.ignore_patterns('private-data'))
path=mutated/'app/domain.mjs';code=path.read_text(encoding='utf-8');assert 'if(decoded.readable)notify(' in code
path.write_text(code.replace('if(decoded.readable)notify(','if(true)notify('),encoding='utf-8')
negative=execute_core(mutated,True)
manifest=ROOT/'review/scenarios-source-hashes.json';frozen=json.loads(manifest.read_text(encoding='utf-8'))
for folder in (core,mutated):
    for path in folder.rglob('*'):
        if path.is_file() and path.suffix in {'.py','.mjs','.js'}:
            key=path.relative_to(ROOT/'review/scenarios').as_posix();sha=hashlib.sha256(path.read_bytes()).hexdigest()
            assert key not in frozen['files'] or frozen['files'][key]==sha
            frozen['files'][key]=sha
manifest.write_text(json.dumps(frozen,indent=2),encoding='utf-8')
evidence={'core_without_observer':clean,'targeted_invalid_notification_detected':negative,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()}
(ROOT/'review/candidate3-core-checks.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
print(json.dumps(evidence))
