"""Declaration rejection, native guard and isolation regression checks."""
import json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'observer_runtime'),str(ROOT/'work/python-packages')]
from bo_observer.protocol import validate_project
from bo_stategraph import BOStateGraph

def main():
    p=json.loads((ROOT/'bo_stategraph/project.json').read_text(encoding='utf-8'));validate_project(p)
    assert p['selection']['answer']=='drive'
    code="import {project,transition} from './bo_stategraph/native.mjs'; const i={state:'pending_review',owner:'alice',reviewer:'',bytes:1,readable:true}; try {transition(i,'approve',{actor:'alice'}); process.exit(2);} catch {} if(transition(i,'approve',{actor:'bob'}).state!=='published')process.exit(3); const bad=structuredClone(project.model.machine); bad.execution={}; const {BOExecutor}=await import('./observer_runtime/bo_observer/adapters/javascript/bo_runtime.mjs');try {new BOExecutor(bad,{});process.exit(4);}catch{}"
    subprocess.run(['node','--input-type=module','-e',code],cwd=ROOT,check=True)
    invalid=json.loads(json.dumps(p));invalid['model']['machine']['initial']='not_declared'
    try:validate_project(invalid)
    except ValueError:pass
    else:raise AssertionError('Invalid declaration accepted')
    graph=BOStateGraph(p['model'],build_id='test',mode='drive')
    result=graph.bo_observe('bad',state='illegal',context={'owner':'alice','reviewer':'','bytes':1,'readable':True},revision=0,evidence_id='actual-invalid',build_id='test')
    assert graph.bo_instances()[0]['observed']['state']=='illegal'
    assert graph.bo_instances()[0]['errors']
    subprocess.run([sys.executable,'observer_runtime/architecture_guard.py','check','--root',str(ROOT),'--out','review/architecture-check.json'],cwd=ROOT,check=True)
    print(json.dumps({'native_self_review_rejected':True,'other_account_accepted':True,'unsupported_engine_semantics_rejected':True,'invalid_actual_state_preserved':True}))

if __name__=='__main__':main()
