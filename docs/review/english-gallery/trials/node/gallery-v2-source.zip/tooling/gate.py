"""Normal project gate: retain native checks and accepted change synchronization."""
import os,subprocess,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
env={**os.environ,'PYTHONPATH':str(root/'work/python-packages'),'PYTHONIOENCODING':'utf-8'}
for argv in [[sys.executable,'tooling/project_checks.py'],[sys.executable,'observer_runtime/change_sync.py','check','--root',str(root)]]:
    result=subprocess.run(argv,cwd=root,env=env)
    if result.returncode:raise SystemExit(result.returncode)
