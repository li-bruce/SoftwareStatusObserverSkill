"""Create required protected witness plan and inventory exclusions before begin."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
plan={"schema":"bo-mapping/v1","cases":["workflow"],"modes":["on","off","fault"],"source":"Independent store.json read after completed HTTP workflow","actual_collection":["actual_records"],"actual_id":["id"],"fields":[{"id":key,"node":"pending_review","actual":[key],"mapped":[key]} for key in ["state","revision","build_id","context"]],"export":{"case":"workflow","mode":"on"}}
(root/'mapping.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
cfg=json.loads((root/'sync.json').read_text(encoding='utf-8'))
frozen={}
for base,name in [('vendor/business-observer-candidate-2','review/frozen-skill-files.json'),('work','review/frozen-preparation-files.json')]:
    files={p.relative_to(root/base).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'node_modules' not in p.parts and p.suffix in {'.py','.mjs','.js','.json'}}
    (root/name).write_text(json.dumps({'files':files},indent=2),encoding='utf-8');frozen[base]=name
cfg['source_scope']['frozen_sources']=frozen
cfg['source_scope']['exclude']['tooling/**']='Project verification, build and launcher infrastructure; watched separately.'
cfg['source_scope']['exclude']['integrations/bo_service.py']='Observer-only HTTP collector and graph transport; no business execution.'
(root/'sync.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
print('Protected mapping plan prepared; prior failed begin attempts retained.')
