"""Measure the preserved v1 export without changing its source or old evidence."""
import base64,json,os,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tooling'))
from observe import request
folder=ROOT/'review/scenarios/core-candidate3'
data=ROOT/'work/v1-jpeg-baseline-data'
app=subprocess.Popen(['node','app/server.mjs'],cwd=folder,env={**os.environ,'PORT':'0','BO_MODE':'off','GALLERY_DATA':str(data)},stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
try:
    ready=json.loads(app.stdout.readline());base=ready['url']
    _,_,cookie=request(base,'/api/login',{'username':'alice','password':'gallery-demo-2026'})
    status,image,_=request(base,'/api/upload',{'filename':'baseline.jpg','content':base64.b64encode((ROOT/'fixtures/painting.jpg').read_bytes()).decode()},cookie)
    assert status==201 and image['state']=='pending_review'
    raw=json.loads((data/'store.json').read_text())
    assert any(m['image_id']==image['id'] and m['recipient']=='bob' for m in raw['messages'])
    result={'application_version':'v1 preserved candidate-3 core export','jpeg_upload_status':status,'state':image['state'],'other_account_notified':True,'source_unchanged':True}
    (ROOT/'review/v1/jpeg-baseline.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result))
finally:app.terminate();app.wait(timeout=5)
