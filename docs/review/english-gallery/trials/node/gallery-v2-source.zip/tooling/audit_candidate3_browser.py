"""Audit the newest browser recording against actual persisted effects."""
import json,sys
from pathlib import Path
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parents[1]
def get(url):
    with urlopen(url,timeout=8) as response:return json.load(response)
def main():
    version=sys.argv[1];folder=ROOT/'review'/version;folder.mkdir(exist_ok=True)
    dev=json.loads((ROOT/'.stategraph/dev.json').read_text());base=dev['graph'].removesuffix('/graph')
    view=get(base+'/api/view');records=get(base+'/api/recordings')['recordings']
    meta=next(r for r in reversed(records) if r['build_id']==dev['build_id'] and r['events']>=30)
    record=get(base+'/api/recordings/'+meta['id'])
    # Identify a real newly uploaded instance, excluding restored startup reads.
    raw=json.loads((ROOT/'data/store.json').read_text())
    starts={e['entity'] for e in record['events'] if e['node']=='upload' and e['phase']=='commit'}
    image=next(i for i in raw['images'] if i['id'] in starts and i['state']=='published')
    assert image['owner']=='alice' and image['reviewer']=='bob' and image['state']=='published'
    frames=record['runtime_frames']['frames'];states=[f['machine']['current'] for f in frames]
    assert states[-1]=='published' and 'pending_review' in states and 'received' in states
    assert not record['gaps'] and view['binding_status']['status']=='current'
    assert view['health']['errors']==0 and view['health']['dropped']==0
    for e in record['events']:
        assert e['build_id']==dev['build_id']
        assert not {'password','cookie','token','content','buffer'}.intersection(set(e['inputs'])|set(e['outputs']))
    observed=next(i['observed'] for i in view['instances'] if i['observed']['instance_id'].endswith(':'+image['id']))
    assert observed['state']==image['state'] and observed['revision']==image['revision']
    result={'build_id':dev['build_id'],'recording_id':meta['id'],'recorded_events':len(record['events']),'state_frames':states,'store_matches':True,'errors':0,'dropped':0,'credentials_recorded':False,'event_count_before_controls':len(view['events'])}
    (folder/'browser-recording.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    (folder/'browser-audit.json').write_text(json.dumps(result,indent=2))
    print(json.dumps(result))
if __name__=='__main__':main()
