"""Build the canonical common graph from confirmed intent and native source facts."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'observer_runtime'),str(ROOT/'work/python-packages')]
from code_structure import scan,enrich
from behavior_model import capture
from bo_observer.protocol import validate_project
from bo_observer.development import questions
from behavior_model import digest

def write(name,value):
    (ROOT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')

def build():
    cfg=json.loads((ROOT/'sync.json').read_text(encoding='utf-8'))
    cfg.update(code_files=['app/domain.mjs','app/store.mjs','app/server.mjs','bo_stategraph/native.mjs','public/client.js','integrations/bo_probe.mjs','integrations/bo_http.mjs'],watch_files=['tooling/build_model.py','tooling/observe.py','tooling/dev.py','tooling/project_checks.py','tooling/gate.py','integrations/bo_service.py','public/index.html','public/style.css','package.json','package-lock.json','implementation.json','whitebox.json','ownership.json','AGENTS.md'],whitebox='whitebox.json',probe_callees=['bo_probe.record'],slice_depth=1)
    cfg['code_files'].extend(['public/bo_client.js','bo_stategraph/bootstrap.mjs','app/bo_ports.mjs','bo_stategraph/engine.mjs'])
    cfg['source_scope']['exclude']['scripts/project_checks.py']='Preserved verification wrapper; executes the watched project checks.'
    cfg['stategraph']['module']='bo_stategraph/native.mjs'
    cfg['reconciliation']='reconciliation.json'
    cfg['watch_files'].append('reconciliation.json')
    cfg['source_scope']['frozen_sources']['review/scenarios']='review/scenarios-source-hashes.json'
    archive=ROOT/'review/scenarios-source-hashes.json'
    frozen=json.loads(archive.read_text(encoding='utf-8')) if archive.exists() else {'files':{}}
    for path in (ROOT/'review/scenarios').rglob('*'):
        if path.is_file() and path.suffix in {'.py','.mjs','.js'}:
            key=path.relative_to(ROOT/'review/scenarios').as_posix();sha=hashlib.sha256(path.read_bytes()).hexdigest()
            if key in frozen['files'] and frozen['files'][key]!=sha:raise ValueError('Archived scenario source changed: '+key)
            frozen['files'][key]=sha
    write('review/scenarios-source-hashes.json',frozen)
    cfg['observations_command']=['{python}','tooling/observe.py']
    cfg['watch_files'].append('scripts/project_checks.py')
    write('sync.json',cfg)
    discovery=json.loads((ROOT/'discovery.json').read_text(encoding='utf-8'))
    states=['received','invalid_file','pending_review','published','not_displayed']
    machine={'engine':'bo.fsm','version':'1','states':states,'values':states,'initial':'received','state_type':'enum','events':{'validate':{'payload':{'valid':{'type':'boolean'}}},'approve':{'payload':{'actor':{'type':'string'}}},'reject':{'payload':{'actor':{'type':'string'}}}},'context':{'owner':{'type':'string'},'reviewer':{'type':'string'},'bytes':{'type':'integer','min':0},'readable':{'type':'boolean'}},'guards':{'imageReadable':{'source':{'path':'bo_stategraph/native.mjs','symbol':'imageReadable'}},'otherAccount':{'source':{'path':'bo_stategraph/native.mjs','symbol':'otherAccount'}}},'transitions':[{'source':'received','dest':'pending_review','trigger':'validate','conditions':'imageReadable'},{'source':'received','dest':'invalid_file','trigger':'validate','unless':'imageReadable'},{'source':'pending_review','dest':'published','trigger':'approve','conditions':'otherAccount'},{'source':'pending_review','dest':'not_displayed','trigger':'reject','conditions':'otherAccount'}]}
    declarations={
        'login':('login',{'username':'string','password_present':'boolean'},{'authenticated':'boolean','actor':'string'}),
        'authenticate':('authenticate',{'cookie_present':'boolean'},{'authenticated':'boolean','actor':'string'}),
        'logout':('logout',{'token_present':'boolean'},{'removed':'boolean'}),
        'upload':('upload',{'actor':'string','filename':'string','bytes':'number'},{'image_id':'string','state':'string','revision':'number'}),
        'image_check':('decodeImage',{'bytes':'number','image_id':'string'},{'readable':'boolean','original_format':'string','accepted':'boolean','width':'number','height':'number'}),
        'upload_message':('notify',{'image_id':'string','owner':'string'},{'recipients':['string'],'count':'number'}),
        'messages':('messages',{'actor':'string'},{'count':'number','image_ids':['string']}),
        'display_review':('review',{'actor':'string','image_id':'string','decision':'string'},{'state':'string','revision':'number','reviewer':'string'}),
        'review_permission':('review',{'actor':'string','owner':'string','image_id':'string'},{'allowed':'boolean'}),
        'exhibition':('exhibition',{},{'count':'number','image_ids':['string']}),
        'image_bytes':('imageBytes',{'image_id':'string','actor':'string'},{'allowed':'boolean','bytes':'number'}),
        'http':('send',{'path':'string'},{'status':'number','body_bytes':'number','header_count':'number'}),
    }
    original={n['id']:n for net in discovery['networks'] for n in net['nodes']}
    nodes=[]
    for ident,(symbol,inputs,outputs) in declarations.items():
        nodes.append({'id':ident,'label':original.get(ident,{}).get('label',ident.replace('_',' ').title()),'kind':'decision' if ident in {'image_check','review_permission'} else 'action','layer':'business','summary':'Actual native operation; capture selected fields only. '+('Actual content must decode as PNG; JPEG and every other format are rejected without notification. ' if ident=='image_check' else '')+('A different logged-in account is required.' if ident=='review_permission' else ''),'source':{'path':'app/server.mjs' if ident=='http' else 'app/domain.mjs','symbol':symbol},'capture':{'in':inputs,'out':outputs},'requirements':['R1' if ident in {'login','authenticate','logout','review_permission'} else 'R2' if ident in {'upload','image_check'} else 'R4' if ident in {'exhibition','image_bytes'} else 'R3']})
    for state in states:nodes.append({'id':state,'kind':'state','layer':'state','value':state,'label':original.get(state,{}).get('label',state.title()),'summary':'Authoritative persisted image lifecycle state','capture':{}})
    edges=[{'id':e['id'],'from':e['from'],'to':e['to'],'type':e['relation'],'label':e['label'],'evidence':'Confirmed discovery source references: '+','.join(e['source_refs'])} for net in discovery['networks'] for e in net['edges']]
    for ident,target in [('messages','display_review'),('review_permission','display_review'),('authenticate','upload'),('image_bytes','exhibition')]:edges.append({'id':ident+':'+target,'from':ident,'to':target,'type':'guard' if ident in {'review_permission','authenticate'} else 'data','label':'Native implementation relationship','evidence':'Current implementation, independently tested'})
    model={'schema_version':3,'revision':'gallery-2','project_id':discovery['project_id'],'intent':'intent.json','source_files':cfg['code_files']+cfg['watch_files']+['intent.json','discovery.json','acceptance.json','mapping.json'],'nodes':nodes,'edges':edges,'overview':[{'node':n['id']} for n in nodes if n.get('layer')=='business'],'graph_roots':[n['id'] for n in nodes],'scope':{'observable':['Authentication','Image decoding','Upload','Other-account permission','Notifications','Review','Exhibition query','Image serving','HTTP responses'],'unknowns':['Local two-account trial; no production identity deployment claim.','Selected execution cases do not prove every path or scheduling.','Frontend callbacks are source-mapped; server operation results are captured at authoritative boundaries.']},'machine':machine,'presentation':{'subject':'Gallery · mutual review'}}
    prior=None
    active=ROOT/'.stategraph/active.json'
    if active.exists():
        change=json.loads(active.read_text(encoding='utf-8'))['change']
        baseline=ROOT/change/'baseline.json'
        if baseline.exists():prior=json.loads(baseline.read_text(encoding='utf-8')).get('structure')
    index=scan(ROOT,cfg['code_files'],prior)
    if index['errors']:raise ValueError(index['errors'])
    plan={'schema':'bo-implementation/v1','features':[],'support':{},'excluded':{}}
    parameter_fields={'password':'password_present','cookie':'cookie_present','token':'token_present','buffer':'bytes','image':'image_id','request':'path','body':'body_bytes','headers':'header_count'}
    for ident,(symbol,inputs,outputs) in declarations.items():
        if ident=='review_permission':continue
        source=('app/server.mjs' if ident=='http' else 'app/domain.mjs')+'::'+symbol
        frontend={'login':'signIn','logout':'signOut','upload':'sendFile','messages':'refresh','display_review':'reviewClick'}
        sources=[source]+(['app/server.mjs::handle'] if ident=='http' else [])+(['public/client.js::'+frontend[ident]] if ident in frontend else [])
        owned=[ident]+(['review_permission'] if ident=='display_review' else [])
        feature={'id':ident,'label':ident,'business_node':ident,'nodes':owned,'sources':sources,'parameters':[],'cases':[{'case':'workflow','node':ident,'phase':'decision' if ident=='image_check' else 'commit' if ident in {'display_review','upload_message'} else 'return'}]}
        if ident=='display_review':feature['cases'].append({'case':'workflow','node':'review_permission','phase':'decision'})
        for sid in sources:
            for p in index['symbols'][sid]['parameters']:
                name=p['name']
                if name=='response':feature['parameters'].append({'source':sid,'name':name,'policy':'context','reason':'HTTP transport response object; no business data captured.'});continue
                if name in {'parent_call_id','source_event'}:feature['parameters'].append({'source':sid,'name':name,'policy':'context','reason':'Actual parent call/evidence identity; does not replace business arguments.'});continue
                field=({'login':'username','upload':'bytes','display_review':'image_id'}.get(ident) if name=='event' else parameter_fields.get(name,name));direction='in' if field in inputs else 'out'
                feature['parameters'].append({'source':sid,'name':name,'node':ident,'direction':direction,'field':field,'policy':'derived' if field!=name else 'value',**({'reason':'Selected presence, size or identity from the real argument; never credentials or arbitrary bodies.'} if field!=name else {})})
        plan['features'].append(feature)
    classified={sid for f in plan['features'] for sid in f['sources']}
    for sid,symbol in index['symbols'].items():
        if symbol['kind']!='function' or sid in classified:continue
        if symbol['path'].startswith('integrations/bo_') or symbol['path'] in {'public/bo_client.js','app/bo_ports.mjs'}:plan['excluded'][sid]={'category':'observer','reason':'Neutral optional ports, bounded transport and diagnostics only; no business decision.'}
        else:plan['support'][sid]={'node':'upload' if symbol['path']=='bo_stategraph/native.mjs' or 'store' in symbol['path'] else 'http','reason':'Source-inventoried native execution, rendering, routing or persistence support.'}
    model['implementation']=plan
    model=enrich(model,index,1)
    write('implementation.json',plan)
    project={'protocol':'bo-project/v1','project_id':discovery['project_id'],'selection':{'mode':'drive','source':'user','answer':'drive','locator':'discovery.json:U_D1'},'model':model}
    answers=[]
    for item in questions(project,index)['coding']:
        expression=item['expression']
        dependency='ECMAScript standard objects and native collection/string methods; selected source value is verified by the workflow'
        if any(term in expression for term in ('sharp','rotate','png','toBuffer')):dependency='sharp@0.34.5 decoding pipeline; real PNG and invalid bytes are independently checked'
        elif 'bo_probe' in expression:dependency='Neutral live-bound BOProbe port installed at application entry; frozen SDK transport; on/off/fault workflow coverage'
        elif any(term in expression for term in ('scrypt','timingSafeEqual','randomUUID','randomBytes','Buffer','writeFile','readFile')):dependency='Node.js built-in crypto, Buffer or filesystem API; explicit import and real store/HTTP result witness'
        elif 'request' in expression or 'response' in expression:dependency='Node.js native HTTP request/response interface; real HTTP workflow'
        answers.append({'id':item['id'],'status':'external','dependency':dependency,'reason':item['symbol']+' at current source line '+str(item['id'].split(':')[-2])+': '+expression,'case':'workflow'})
    write('reconciliation.json',{'schema':'bo-reconciliation/v1','source_id':digest({p:u['file_hash'] for p,u in index['units'].items()}),'answers':answers})
    validate_project(project)
    write('bo_stategraph/project.json',project)
    rules=[{'id':'other-account-only','requirement':'R1','claim':'A review actor must differ from the owner.','basis':'discovery.json:U_D4','category':'business','node':'review_permission','source':{'path':'app/domain.mjs','symbol':'review'},'parameters':{'actor':None,'image_id':None,'decision':None}}]
    checks=[{'id':'review-permission-value','rule':'other-account-only','case':'workflow','phase':'decision','count':{'min':4},'fields':[{'path':['outputs','allowed'],'type':'boolean'}]}]
    write('whitebox.json',{'schema_version':1,'rules':rules,'checks':checks})
    for decision in discovery['decisions']:
        rid={'D1':'R5','D2':'R2','D3':'R1','D4':'R1'}[decision['id']]
        acceptance=json.loads((ROOT/'acceptance.json').read_text(encoding='utf-8'))
        ids=[c['id'] for c in acceptance['checks'] if c['requirement']==rid]
        if not ids:
            check_id='drive-engine-'+rid
            if not any(c['id']==check_id for c in acceptance['model_checks']):acceptance['model_checks'].append({'id':check_id,'requirement':rid,'path':['machine','engine'],'equals':'bo.fsm'})
            write('acceptance.json',acceptance);ids=[check_id]
        decision['links']={'requirements':[rid],'model_nodes':[n for n in decision['affects'] if n in {v['id'] for v in nodes}] or ['login'],'checks':ids}
    write('discovery.json',discovery)
    # Capture after every watched source exists; the service recomputes the same identity.
    missing=[p for p in model['source_files'] if not (ROOT/p).exists()]
    if not missing:write('manifest.json',capture(ROOT,model))
    write('review/source-index.json',index)
    print(json.dumps({'nodes':len(model['nodes']),'features':len(plan['features']),'symbols':len(index['symbols']),'unresolved_calls':len(index['unresolved']),'missing_files':missing}))

if __name__=='__main__':build()
