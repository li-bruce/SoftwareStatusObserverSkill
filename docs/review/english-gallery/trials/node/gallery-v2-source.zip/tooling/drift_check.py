"""Demonstrate that the normal gate rejects unsynchronized core changes."""
import json,os,subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[1]
path=root/'app/domain.mjs';original=path.read_bytes()
try:
    path.write_bytes(original+b'\n// Deliberate synchronization-negative test; restored byte-for-byte.\n')
    result=subprocess.run(['npm.cmd','test'],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    (root/'review/drift-rejection.stdout.log').write_bytes(result.stdout)
    assert result.returncode!=0,'Normal gate accepted unsynchronized core code'
finally:path.write_bytes(original)
evidence={'mutation':'A valid JavaScript comment added to core source without graph/probe synchronization.','exit_code':result.returncode,'source_restored_exactly':path.read_bytes()==original,'failure_scope':'Synchronization gate; not a syntax or startup failure.'}
(root/'review/drift-rejection.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
print(json.dumps(evidence))
