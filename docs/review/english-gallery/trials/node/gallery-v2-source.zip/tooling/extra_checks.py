"""Exercise exported core and targeted business mutation without editing live code."""
import json,os,shutil,subprocess,sys,tempfile,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tooling'))
from observe import workflow

def execute_core(folder,expect_failure=False):
    env={**os.environ,'PORT':'0','GALLERY_DATA':str(folder/'private-data'),'BO_MODE':'off'}
    app=subprocess.Popen(['node','app/server.mjs'],cwd=folder,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
    try:
        line=app.stdout.readline()
        if not line:raise RuntimeError(app.stderr.read())
        ready=json.loads(line)
        try:observations,raw=workflow(ready['url'],folder/'private-data')
        except AssertionError:
            if expect_failure:return {'detected':True,'reason':'Independent invalid-image notification effect assertion failed after targeted mutation.'}
            raise
        if expect_failure:raise AssertionError('Mutated business rule escaped the independent workflow')
        return {'passed':True,'observations':observations,'observer_directories_present':(folder/'integrations').exists()}
    finally:
        app.terminate();app.wait(timeout=5)

def main():
    artifact=ROOT/'outputs/gallery-core.zip'
    result=subprocess.run([sys.executable,'observer_runtime/architecture_guard.py','package','--root',str(ROOT),'--out','outputs/gallery-core.zip'],cwd=ROOT,capture_output=True,text=True,encoding='utf-8')
    (ROOT/'review/core-package-command.json').write_text(json.dumps({'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr},indent=2),encoding='utf-8')
    assert result.returncode==0,result.stdout
    folder=ROOT/'review/core-export';folder.mkdir(exist_ok=False)
    with zipfile.ZipFile(artifact) as archive:archive.extractall(folder)
    clean=execute_core(folder)
    mutated=ROOT/'review/business-mutation';shutil.copytree(folder,mutated,ignore=shutil.ignore_patterns('private-data'))
    path=mutated/'app/domain.mjs';code=path.read_text(encoding='utf-8');assert 'if(decoded.readable)notify(image)' in code
    path.write_text(code.replace('if(decoded.readable)notify(image)','notify(image)'),encoding='utf-8')
    negative=execute_core(mutated,expect_failure=True)
    evidence={'core_without_observer':clean,'invalid_image_notification_mutation':negative}
    (ROOT/'review/core-and-mutation-checks.json').write_text(json.dumps(evidence,indent=2),encoding='utf-8')
    print(json.dumps(evidence))

if __name__=='__main__':main()
