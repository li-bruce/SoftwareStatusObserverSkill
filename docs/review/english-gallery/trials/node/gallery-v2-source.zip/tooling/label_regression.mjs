// Pure display regressions; these fixtures are not business runtime evidence.
import assert from 'node:assert/strict';
import {phaseLabel} from '../observer_generated/static/graph-core.js';
import {boDisplayValue} from '../observer_generated/static/replay-steps.js';
const raw={machine:{}};
const labeled={machine:{labels:{pending:'Awaiting image review'}}};
assert.equal(phaseLabel(raw,'pending'),'pending');
assert.equal(boDisplayValue('pending',raw,{kind:'business',field:'Flow'}),'pending');
assert.equal(boDisplayValue('pending',labeled,{kind:'business',field:'Flow'}),'Awaiting image review');
assert.equal(boDisplayValue('pending',labeled,{kind:'value',field:'state'}),'pending');
assert.equal(boDisplayValue('pending',labeled,{kind:'state',field:'Activity'}),'Not started');
console.log(JSON.stringify({missing_labels_raw_fallback:true,business_labels_respected:true,raw_parameters_untranslated:true,activity_meaning_separate:true}));
