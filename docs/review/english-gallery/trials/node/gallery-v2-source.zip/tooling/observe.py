"""Execute real HTTP workflows and compare storage with common graph projections."""
import base64,concurrent.futures,copy,hashlib,json,os,shutil,struct,subprocess,sys,tempfile,threading,time,zlib
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'integrations'),str(ROOT/'observer_runtime'),str(ROOT/'work/python-packages')]
from bo_service import BOGallerySession,make_server
from behavior_model import capture
from bo_stategraph import BOStateGraph

def png_bytes():
    def chunk(kind,data):return struct.pack('!I',len(data))+kind+data+struct.pack('!I',zlib.crc32(kind+data)&0xffffffff)
    return b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!2I5B',2,2,8,2,0,0,0))+chunk(b'IDAT',zlib.compress(b'\x00\x26\x69\xa2\x8a\xba\xd7\x00\x8a\xba\xd7\x26\x69\xa2'))+chunk(b'IEND',b'')

def request(base,path,body=None,cookie=None):
    headers={'Content-Type':'application/json'}
    if cookie:headers['Cookie']=cookie
    req=Request(base+path,headers=headers,data=json.dumps(body).encode() if body is not None else None)
    try:
        with urlopen(req,timeout=8) as response:status=response.status;raw=response.read();cookie=response.headers.get('Set-Cookie','').split(';')[0]
    except HTTPError as error:status=error.code;raw=error.read();cookie=''
    try:data=json.loads(raw)
    except (ValueError,UnicodeError):data={'bytes':len(raw)}
    return status,data,cookie

def workflow(base,data_dir):
    observations={};png=base64.b64encode(png_bytes()).decode();file={'filename':'test-painting.png','content':png}
    observations['anonymous_upload']=request(base,'/api/upload',file)[0]
    observations['bad_password']=request(base,'/api/login',{'username':'alice','password':'wrong'})[0]
    _,_,alice=request(base,'/api/login',{'username':'alice','password':'gallery-demo-2026'})
    _,_,bob=request(base,'/api/login',{'username':'bob','password':'gallery-demo-2026'})
    observations['valid_upload'],first,_=request(base,'/api/upload',file,alice)
    observations['pending_public_image']=request(base,'/images/'+first['id'])[0]
    observations['self_review']=request(base,'/api/review',{'image_id':first['id'],'decision':'approve'},alice)[0]
    own=request(base,'/api/messages',cookie=alice)[1]['messages'];others=request(base,'/api/messages',cookie=bob)[1]['messages']
    observations['own_messages']=len(own);observations['message_to_other']=len(others)==1 and others[0]['image_id']==first['id']
    request(base,'/images/'+first['id'],cookie=bob)
    observations['other_review']=request(base,'/api/review',{'image_id':first['id'],'decision':'approve'},bob)[0]
    observations['repeat_review']=request(base,'/api/review',{'image_id':first['id'],'decision':'reject'},bob)[0]
    observations['published_public_image']=request(base,'/images/'+first['id'])[0]
    _,second,_=request(base,'/api/upload',file,bob)
    observations['rejected_review']=request(base,'/api/review',{'image_id':second['id'],'decision':'reject'},alice)[0]
    observations['invalid_upload']=request(base,'/api/upload',{'filename':'pretend.png','content':base64.b64encode(b'not an image').decode()},alice)[0]
    before_messages=len(json.loads((data_dir/'store.json').read_text())['messages'])
    jpeg=(ROOT/'fixtures/painting.jpg').read_bytes()
    observations['jpeg_upload'],rejected_jpeg,_=request(base,'/api/upload',{'filename':'disguised.png','content':base64.b64encode(jpeg).decode()},alice)
    observations['jpeg_no_notification']=len(json.loads((data_dir/'store.json').read_text())['messages'])==before_messages
    observations['jpeg_image_unavailable']=request(base,'/images/'+rejected_jpeg['image_id'],cookie=bob)[0]
    _,third,_=request(base,'/api/upload',file,alice)
    with concurrent.futures.ThreadPoolExecutor(2) as pool:
        statuses=list(pool.map(lambda decision:request(base,'/api/review',{'image_id':third['id'],'decision':decision},bob)[0],['reject','reject']))
    observations['concurrent_winners']=statuses.count(200)
    assert sorted(statuses)==[200,409],statuses
    gallery=request(base,'/api/gallery')[1]['images'];observations['gallery_count']=len(gallery)
    observations['logout']=request(base,'/api/logout',{},alice)[0]
    observations['revoked_session']=request(base,'/api/messages',cookie=alice)[0]
    raw=json.loads((data_dir/'store.json').read_text(encoding='utf-8'))
    # Independent effects: no invalid-image notification and all recipients differ from owners.
    assert len(raw['images'])==5
    invalid=next(i for i in raw['images'] if not i['readable'])
    assert invalid['state']=='invalid_file' and not any(m['image_id']==invalid['id'] for m in raw['messages'])
    jpeg_record=next(i for i in raw['images'] if i['id']==rejected_jpeg['image_id'])
    observations['png_content_accepted']=next(i for i in raw['images'] if i['id']==first['id'])['accepted'] is True
    observations['jpeg_content_rejected']=jpeg_record['readable'] is True and jpeg_record['original_format']=='jpeg' and jpeg_record['accepted'] is False and jpeg_record['state']=='invalid_file'
    assert observations['jpeg_no_notification'] and observations['jpeg_content_rejected']
    assert not (data_dir/'images'/(jpeg_record['id']+'.png')).exists()
    assert all(m['owner']!=m['recipient'] for m in raw['messages'])
    assert next(i for i in raw['images'] if i['id']==first['id'])['reviewer']=='bob'
    assert next(i for i in raw['images'] if i['id']==second['id'])['reviewer']=='alice'
    assert len(gallery)==1 and gallery[0]['id']==first['id']
    return observations,raw

def execute(mode,project,build_id,capacity=None):
    # Keep scenario evidence in this trial; retain it rather than deleting failed runs.
    scenario_base=ROOT/'review/scenarios';scenario_base.mkdir(parents=True,exist_ok=True)
    from contextlib import nullcontext
    with nullcontext(tempfile.mkdtemp(prefix='gallery-trial-',dir=scenario_base)) as temp:
        sandbox=Path(temp);data_dir=sandbox/'application-data'
        for name in [*project['model']['source_files'],'bo_stategraph/project.json','sync.json']:
            target=sandbox/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/name,target)
        archive=ROOT/'review/scenarios-source-hashes.json'
        frozen=json.loads(archive.read_text(encoding='utf-8'))
        for path in sandbox.rglob('*'):
            if path.is_file() and path.suffix in {'.py','.mjs','.js'}:
                key=path.relative_to(scenario_base).as_posix();sha=hashlib.sha256(path.read_bytes()).hexdigest()
                assert key not in frozen['files'] or frozen['files'][key]==sha
                frozen['files'][key]=sha
        archive.write_text(json.dumps(frozen,indent=2),encoding='utf-8')
        session=BOGallerySession(sandbox);server=make_server(session,0);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        endpoint=f'http://127.0.0.1:{server.server_port}'
        env={**os.environ,'GALLERY_DATA':str(data_dir),'PORT':'0','BO_BUILD':build_id,'BO_ENDPOINT':endpoint if mode=='on' else 'http://127.0.0.1:1','BO_TOKEN':server.bo_token,'BO_MODE':mode}
        if capacity is not None:env['BO_CAPACITY']=str(capacity)
        app=subprocess.Popen(['node','app/server.mjs'],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8')
        try:
            line=app.stdout.readline()
            if not line:raise RuntimeError(app.stderr.read())
            ready=json.loads(line)
            if mode=='on' and capacity is None:session.recordings.start('HTTP acceptance workflow')
            observations,raw=workflow(ready['url'],data_dir)
            # Wait for bounded asynchronous transport, not for business outcomes.
            deadline=time.monotonic()+45
            while mode=='on' and capacity is None and time.monotonic()<deadline:
                diagnostic=request(ready['url'],'/api/bo/diagnostics')[1]
                if diagnostic['queued']==0 and not diagnostic['busy']:break
                time.sleep(.05)
            recording=None
            if mode=='on' and capacity is None:
                session.recordings.stop();recording=session.recordings.get(session.recordings.list()['recordings'][-1]['id'])
                assert len(recording['events'])>0
                assert any(e['node']=='display_review' for e in recording['events'])
                before=len(session.history.snapshot());session.recordings.list();session.view();session.export();assert len(session.history.snapshot())==before
            actual=[]
            for image in raw['images']:
                actual.append({'id':ready['run_id']+':'+image['id'],'state':image['state'],'revision':image['revision'],'build_id':build_id,'context':{k:image[k] for k in ('owner','reviewer','bytes','readable')}})
            if mode=='on' and capacity is None:
                machine=session.view()['machine']
                events=session.history.snapshot()
                starts=[e for e in events if e['node']=='upload' and e['phase']=='commit']
                checks=[e for e in events if e['node']=='image_check']
                assert any(e['outputs']['original_format']=='jpeg' and e['outputs']['readable'] and not e['outputs']['accepted'] for e in checks)
                assert any(e['outputs']['original_format']=='png' and e['outputs']['accepted'] for e in checks)
                assert len(starts)==5
                for start in starts:
                    end=next(e for e in events if e['node']=='upload' and e['phase']=='return' and e['entity']==start['entity'])
                    child=next(e for e in events if e['node']=='image_check' and e['entity']==start['entity'])
                    assert start['call_id']==end['call_id']==child['parent_call_id']
                    assert child['depends']==[{'event':start['id'],'type':'data'}]
                assert all(e['parent_call_id'] in {s['call_id'] for s in starts} and e['depends'] for e in events if e['node']=='upload_message')
                instances=session.graph.bo_instances(machine)
                assert len(instances)==5,session.view()['health']
                assert all(not i['errors'] and not i['missing'] for i in instances),instances
            else:
                machine={'current':None,'configurations':[{'attempt':i['id'],'phase':i['state'],'state_revision':i['revision'],'run_build_id':i['build_id'],'context':i['context'],'activities':{},'resources':{},'journal':[]} for i in actual]}
                instances=session.graph.bo_instances(machine)
            witnesses=[{'id':'authoritative-state:'+a['id'],'source':'store.json independently read','projection':'BOStateGraph.bo_instances','actual':a['state'],'mapped':next(i['observed']['state'] for i in instances if i['observed']['instance_id']==a['id'])} for a in actual]
            result={'case':'workflow','mode':mode,'events':session.history.snapshot(),'observations':observations,'actual_records':actual,'projection':{'build_id':build_id,'machine':machine,'instances':instances},'mapping_checks':witnesses,'state_errors':[e for i in instances for e in i['errors']]}
            return result,session.graph.bo_export(runtime={'machine':machine}),recording
        finally:
            app.terminate()
            try:app.wait(timeout=3)
            except subprocess.TimeoutExpired:app.kill();app.wait()
            server.shutdown();server.server_close();session.close()

def main():
    project=json.loads((ROOT/'bo_stategraph/project.json').read_text(encoding='utf-8'));build=capture(ROOT,project['model'])['build_id']
    runs=[];export=None
    for mode in ['on','off','fault']:
        run,current,recording=execute(mode,project,build);runs.append(run)
        if mode=='on':
            export=current
            (ROOT/'review/runtime-recording.json').write_text(json.dumps(recording,ensure_ascii=False,indent=2),encoding='utf-8')
    limited,_,_=execute('on',project,build,capacity=1)
    assert limited['observations']==runs[0]['observations']
    result={'build_id':build,'machine':project['model']['machine'],'runs':runs,'stategraph_export':export,'mapping_checks':[w for run in runs for w in run['mapping_checks']],'queue_limited_business_equal':True}
    (ROOT/'review/observations.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))

if __name__=='__main__':main()
