"""Independently audit browser recording, live state and zero-event viewer controls."""
import json
from pathlib import Path
from urllib.request import urlopen
ROOT=Path(__file__).resolve().parents[1]
def get(url):
    with urlopen(url,timeout=8) as response:return json.load(response)

def main():
    dev=json.loads((ROOT/'.stategraph/dev.json').read_text(encoding='utf-8'))
    base=dev['graph'].removesuffix('/graph');view=get(base+'/api/view');listing=get(base+'/api/recordings')
    record_meta=next(r for r in listing['recordings'] if r['build_id']==dev['build_id'] and r['events']>=30)
    record=get(base+'/api/recordings/'+record_meta['id'])
    (ROOT/'review/browser-operation-recording.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
    frames=record.get('runtime_frames',{}).get('frames',[])
    states=[f['machine']['current'] for f in frames]
    assert states==['received','pending_review','published'],states
    assert record['gaps']==[],record['gaps']
    assert record_meta['events']==36
    for event in record['events']:
        assert event['build_id']==dev['build_id']
        if 'revision' in event:assert any(f['event_id']==event['id'] and f['revision']==event['revision'] for f in frames)
        for values in (event['inputs'],event['outputs']):
            assert not any(key in values for key in ('password','cookie','token','content','buffer'))
    before=json.loads((ROOT/'review/browser-before-viewer-controls.json').read_text(encoding='utf-8-sig'))
    assert len(view['events'])==before['event_count']==51
    raw=json.loads((ROOT/'data/store.json').read_text(encoding='utf-8'))
    assert len(raw['images'])==1 and raw['images'][0]['state']=='published'
    assert raw['images'][0]['owner']=='alice' and raw['images'][0]['reviewer']=='bob'
    observed=view['instances'][0]['observed']
    assert observed['state']==raw['images'][0]['state'] and observed['revision']==raw['images'][0]['revision']
    assert view['manifest']['build_id']==dev['build_id'] and view['binding_status']['status']=='current'
    assert view['health']['errors']==0 and view['health']['dropped']==0
    result={'build_id':dev['build_id'],'recording_id':record_meta['id'],'recorded_events':36,'exact_state_frames':states,'viewer_controls_business_events_added':0,'live_state_matches_independent_store':True,'event_credentials_captured':False,'collector_errors':0,'collector_dropped':0,'locale_preferences':get(base+'/api/preferences')['entries'].get('business-observer.layout.v2:locale')}
    (ROOT/'review/browser-acceptance.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':main()
