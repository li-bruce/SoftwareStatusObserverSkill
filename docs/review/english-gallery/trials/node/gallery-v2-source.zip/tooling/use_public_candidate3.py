"""Adopt the publicly installed candidate-3 runtime without overwriting evidence."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
paths=[*root.glob('tooling/*.py'),*root.glob('integrations/*.py'),*root.glob('integrations/*.mjs')]
for path in paths:
    if path.name in {'use_public_candidate3.py','upgrade_candidate.py','prepare_contracts.py'}:continue
    code=path.read_text(encoding='utf-8')
    code=code.replace('vendor/business-observer-candidate-2/scripts','observer_runtime')
    path.write_text(code,encoding='utf-8')
agents=root/'AGENTS.md';agents.write_text(agents.read_text(encoding='utf-8').replace('vendor/business-observer-candidate-2/SKILL.md','vendor/business-observer-candidate-3/SKILL.md'),encoding='utf-8')
cfg=json.loads((root/'sync.json').read_text(encoding='utf-8'))
for name in ['observer_runtime','observer_generated']:
    cfg['source_scope']['exclude'][name+'/**']='Public candidate-3 runtime/assets; managed hashes and installed-copy comparison are checked.'
for name in ['__init__.py','bo_contracts.py','execution_contract.py']:
    cfg['source_scope']['exclude']['bo_stategraph/'+name]='Public independent query/type core; managed exact copy, not application logic.'
for base in ['vendor/business-observer-candidate-3','observer_runtime','observer_generated','bo_stategraph']:
    manifest='review/frozen-'+base.replace('/','-')+'.json'
    files={p.relative_to(root/base).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and 'node_modules' not in p.parts}
    (root/manifest).write_text(json.dumps({'files':files},indent=2),encoding='utf-8');cfg['source_scope']['frozen_sources'][base]=manifest
(root/'sync.json').write_text(json.dumps(cfg,indent=2),encoding='utf-8')
ownership=json.loads((root/'ownership.json').read_text(encoding='utf-8'))
ownership['layers']['observer']['paths'].extend(['observer_runtime','observer_generated'])
ownership['managed_paths'].extend(['observer_runtime','observer_generated','bo_stategraph/__init__.py','bo_stategraph/bo_contracts.py','bo_stategraph/execution_contract.py'])
(root/'ownership.json').write_text(json.dumps(ownership,indent=2),encoding='utf-8')
print('Using public candidate-3 runtime; all original business sources and previous candidates retained.')
