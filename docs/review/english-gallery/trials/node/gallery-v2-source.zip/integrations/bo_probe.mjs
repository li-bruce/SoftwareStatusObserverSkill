// Observation is asynchronous, bounded, field-selected and never business authority.
import {BOProbe} from '../observer_runtime/bo_observer/adapters/javascript/bo_runtime.mjs';
import {bo_state} from '../app/bo_ports.mjs';
export function bo_create(project) {
  return new BOProbe({project,buildId:process.env.BO_BUILD||'offline',endpoint:process.env.BO_ENDPOINT||'http://127.0.0.1:1',token:process.env.BO_TOKEN||'',enabled:process.env.BO_MODE!=='off',capacity:Number(process.env.BO_CAPACITY||256),timeout:3000});
}
export function bo_restore(probe,store) {
  for(const image of store.images) {
    const evidence=probe.record('upload','read',()=>({inputs:{actor:image.owner,filename:image.filename,bytes:image.bytes},outputs:{image_id:image.id,state:image.state,revision:image.revision}}),{entity:image.id,attempt:image.id,scope:'entity',revision:image.revision});
    bo_state(probe,image,evidence);
  }
}
