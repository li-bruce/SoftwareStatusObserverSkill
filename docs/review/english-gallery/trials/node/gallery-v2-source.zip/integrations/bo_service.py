"""Project-local observer integration. Native business state remains in Node.js."""
import json,os,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'observer_runtime'),str(ROOT/'work/python-packages')]
from bo_observer.service import GraphSession,make_server
from view_preferences import Preferences

class BOGallerySession(GraphSession):
    def __init__(self,root):
        super().__init__(root)
        discovery=json.loads((Path(root)/'discovery.json').read_text(encoding='utf-8'))
        self.bo_layout=discovery['layout_id']
        self.preferences=Preferences(root,self.bo_layout)

    def view(self):
        value=super().view()
        value['layout_id']=getattr(self,'bo_layout','gallery-node-trial-layout-v1')
        return value

    def export(self):
        with self.lock:
            value=self.view()
            return self.graph.bo_export(binding=self.binding(),runtime={'machine':value['machine'],'events':value['events'],'runtime_frames':value['runtime_frames']})

def serve():
    session=BOGallerySession(ROOT)
    server=make_server(session,0,origins=[os.environ['APP_ORIGIN']] if os.environ.get('APP_ORIGIN') else [])
    settings={'endpoint':f'http://127.0.0.1:{server.server_port}','token':server.bo_token,'build_id':session.manifest['build_id']}
    (ROOT/'.stategraph').mkdir(exist_ok=True)
    (ROOT/'.stategraph/collector.json').write_text(json.dumps(settings),encoding='utf-8')
    print(json.dumps({'type':'ready','url':settings['endpoint'],'build_id':settings['build_id']}),flush=True)
    try:server.serve_forever()
    finally:server.server_close();session.close()

if __name__=='__main__':serve()
