// Transport diagnostics are observer infrastructure and never business events.
import {readFileSync} from 'node:fs';
export function bo_entry(bytes,graphUrl) {
  let visible=true;
  try{visible=JSON.parse(readFileSync(new URL('../bo_stategraph/config/web.json',import.meta.url),'utf8')).mode==='visible';}catch{}
  return visible&&graphUrl?Buffer.from(bytes.toString('utf8').replace('data-bo-entry target','data-bo-entry href="'+graphUrl+'" target').replace('rel="noopener" hidden','rel="noopener"')):bytes;
}
export async function bo_http(path,response,probe,request) {
  if(path==='/bo_client.js') {response.writeHead(200,{'Content-Type':'text/javascript; charset=utf-8'});response.end(readFileSync(new URL('../public/bo_client.js',import.meta.url)));return true;}
  if(path==='/api/bo/ui'&&request.method==='POST') {
    if(request.headers.origin&&request.headers.origin!==`http://${request.headers.host}`){response.writeHead(403);response.end();return true;}
    try {
      let body='';for await(const chunk of request){body+=chunk;if(body.length>8192)throw Error('capture_too_large');}
      const value=JSON.parse(body);
      if(!['login','logout','upload','display_review','messages'].includes(value.node))throw Error('unknown_ui_capture');
      probe.record(value.node,'return',()=>({inputs:value.inputs,outputs:value.outputs}));
      response.writeHead(200,{'Content-Type':'application/json'});response.end('{"accepted":true}');
    }catch{response.writeHead(400);response.end();}
    return true;
  }
  if(path!=='/api/bo/diagnostics')return false;
  response.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});
  response.end(JSON.stringify({queued:probe.bo_queue.length,busy:probe.bo_busy,errors:probe.bo_errors,dropped:probe.bo_dropped,enabled:probe.bo_enabled}));return true;
}
