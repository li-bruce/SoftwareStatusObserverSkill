"""Preserved original configured project-check entrypoint."""
import runpy
runpy.run_path('tooling/project_checks.py',run_name='__main__')
