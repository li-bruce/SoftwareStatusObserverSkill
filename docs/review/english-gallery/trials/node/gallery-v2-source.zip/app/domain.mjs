import sharp from 'sharp';
import {randomUUID,randomBytes,scryptSync,timingSafeEqual} from 'node:crypto';
import {writeFileSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {loadStore,saveStore} from './store.mjs';
import {project,transition} from '../bo_stategraph/native.mjs';
import {bo_probe,bo_state} from './bo_ports.mjs';
export {bo_probe} from './bo_ports.mjs';
export const directory=process.env.GALLERY_DATA||'data';
export const store=loadStore(directory);
export const sessions=new Map();
export function fail(status,code) { const error=new Error(code);error.status=status;throw error; }
export function login(username,password) {
  const user=store.users.find(u=>u.id===username);
  const ok=Boolean(user)&&timingSafeEqual(scryptSync(password,user.salt,32),Buffer.from(user.hash,'hex'));
  bo_probe.record('login','return',()=>({inputs:{username,password_present:Boolean(password)},outputs:{authenticated:ok,actor:ok?user.id:''}}));
  if(!ok)fail(401,'invalid_credentials');
  const token=randomBytes(32).toString('hex');sessions.set(token,{actor:user.id,expires:Date.now()+8*3600000});return {token,actor:user.id};
}
export function authenticate(cookie) {
  const token=/(?:^|;\s*)gallery_node_session=([a-f0-9]{64})(?:;|$)/.exec(cookie||'')?.[1];
  const session=sessions.get(token);
  const actor=session&&session.expires>Date.now()?session.actor:'';
  bo_probe.record('authenticate','return',()=>({inputs:{cookie_present:Boolean(cookie)},outputs:{authenticated:Boolean(actor),actor}}));
  if(!actor)fail(401,'login_required');return {actor,token};
}
export function logout(token) {
  const removed=sessions.delete(token);
  bo_probe.record('logout','return',()=>({inputs:{token_present:Boolean(token)},outputs:{removed}}));
  return {removed};
}
export async function decodeImage(buffer,image_id,parent_call_id=null,source_event=null) {
  try {
    const metadata=await sharp(buffer,{failOn:'warning',limitInputPixels:20000000}).metadata();
    const decoded=await sharp(buffer,{failOn:'warning',limitInputPixels:20000000}).rotate().png().toBuffer({resolveWithObject:true});
    const result={readable:true,original_format:metadata.format,accepted:metadata.format==='png',width:decoded.info.width,height:decoded.info.height,png:decoded.data};
    result.bo_evidence=bo_probe.record('image_check','decision',()=>({inputs:{bytes:buffer.length,image_id},outputs:{readable:true,original_format:result.original_format,accepted:result.accepted,width:result.width,height:result.height}}),{entity:image_id,attempt:image_id,scope:'entity',parentCallId:parent_call_id,depends:source_event?[{event:source_event,type:'data'}]:[]});
    return result;
  } catch {
    const bo_evidence=bo_probe.record('image_check','decision',()=>({inputs:{bytes:buffer.length,image_id},outputs:{readable:false,original_format:'',accepted:false,width:0,height:0}}),{entity:image_id,attempt:image_id,scope:'entity',parentCallId:parent_call_id,depends:source_event?[{event:source_event,type:'data'}]:[]});
    return {readable:false,original_format:'',accepted:false,width:0,height:0,bo_evidence};
  }
}
export function notify(image,parent_call_id=null,source_event=null) {
  const recipients=store.users.filter(u=>u.id!==image.owner).map(u=>u.id);
  for(const recipient of recipients)store.messages.push({id:randomUUID(),image_id:image.id,recipient,owner:image.owner});
  saveStore(directory,store);
  bo_probe.record('upload_message','commit',()=>({inputs:{image_id:image.id,owner:image.owner},outputs:{recipients,count:recipients.length}}),{entity:image.id,attempt:image.id,scope:'entity',parentCallId:parent_call_id,depends:source_event?[{event:source_event,type:'data'}]:[]});
  return recipients;
}
export async function upload(actor,filename,buffer) {
  const bo_call_id=randomUUID();
  const image={id:randomUUID(),owner:actor,reviewer:'',filename:filename.slice(0,120),bytes:buffer.length,readable:false,width:0,height:0,state:'received',revision:0};
  const initial=bo_probe.record('upload','commit',()=>({inputs:{actor,filename:image.filename,bytes:buffer.length},outputs:{image_id:image.id,state:image.state,revision:0}}),{entity:image.id,attempt:image.id,scope:'entity',revision:0,callId:bo_call_id});
  bo_state(bo_probe,image,initial);
  const decoded=await decodeImage(buffer,image.id,bo_call_id,initial);image.readable=decoded.readable;image.width=decoded.width;image.height=decoded.height;
  image.original_format=decoded.original_format;image.accepted=decoded.accepted;
  const step=transition(image,'validate',{valid:decoded.accepted});image.state=step.state;image.revision++;
  if(decoded.accepted)writeFileSync(join(directory,'images',image.id+'.png'),decoded.png);
  store.images.push(image);
  if(decoded.accepted)notify(image,bo_call_id,decoded.bo_evidence);
  else saveStore(directory,store);
  const evidence=bo_probe.record('upload','return',()=>({inputs:{actor,filename:image.filename,bytes:buffer.length},outputs:{image_id:image.id,state:image.state,revision:image.revision}}),{entity:image.id,attempt:image.id,scope:'entity',revision:image.revision,callId:bo_call_id,depends:decoded.bo_evidence?[{event:decoded.bo_evidence,type:'control'}]:[]});
  bo_state(bo_probe,image,evidence,step);
  if(!decoded.accepted){const error=new Error(decoded.readable?'unsupported_image_format':'invalid_image');error.status=415;error.image_id=image.id;throw error;}
  return {...image};
}
export function messages(actor) {
  const result=store.messages.filter(m=>m.recipient===actor&&store.images.some(i=>i.id===m.image_id&&i.state==='pending_review')).map(m=>({...m,image:store.images.find(i=>i.id===m.image_id)}));
  bo_probe.record('messages','return',()=>({inputs:{actor},outputs:{count:result.length,image_ids:result.map(m=>m.image_id)}}));return result;
}
export function review(actor,image_id,decision) {
  const image=store.images.find(i=>i.id===image_id);if(!image)fail(404,'image_not_found');
  const allowed=actor!==image.owner;
  bo_probe.record('review_permission','decision',()=>({inputs:{actor,owner:image.owner,image_id},outputs:{allowed}}),{entity:image.id,attempt:image.id,scope:'entity'});
  if(!allowed)fail(403,'self_review_forbidden');
  if(image.state!=='pending_review')fail(409,'review_already_decided');
  if(!['approve','reject'].includes(decision))fail(400,'invalid_decision');
  const step=transition(image,decision,{actor});image.state=step.state;image.reviewer=actor;image.revision++;
  saveStore(directory,store);
  const evidence=bo_probe.record('display_review','commit',()=>({inputs:{actor,image_id,decision},outputs:{state:image.state,revision:image.revision,reviewer:image.reviewer}}),{entity:image.id,attempt:image.id,scope:'entity',revision:image.revision});
  bo_state(bo_probe,image,evidence,step);return {...image};
}
export function exhibition() {
  const result=store.images.filter(i=>i.state==='published').map(i=>({...i}));
  bo_probe.record('exhibition','return',()=>({outputs:{count:result.length,image_ids:result.map(i=>i.id)}}));return result;
}
export function imageBytes(image_id,actor) {
  const image=store.images.find(i=>i.id===image_id);
  const allowed=Boolean(image&&image.readable&&image.state!=='invalid_file'&&(image.state==='published'||actor));
  bo_probe.record('image_bytes','return',()=>({inputs:{image_id,actor},outputs:{allowed,bytes:allowed?image.bytes:0}}));
  if(!allowed)fail(404,'image_not_found');return readFileSync(join(directory,'images',image.id+'.png'));
}
