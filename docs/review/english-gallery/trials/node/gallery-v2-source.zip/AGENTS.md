# Gallery trial maintenance

Use `vendor/business-observer-candidate-3/SKILL.md`, the frozen candidate only. Preserve the real-user answers in `discovery.json`, especially mutual review between accounts. Mode is explicitly `drive`; do not ask again.

Before editing behavior, continue the active change in `.stategraph/active.json`; never replace its baseline to hide drift. Maintain `bo_stategraph/project.json`, source mappings, probes and independent expectations together. Run `npm test` before delivery; it includes `change_sync check`. Preserve all previous checks and failures. Use `npm run dev` to start the application and observer together. Observer failure must not change native execution. Observe only selected fields and never credentials. Keep source and comments in English; preserve original conversation evidence.
