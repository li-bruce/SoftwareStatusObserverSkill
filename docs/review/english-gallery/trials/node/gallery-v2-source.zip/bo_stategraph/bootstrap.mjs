// Initial implementation boundary; replaced by the native state module.
export const planned = true;
