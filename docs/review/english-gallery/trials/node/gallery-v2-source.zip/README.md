# Gallery · mutual review

A local Node.js gallery with a declaration-driven native state machine and the frozen business-observer candidate-3 Python service. Application v2 accepts actual readable PNG only. Every account may upload and review other accounts' images; self-review is rejected. JPEG/unreadable uploads create no review messages. Approved images alone appear publicly. The format change was an explicitly simulated test request; original account permissions were preserved.

## Run

Tested here with Node.js 20.19.6 and Python 3.13.13. From the extracted project folder, in PowerShell:

```powershell
npm ci
npm ci --prefix observer_runtime/bo_observer/adapters/javascript
python -m pip install --target work/python-packages -r vendor/business-observer-candidate-3/requirements.txt
npm run dev
```

The development command prints the actual Application and Observer URLs; ports are selected dynamically. Open the two printed URLs. Local synthetic accounts are `alice` and `bob`, both using `gallery-demo-2026`. Runtime stores and collector credentials are generated locally and are excluded from the source package.

Use Ctrl+C in the launch terminal, or from a second terminal in this project:

```powershell
python tooling/dev.py --stop
```

The launcher cleans only its own children. Observer loss leaves native business execution available. `BO_MODE=off` disables transport when directly launching the native application.

## Record actual actions

Open the Observer URL, click **Start recording**, then use the application: sign in, upload `fixtures/painting.jpg` (rejected), upload `fixtures/painting.png`, sign out, sign in as the other account, and approve. Stop recording in the graph. Choose that record and a step, or play it. The JPEG decision preserves `readable=true`, `original_format=jpeg`, `accepted=false`. PNG moves through `received`, `pending_review`, and `published`. Record controls, graph reads and personal layout changes do not create business events.

The graph supports English and Chinese. Its language choice, layout and annotations are personal project settings. They are deliberately excluded from the distribution. Canonical source and documentation are English; localized display strings and original dialogue remain in their original language.

## Verify

```powershell
npm test
$env:PYTHONPATH = (Join-Path (Get-Location) 'work/python-packages')
python observer_runtime/change_sync.py verify --root .
```

`npm test` runs native/architecture checks and checks the accepted source, graph and review receipt. Full verification runs actual isolated HTTP workflows with observation on/off/failing and a bounded queue. Independently read storage supplies expected effects; capture alone does not establish correctness. Do not replace baselines, relax old checks or reseal modified public runtime files to make a check pass.

On a new development change, use `change_sync begin`, maintain declarations/mappings/capture and independent tests, then scan, review, verify, accept and check. `AGENTS.md` states the maintained project workflow. Existing accepted v1/v2 receipts are included as audit metadata. Historic test directories and runtime records are not required to run the source distribution; historical verification is reviewed in the separate evidence deliverables.

## Review evidence

In the original workspace, `outputs/REVIEW.md` is the review entrypoint; `review/commands/` contains complete raw command outputs. `review/v1/` retains v1 acceptance and its real browser recording; `review/v2/` contains v2 evidence. Application versions v1/v2 are separate from Skill candidates 1/2/3. Frozen candidate-3 has 144 upstream files; upstream manifest SHA256 is `fd022e1377b17e2679a8e1e8e0b9cbba51d1bb41c2f4af017383cc7dab1ccb8c`.

This is synthetic local integration testing, not a production identity system, human usability study, or proof of arbitrary whole-program semantic equivalence. Selected reconciliation cases bound external/dynamic-call claims. Old startup restores are reads of current storage, not reconstructed historical operations.
