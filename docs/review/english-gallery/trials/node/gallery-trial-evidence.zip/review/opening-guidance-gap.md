# Opening guidance gap and current stopping point

Project: `C:\Users\Lvi_P\Documents\Codex\2026-10-23\business-observer-gallery-node`

## New request and evidence

The coordinating chat requested that the opening also show a concise Mermaid business graph directly in conversation, generated from the same `discovery.json`, together with a clickable, verified real Web URL. It requested a stop for an explicitly labeled simulated-test confirmation before implementation. Existing real-user answers, especially account-to-account review, must remain authoritative.

Exact latest user request:

> skill中的不应该是项目和这个一起启动吗，还有记录操作的过程在哪里？反馈给主会话当前的结束状态

## Guidance gap G-02

The frozen `SKILL.md` section 1 and `references/conversation-web.md` instruct the agent to maintain the same Web graph, focus it, open its URL and discuss it in the coding conversation. They do not explicitly require an inline Mermaid projection before confirmation. The earlier trial supplied a screenshot and URL but omitted that inline projection. Against the newly explicit opening requirement, this is a guidance gap.

Minimal reproduction: follow the frozen design-stage instructions, create `discovery.json`, start `bo_web.py serve`, focus/open the Web graph, and stop after linking it. This sequence can satisfy the written steps while leaving the user without a concise textual graph directly in conversation.

Trial-local remedy: `work/render_conversation_graph.py` reads the canonical discovery file, maps only its display labels to Chinese, preserves all ten node IDs and eleven edges, and writes the Mermaid output plus its input SHA256 and live-Web identity comparison. No canonical business data or frozen Skill file is changed. This is a local workflow remedy, not a claim that the frozen candidate has been repaired upstream.

## Startup and operation recording

The current process is the **design-only** viewer `bo_web.py serve`. It is not the complete application/observer runtime. The Node.js application has not been implemented, so there is no application process to launch together with it.

The frozen multilingual guide documents a Python public service command separately (`scripts/bo.py serve`) and requires native application execution to survive observer failure. It does not provide a project-specific combined launcher for this unimplemented app. The intended integrated trial still needs project startup wiring, the native executable declaration, probes, the Python service, real recording APIs and verification. Concurrent startup is compatible with independently survivable business execution.

Two record types must remain distinct:

- **Development audit, already present:** `review/conversation.json`, `review/commands/*.json` and `*.log`, `review/tool-operations.json`, graph snapshots, HTTP responses and browser screenshot. These record what the development agent did and the answers it received.
- **Application operation recording, not implemented:** frozen `references/recorded-analysis.md` describes start recording, operate the application, stop recording, inspect events/parameters and replay. It specifies `POST /api/recordings/start`, `POST /api/recordings/stop`, `GET /api/recordings` and recording details. Those APIs are not part of this design-only server. The current view has no runtime events; it must not be represented as a recording of uploads or reviews.

## Ending status sent to the coordinating chat

- Frozen Skill copied completely; original 142 files hash-identical; local Python/JS dependencies installed.
- Intent clarified: drive, separate login, every account uploads and reviews other accounts' images, automatic readable-image check, invalid uploads rejected without message, in-app pending-review notification, approved exhibition display.
- Same-source Mermaid and real Web URL provided; waiting for the explicitly labeled simulated graph confirmation requested by the coordinator.
- No Node.js application, native executor, runtime probe integration or real business operation recording exists yet.
- Implementation mapping, state constraints and business runtime correctness remain untested; full project/architecture/export gates and the later iteration remain outstanding.
- Full trial is **not complete**. Development audit and design checks are not runtime acceptance.
