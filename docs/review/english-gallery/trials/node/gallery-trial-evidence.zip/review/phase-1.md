# Phase 1: installation and intent clarification

Project: `C:\Users\Lvi_P\Documents\Codex\2026-10-23\business-observer-gallery-node`

This is an independent AI development trial with simulated-user answers. It is not human usability testing. The original brief requested an initial stop after necessary questions and a design graph. This phase contains no application implementation, executable state declaration, authentication implementation, or business runtime evidence.

## Frozen installation

Source: `C:/Users/Lvi_P/Documents/Work/CF/平台软著/SoftwareStatusObserverSkill/.validation/gallery-trials/candidate-1/business-observer`

Installed copy: `vendor/business-observer`. All 142 original files were copied, including references, scripts, assets, agents and dependency manifests. Every original file's source and installed SHA256 is in `skill-installation.json`. Original files remain unchanged after installation; generated dependencies and Python caches are additional local installation files.

`SKILL.md` SHA256: `E7B5E7E2F506FF7FE97D56A8576259A10AC2218F43111DDE3AB05D7FD171A6EA`.

Python requirements were installed into `work/python-packages`. JavaScript adapter dependencies were installed with the frozen npm lockfile. No global Skill was used and no existing application was copied. No GitHub submission was made.

The frozen Skill requires a mode decision: "Until answered, continue only mode-independent preparation." The project now has the actual answer `drive`; no mode was inferred during preparation.

## Confirmed intent

Exact Chinese questions, answers, and source locations are preserved in `conversation.json` and `discovery.json`. Earlier graph snapshots remain in this directory.

- The Node.js application will execute from the state declaration (`drive`).
- Accounts log in separately. Every account may upload and review images uploaded by other accounts.
- The program automatically determines whether a file is a readable image.
- A non-image or unreadable file is rejected without sending a review notification.
- Valid images await display review. The reviewer receives an in-app pending-review message.
- A positive display review permits exhibition display; a negative display review does not permit display.
- The exhibition is a simple web gallery.

The initial answer `程序自动` answered only who checks the file; it did not settle the invalid-file route. The later answer `时` was preserved as ambiguous and was not used as confirmation. The subsequent explicit answer `是` settled that route. No additional business features were selected.

`discovery.json` contains ten stable design node IDs. Its `layout_id` is `gallery-node-trial-layout-v1`. The implementation phase must retain these IDs and the same viewer/layout identity. The current graph is a declaration-only design projection and must not be loaded as an executable state machine.

## Current graph and evidence

Verified viewer: http://127.0.0.1:61522/graph

Project ID: `gallery-node-trial`. The HTTP response, browser accessibility tree and screenshot all show the correct project. `verified-design-http.json` records successful requests for `/graph`, `/api/view`, and `/api/design`; the focus is current and the business event list is empty. `design-graph.png` and `design-browser-ax.txt` retain the browser evidence. The host viewer runs from this project's frozen copy, listens only on loopback and uses the project directory for preferences.

## Checks reported separately

| Category | Phase 1 result | Boundary |
| --- | --- | --- |
| Implementation mapping | Not run | No application functions or probes exist yet. Reserved node IDs do not prove coverage. |
| State constraints | Not run | No executable application state declaration or executor has been created. |
| Business rules | Not run | User answers are recorded; no real business execution has occurred. |
| Project checks | Phase artifacts passed | File hashes, dependency versions, discovery structure/history, graph identity, HTTP access and browser rendering verified. Full project/architecture/package gates remain unrun. |

The earlier unanswered-question check exited 1 as intended. After actual answers, the same check exited 0 with no unresolved decisions. Earlier failures were retained; no assertions or frozen checks were weakened.

## Failures, recovery and limitations

1. The coordinator reported `Selected model is at capacity`. This is recorded as an environment interruption reported by the coordinator; there is no direct tool output proving that error in this chat. Existing files and hashes were retained.
2. The default Python executable reports a location warning and its attempted venv bootstrap exited 1. The full log is retained. Project-local package installation succeeded using workspace-local `TEMP` and `TMP`; no global package change was needed.
3. Initial pip installation hit a temporary-directory permission error. Initial npm installation hit `EPERM`. Repeating installation with local temporary/cache directories succeeded. See command records 001–005 and 009.
4. The trial's command-output logger initially decoded a Windows codepage as UTF-8 and then failed when printing replacement characters. Raw subprocess outputs and subprocess exit codes had already been saved. The local logger was fixed to use UTF-8 for itself and child Python processes. Subsequent commands retested discovery validation and focus successfully. This was trial harness code, not a frozen Skill defect.
5. Several exploratory `rg` reads targeted inferred filenames that did not exist (`web.py`, `design.py`, `app.js`). Actual filenames were subsequently inspected. These are agent lookup errors, not product defects.
6. Port 8841 returned another project's graph (`gallery-python-trial`). Those responses were rejected as evidence for this trial. A dynamically allocated port was used instead. The first dynamically allocated viewer (57404) was isolated from the browser and timed out. The isolated command session was stopped; no process from another trial was stopped or modified.
7. Host execution of this project's viewer was accepted by automatic approval review. Port 61522 then passed HTTP identity checks and browser rendering. Windows CIM/process inventory was unavailable inside the isolated environment, so no claim relies on that inventory.
8. Reusing the tab that had timed out encountered the browser's generated error-page URL restriction. A fresh tab opened the verified host URL successfully. No browser security warning or restriction was bypassed.
9. **Localization limitation, unchanged:** the complete viewer hard-codes `lang="zh-CN"` and Chinese controls (`assets/stategraph-viewer/index.html`, lines 2 and 5). The observed page combines those controls with canonical English graph labels, and the page has no visible language chooser. Minimal reproduction: start `scripts/bo_web.py serve --root PROJECT --port 0`, open the reported `/graph` URL, inspect the toolbar and HTML language attribute. The frozen language policy calls for explicit locale choice and English fallback. This initial phase records the mismatch without modifying the candidate. See the screenshot and frozen source hashes. It does not establish that every other service surface lacks localization.

## Resume boundary

Stop after this initial requested phase. The full development trial remains outstanding: independent expectations, canonical `bo-project/v1` declaration, change-sync baseline, Node.js application/executor, Python observer integration, all implemented-feature mappings and capture, real program and graph acceptance, and one later user-requested iteration. Preserve every original check and record failures/fixes/retests. Application behavior must continue with observation off or unavailable. Observer controls must not create business events.
