# Business network draft

```mermaid
flowchart LR
  n0["Review exhibition display"]
  n1["View simple exhibition"]
  n2["Check readable PNG content"]
  n3["Unreadable or non-PNG rejected"]
  n4["Log in separately"]
  n5["Display not permitted"]
  n6["Image awaiting display review"]
  n7["Display permitted"]
  n8["Upload file"]
  n9["Receive in-app review message"]
  n2 -->|"Not an image or unreadable: reject, send no message"| n3
  n2 -->|"Only a valid image produces a review message"| n9
  n2 -->|"Valid image awaits another account&#x27;s review"| n6
  n4 -->|"An authenticated account reviews another account&#x27;s image"| n0
  n4 -->|"Any authenticated account may upload"| n8
  n0 -->|"Reviewer declines display"| n5
  n0 -->|"Reviewer permits display"| n7
  n9 -->|"Another person reviews display"| n0
  n6 -->|"Review pending image"| n0
  n7 -->|"Exhibition presents permitted image"| n1
  n8 -->|"Check the uploaded file"| n2
```

[Open the live graph](http://127.0.0.1:57136/graph)

Confirm this understanding in the conversation, or describe a correction. Viewing the graph is not confirmation.
