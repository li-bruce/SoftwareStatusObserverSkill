// The application executes the canonical declaration without a collector dependency.
import {BOExecutor} from './engine.mjs';
import {readFileSync} from 'node:fs';
export const project = JSON.parse(readFileSync(new URL('./project.json', import.meta.url), 'utf8'));
export function imageReadable(context, payload) { return payload.valid; }
export function otherAccount(context, payload) { return Boolean(payload.actor) && payload.actor !== context.owner; }
const executor = new BOExecutor(project.model.machine, {imageReadable, otherAccount});
export function transition(image, event, payload) {
  const context = {owner:image.owner, reviewer:image.reviewer, bytes:image.bytes, readable:image.readable};
  return executor.step(image.state, event, context, payload);
}
