// Native application adapter. No Python imports or observer-dependent decisions.
// Only the declared flat bo.fsm/1 subset executes here; other engines need adapters.
export function bo_validateMachine(machine, guards={}) {
  if(machine.engine!=='bo.fsm' || machine.version!=='1') throw Error('Unsupported native machine engine/version');
  if(machine.execution || machine.states.some(s=>typeof s!=='string')) throw Error('bo.fsm/1 is flat; hierarchy/activity needs an explicit engine adapter');
  const allowed=new Set(['engine','version','states','values','initial','state_type','transitions','events','context','guards','labels']);
  if(Object.keys(machine).some(k=>!allowed.has(k))) throw Error('Unsupported machine semantics');
  if(!machine.states.length||machine.states.some(s=>!s.trim())||new Set(machine.states).size!==machine.states.length||!machine.states.includes(machine.initial)) throw Error('Invalid initial/states');
  if(machine.state_type!=='enum'||machine.values?.length!==machine.states.length||new Set(machine.values).size!==machine.values.length||machine.values.some(s=>!machine.states.includes(s))) throw Error('Invalid state values');
  if(['context','events','guards'].some(k=>machine[k]===null||typeof machine[k]!=='object'||Array.isArray(machine[k])))throw Error('Expected context, events and guards objects');
  const names=Object.keys(machine.guards||{});
  if(names.some(n=>!Object.hasOwn(guards,n)||typeof guards[n]!=='function')) throw Error('Missing guard implementation');
  for(const t of machine.transitions) {
    if(Object.keys(t).some(k=>!['source','dest','trigger','conditions','unless'].includes(k))) throw Error('Unsupported transition semantics');
    const sources=Array.isArray(t.source)?t.source:[t.source];
    if(!sources.length||sources.some(s=>s!=='*'&&!machine.states.includes(s)) || t.dest!==null&&!machine.states.includes(t.dest) || !Object.hasOwn(machine.events,t.trigger)) throw Error('Dangling transition');
    for(const key of ['conditions','unless']) for(const guard of bo_list(t[key])) if(!names.includes(guard)) throw Error('Undeclared guard');
  }
  for(const spec of Object.values(machine.context||{})) bo_spec(spec);
  for(const event of Object.values(machine.events||{})) {if(!event?.payload || typeof event.payload!=='object') throw Error('Event payload required'); for(const spec of Object.values(event.payload)) bo_spec(spec);}
}
const bo_list=v=>v===undefined?[]:Array.isArray(v)?v:[v];
function bo_spec(spec) {
  if(!['integer','number','boolean','string','enum','object','array'].includes(spec?.type)) throw Error('Unknown value type');
  if(spec.type==='enum'&&(!Array.isArray(spec.values)||!spec.values.length)) throw Error('Enum requires values');
  if(spec.min!==undefined&&!Number.isFinite(spec.min)||spec.max!==undefined&&!Number.isFinite(spec.max)||spec.min>spec.max) throw Error('Invalid value bounds');
  if(spec.items) bo_spec(spec.items);
  for(const child of Object.values(spec.properties||{})) bo_spec(child);
}
export function bo_value(value,spec) {
  bo_spec(spec);
  const type=spec.type;
  const valid={integer:Number.isSafeInteger(value),number:typeof value==='number'&&Number.isFinite(value),boolean:typeof value==='boolean',string:typeof value==='string',enum:spec.values?.some(v=>typeof v===typeof value&&JSON.stringify(v)===JSON.stringify(value)),object:value!==null&&typeof value==='object'&&!Array.isArray(value),array:Array.isArray(value)}[type];
  if(!valid) throw Error(`Expected ${type}`);
  if(['integer','number'].includes(type)&&(spec.min!==undefined&&value<spec.min||spec.max!==undefined&&value>spec.max)) throw Error('Value outside bounds');
  if(type==='array'&&spec.items) for(const v of value) bo_value(v,spec.items);
  if(type==='object') { for(const k of spec.required||[]) if(!Object.hasOwn(value,k)) throw Error('Missing property'); for(const [k,s] of Object.entries(spec.properties||{})) if(Object.hasOwn(value,k)) bo_value(value[k],s); }
}
export class BOExecutor {
  constructor(machine,guards={}) {bo_validateMachine(machine,guards); this.bo_definition=structuredClone(machine);this.bo_guards=guards;}
  step(state,event,context,payload={}) {
    const m=this.bo_definition;
    if(!m.states.includes(state)||!Object.hasOwn(m.events,event)) throw Error('Unknown state/event');
    if(Object.keys(context).some(k=>!Object.hasOwn(m.context,k))) throw Error('Unknown context field');
    for(const [k,s] of Object.entries(m.context)) {if(!Object.hasOwn(context,k)) throw Error('Missing context');bo_value(context[k],s);}
    const fields=m.events[event].payload;
    if(Object.keys(payload).some(k=>!Object.hasOwn(fields,k))) throw Error('Unknown payload field');
    for(const [k,s] of Object.entries(fields)) {if(!Object.hasOwn(payload,k)) throw Error('Missing payload');bo_value(payload[k],s);}
    const evaluated={};
    const guard=name=>{if(!Object.hasOwn(evaluated,name)){const v=this.bo_guards[name](structuredClone(context),structuredClone(payload));if(typeof v!=='boolean') throw Error('Guard must return boolean synchronously'); evaluated[name]=v;}return evaluated[name];};
    for(const t of m.transitions) if(t.trigger===event&&(bo_list(t.source).includes(state)||bo_list(t.source).includes('*'))) {
      if(bo_list(t.conditions).every(guard)&&bo_list(t.unless).every(n=>!guard(n))) return {state:t.dest??state,guards:evaluated,event,payload:structuredClone(payload)};
    }
    throw Error('No enabled transition');
  }
}

