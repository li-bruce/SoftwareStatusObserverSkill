import {mkdirSync,readFileSync,writeFileSync,renameSync,existsSync} from 'node:fs';
import {join} from 'node:path';
import {randomBytes,scryptSync} from 'node:crypto';
export function loadStore(directory) {
  mkdirSync(join(directory,'images'),{recursive:true});
  const path=join(directory,'store.json');
  if(existsSync(path)) return JSON.parse(readFileSync(path,'utf8'));
  const users=['alice','bob'].map(id=>{const salt=randomBytes(16).toString('hex');return {id,salt,hash:scryptSync('gallery-demo-2026',salt,32).toString('hex')};});
  const store={users,images:[],messages:[]};saveStore(directory,store);return store;
}
export function saveStore(directory, store) {
  const path=join(directory,'store.json');writeFileSync(path+'.tmp',JSON.stringify(store,null,2));renameSync(path+'.tmp',path);
}
