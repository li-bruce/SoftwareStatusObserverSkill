// Neutral optional observation ports; the core runs with these no-op defaults.
import {randomUUID} from 'node:crypto';
export let bo_probe={bo_run:randomUUID(),bo_build:'offline',bo_queue:[],bo_busy:false,bo_errors:0,bo_dropped:0,bo_enabled:false,record(){return null;},snapshot(){return false;},async flush(){return true;}};
export function bo_install(probe) { bo_probe=probe; }
export function bo_state(probe,image,evidence,step=null) {
  if(!evidence)return;
  const context={owner:image.owner,reviewer:image.reviewer,bytes:image.bytes,readable:image.readable};
  const configuration={attempt:probe.bo_run+':'+image.id,phase:image.state,state_revision:image.revision,run_build_id:probe.bo_build,context,activities:{},resources:{},journal:[]};
  probe.snapshot(image.id,image.state,context,image.revision,evidence,{event:step?.event??null,guards:step?.guards??null,payload:step?.payload??null,configuration});
}
