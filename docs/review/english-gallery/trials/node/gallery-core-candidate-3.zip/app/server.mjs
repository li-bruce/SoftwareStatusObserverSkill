import {createServer} from 'node:http';
import {readFileSync} from 'node:fs';
import {login,authenticate,logout,upload,messages,review,exhibition,imageBytes,bo_probe,fail,store} from './domain.mjs';
import {bo_install} from './bo_ports.mjs';
import {project} from '../bo_stategraph/native.mjs';
let bo_http=()=>false;
let bo_entry=bytes=>bytes;
try {
  const adapter=await import('../integrations/bo_probe.mjs');
  bo_install(adapter.bo_create(project));
  adapter.bo_restore(bo_probe,store);
  const web=await import('../integrations/bo_http.mjs');bo_http=web.bo_http;bo_entry=web.bo_entry;
}catch(error){console.error('Observation adapter unavailable; native application remains enabled.');}
export function send(response,status,body,headers={}) {
  response.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers});
  response.end(Buffer.isBuffer(body)?body:JSON.stringify(body));
  bo_probe.record('http','return',()=>({inputs:{path:response.bo_path||'/'},outputs:{status,body_bytes:Buffer.byteLength(Buffer.isBuffer(body)?body:JSON.stringify(body)),header_count:Object.keys(headers).length}}));
}
export async function readBody(request) {
  const chunks=[];let size=0;
  for await(const chunk of request){size+=chunk.length;if(size>14000000)fail(413,'file_too_large');chunks.push(chunk);}
  try{return JSON.parse(Buffer.concat(chunks).toString('utf8'));}catch{fail(400,'invalid_json');}
}
export async function handle(request,response) {
  const path=new URL(request.url,'http://localhost').pathname;
  response.bo_path=path;
  if(await bo_http(path,response,bo_probe,request))return;
  try {
    if(request.method==='GET'&&['/','/client.js','/style.css'].includes(path)) {
      const file=path==='/'?'index.html':path.slice(1);
      let bytes=readFileSync(new URL('../public/'+file,import.meta.url));
      if(file==='index.html')bytes=bo_entry(bytes,process.env.GALLERY_GRAPH);
      return send(response,200,bytes,{'Content-Type':file.endsWith('.js')?'text/javascript; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':'text/html; charset=utf-8'});
    }
    if(request.method==='GET'&&path==='/api/gallery')return send(response,200,{images:exhibition()});
    if(request.method==='GET'&&path.startsWith('/images/')) {
      let actor='';if(request.headers.cookie){try{actor=authenticate(request.headers.cookie).actor;}catch{}}
      return send(response,200,imageBytes(path.split('/').pop(),actor),{'Content-Type':'image/png'});
    }
    if(request.method==='POST') {
      if(request.headers.origin&&request.headers.origin!==`http://${request.headers.host}`)fail(403,'origin_denied');
      const body=await readBody(request);
      if(path==='/api/login'){
        if(typeof body.username!=='string'||typeof body.password!=='string'||body.password.length>256)fail(400,'invalid_credentials');
        const result=login(body.username,body.password);return send(response,200,{actor:result.actor},{'Set-Cookie':`gallery_node_session=${result.token}; HttpOnly; SameSite=Strict; Path=/`});
      }
      const identity=authenticate(request.headers.cookie);
      if(path==='/api/logout')return send(response,200,logout(identity.token),{'Set-Cookie':'gallery_node_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'});
      if(path==='/api/upload') {
        if(typeof body.filename!=='string'||typeof body.content!=='string'||!body.filename.trim())fail(400,'invalid_file');
        return send(response,201,await upload(identity.actor,body.filename,Buffer.from(body.content,'base64')));
      }
      if(path==='/api/review')return send(response,200,review(identity.actor,body.image_id,body.decision));
    }
    if(request.method==='GET'&&path==='/api/messages')return send(response,200,{messages:messages(authenticate(request.headers.cookie).actor)});
    if(request.method==='GET'&&path==='/api/me')return send(response,200,{actor:authenticate(request.headers.cookie).actor});
    return send(response,404,{error:'not_found'});
  }catch(error){return send(response,error.status||500,{error:error.status?error.message:'internal_error',...(error.image_id?{image_id:error.image_id}:{})});}
}
const server=createServer(handle);
server.listen(Number(process.env.PORT||0),'127.0.0.1',()=>console.log(JSON.stringify({type:'ready',url:`http://127.0.0.1:${server.address().port}`,run_id:bo_probe.bo_run})));
process.on('SIGTERM',()=>server.close(async()=>{await bo_probe.flush();process.exit(0);}));
