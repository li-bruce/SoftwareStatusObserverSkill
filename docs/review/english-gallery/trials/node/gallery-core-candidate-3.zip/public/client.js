let bo_ui=()=>{};
try{bo_ui=(await import('/bo_client.js')).bo_ui;}catch{}
const $=id=>document.getElementById(id);
const errors={invalid_credentials:'账号或密码不正确。',login_required:'请先登录。',invalid_image:'文件不是可读取的图片，未发送待审消息。',self_review_forbidden:'请由其他账号审核自己的作品。',review_already_decided:'这件作品已完成审核。',file_too_large:'文件过大，请选择较小的图片。'};
export async function api(path,body) {
  const response=await fetch(path,body===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  const result=await response.json();if(!response.ok)throw Error(errors[result.error]||result.error);return result;
}
export function status(text) { $('status').textContent=text; }
export function member(actor) { $('identity').textContent=actor?`当前账号：${actor}`:'请先登录';$('login-form').hidden=Boolean(actor);$('member-workspace').hidden=!actor; }
export async function signIn(event) {
  event.preventDefault();const username=$('username').value;const password_present=Boolean($('password').value);try{const result=await api('/api/login',{username,password:$('password').value});bo_ui('login',{username,password_present},{authenticated:true,actor:result.actor});$('password').value='';member(result.actor);status('已登录。你可以上传，也可以审核其他账号的作品。');await refresh();}catch(error){bo_ui('login',{username,password_present},{authenticated:false,actor:''});status(error.message);}
}
export async function signOut() {try{const result=await api('/api/logout',{});bo_ui('logout',{token_present:true},{removed:result.removed});member('');$('messages').replaceChildren();status('已退出登录。');}catch(error){status(error.message);}}
export async function sendFile(event) {
  event.preventDefault();const file=$('file').files[0];if(!file)return;
  $('upload-button').disabled=true;
  try{const bytes=new Uint8Array(await file.arrayBuffer());let binary='';for(const byte of bytes)binary+=String.fromCharCode(byte);const result=await api('/api/upload',{filename:file.name,content:btoa(binary)});bo_ui('upload',{actor:result.owner,filename:file.name,bytes:file.size},{image_id:result.id,state:result.state,revision:result.revision});$('upload-form').reset();status('图片已送审，等待其他账号审核。');await refresh();}catch(error){status(error.message);}finally{$('upload-button').disabled=false;}
}
export async function decide(image_id,decision) {try{const result=await api('/api/review',{image_id,decision});bo_ui('display_review',{actor:result.reviewer,image_id,decision},{state:result.state,revision:result.revision,reviewer:result.reviewer});status(decision==='approve'?'审核通过，作品已在画展页展示。':'审核未通过，作品不会展出。');await refresh();await showGallery();}catch(error){status(error.message);await refresh();}}
export function reviewClick(event) { decide(event.currentTarget.dataset.imageId,event.currentTarget.dataset.decision); }
export async function refresh() {
  try{const data=await api('/api/messages');bo_ui('messages',{actor:$('identity').textContent.replace('当前账号：','')},{count:data.messages.length,image_ids:data.messages.map(m=>m.image_id)});$('messages').replaceChildren();if(!data.messages.length){$('messages').textContent='暂时没有需要你审核的作品。';return;}
    for(const message of data.messages){const item=document.createElement('article');item.className='review-item';const image=document.createElement('img');image.src='/images/'+message.image_id;image.alt=message.image.filename;const description=document.createElement('p');description.textContent=`${message.owner} 上传了 ${message.image.filename}`;item.append(image,description);for(const [decision,label]of [['approve','通过并展出'],['reject','不予展出']]){const button=document.createElement('button');button.textContent=label;button.dataset.imageId=message.image_id;button.dataset.decision=decision;button.addEventListener('click',reviewClick);item.append(button);}$('messages').append(item);}
  }catch(error){status(error.message);}
}
export async function showGallery() {
  try{const data=await api('/api/gallery');$('gallery-count').textContent=`${data.images.length} 件作品`;$('empty-gallery').hidden=Boolean(data.images.length);$('artworks').replaceChildren();for(const record of data.images){const figure=document.createElement('figure');const image=document.createElement('img');image.src='/images/'+record.id;image.alt=record.filename;const caption=document.createElement('figcaption');caption.textContent=`${record.filename} · ${record.owner}`;figure.append(image,caption);$('artworks').append(figure);}}catch(error){status(error.message);}
}
$('login-form').addEventListener('submit',signIn);$('upload-form').addEventListener('submit',sendFile);$('logout').addEventListener('click',signOut);$('refresh').addEventListener('click',refresh);
showGallery();api('/api/me').then(result=>{member(result.actor);refresh();}).catch(()=>member(''));
