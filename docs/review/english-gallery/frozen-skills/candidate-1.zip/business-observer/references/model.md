# 图协议

当前结构、事件与源码协议见 [多语言架构](multilanguage.md)，JSON Schema 位于 `scripts/bo_observer/schemas/`。v3 图的语义校验仍由共同的 `bo_contracts` 完成，不允许悬空关系、状态投影缺失或未支持的执行语义。

旧版 v1 的简化 schema 和查看器已移除；旧证据保留在对应 Git 版本。不要将旧 schema 用于现行模型。
