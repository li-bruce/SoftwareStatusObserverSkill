# 公共图与语言适配

一张图，一个逻辑真源。项目在 `bo_stategraph/project.json` 保存 `bo-project/v1`：项目身份、用户的模式选择和现行 v3 图。`model.machine` 是执行声明，业务分组、静态调用、数据和权限关系仍在同一图中；普通边不能被执行器当成迁移。

现有 Python 项目可保留 v3 图文件，执行声明迁入 `bo_stategraph/machine.json`，生成器和真实执行器均读取它。导出的重复结构是生成产物，不能独立修改。

## 职责和目录

| 部分 | 职责 | 不负责什么 |
|---|---|---|
| Python 公共服务 | 验证、源码汇总、记录、查询、导出、局部图、完整查看器 | 替项目决定业务结果 |
| 原生状态模块 | 读取声明；驱动模式执行迁移，跟随模式读取项目实际状态 | 依赖观测服务才能运行 |
| 语言适配器 | 源码事实、类型和调用候选；显式、安全的参数采集与 JSON 投递 | 从函数名猜业务含义 |
| 编码过程 | 根据用户确认分组，维护绑定、探针、独立预期和验证 | 仅凭文件同步声称映射正确 |

公共实现位于 `scripts/bo_observer/`：`graph/`、`workflow/`、`observation/`、`web/`、`delivery/`、`adapters/`。`scripts/*.py` 的命令入口兼容已安装项目，没有另一份业务实现。独立 Python 状态核心的三个文件仍可单独打包；原生 JS 执行器和探针不导入 Python。

## 支持范围

- Python：AST 定位函数、参数、类型、调用；已有完整示例保留 transitions、并发活动、资源、等待、汇合和恢复。
- JavaScript/TypeScript：固定版本 TypeScript 编译器解析函数、箭头函数、方法、导入、调用与路由。
- React：解析 JSX/TSX 组件和事件处理函数。组件生命周期、Hook 行为和异步回调需要实际运行证据。
- Vue：通过 compiler-sfc 解析 SFC 的 script、script setup 和模板入口。模板与脚本保留原文件位置。
- 未支持的代码语言、语法错误和解析器缺失是明确缺口，不能静默略过。静态候选不能冒充动态调用事实。

原生 `bo.fsm/1` 只实现明确的平面状态、事件、同步布尔 guard 和顺序选取迁移。加载时拒绝层次、活动、回调等未实现语义。复杂项目复用其原生引擎并提供显式适配；不能将 Python 完整示例的 Petri/层次能力宣传为 JS 执行器已支持。监控协议可以保留完整活动配置，界面默认显示直接内容，高级分析按需展开。

## 通用协议

Schema 位于 `scripts/bo_observer/schemas/`。Python 使用 JSON Schema 2020-12 进行结构校验，再用共同校验器检查悬空关系、状态投影、引擎和 guard。执行适配器在本地再次检查自己支持的语义。

| 协议 | 内容 |
|---|---|
| `bo-project/v1` | 用户选择、业务抽象、源码绑定、状态及采集声明 |
| `bo-source/v1` | 各语言统一符号、参数、调用候选、未解析项和错误 |
| `bo-event/v1` | 项目、构建、模型、运行、生产者、调用、前后值和显式因果依赖 |
| `bo-snapshot/v1` | 同一证据对应的实际完整实例状态、参数、活动与资源 |
| `bo-stategraph/v1` | 完整结构及已保留的实际证据；不受页面筛选影响 |

模型版本和构建标识由服务验证，原生端原样传回。生产者序号只在自身流中递增；接收顺序用于回放，不宣称跨进程因果。同一实例只能有一个权威生产者。重复事件必须完全相同，旧序号、冲突身份、错误构建和不合法协议报错；实际业务状态违规保留原值并报告 mismatch。JSON 不传函数、循环对象、NaN、无穷数或超出 JS 安全范围的整数；大整数应用带类型的字符串约定。

公共服务监听本机。原生探针使用有界异步队列，显式选字段，失败只计入采集诊断。前端需明确允许的本地来源及开发用令牌，不使用通配 CORS。令牌文件、运行记录和个人布局不提交 Git。关闭 Web 与关闭采集独立；两者均不删除声明或实际执行器。

状态变化事件必须带应用给出的 `revision`，紧接着提交同一修订、同一 `evidence_id` 的实际快照。普通函数调用不强求状态快照；状态步骤缺快照则明确显示未知。公共服务将对应事实接入既有逐步回放，使用接收序号排序，不用不同进程的墙钟推定先后。回放帧有数量和字节上限，不能用最终状态填补历史空缺。

## 开发与确认

开始时询问一次：**基于状态图开发（drive），还是保留自己的逻辑、只观察（observe）？** 记录用户原话及对话位置。没有回答时只继续无关的准备工作，不能自行选择；后续用户可改变选择，保留变更来源。

`bo_sync scan` 将问题分成 `confirmations.user` 与 `confirmations.coding`。业务归属、权限含义和状态含义由用户确认；回调目标、函数参数和采集位置交给编码过程核对。需要记录的动态绑定可配置 `reconciliation`：答案绑定当前源码指纹、真实目标和已登记运行场景，陈旧答案或缺目标阻止验收。该记录不替代实际白盒用例。

使用 `begin → scan → inspect → verify → accept → check`；跨语言仍使用已有实现清单、参数覆盖、实际事件、独立效果和受保护的映射清单。代码、声明或工具变化后旧结果失效。用户只需要回答必要的业务问题和查看图；无须操作这些内部材料。

## 安装

```bash
python -m pip install -r <skill>/requirements.txt
npm ci --prefix <skill>/scripts/bo_observer/adapters/javascript
python <skill>/scripts/bo.py validate --root <project>
python <skill>/scripts/bo.py serve --root <project> --port 8830 --origin http://127.0.0.1:5173
```

只有需要解析 JS/TS/SFC 时才需要 Node 和解析器依赖；原生探针本身没有第三方依赖。使用锁定版本，不能随意换编译器后沿用旧指纹。公共服务的 `validate` 检查声明、源码盘点、绑定及静态实现覆盖，不运行项目测试；完整收尾仍运行已接线的 gate，不能以服务启动成功代替验收。

参考：[TypeScript Compiler API](https://github.com/microsoft/TypeScript/wiki/Using-the-Compiler-API)、[Vue SFC compiler](https://github.com/vuejs/core/tree/main/packages/compiler-sfc)。它们提供语法事实，不提供业务归属或完整动态调用证明。
