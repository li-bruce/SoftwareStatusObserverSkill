# 开发流程

当前入口见 [开发同步](continuous-development.md) 与 [多语言接入](multilanguage.md)。先确认当前意图和 drive / observe 选择，随后在编码期间维护声明、源码绑定和探针，最后执行完整检查。用户不需要操作中间材料。

源码盘点使用 `code_structure.py` 与 `bo_sync.py`，以实际语言适配器为准；不执行被扫描的源码。旧版 `model_tool.py` 已删除，不能用旧快照替代当前构建验证。
